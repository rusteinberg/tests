
// Single License. All Rights Reserved to Gilad Denneboom, 2016. Distribution without permission is not allowed.
// You can contact me at try6767@gmail.com or via my website: http://try67.blogspot.com

if (app.viewerVersion < 10) {
	app.addMenuItem({ cName: "ExportTooltips", cUser: "Export Tooltips", cParent: "Tools", nPos: -1,
		cExec: "importTooltips()", cEnable: "event.rc = (event.target != null);"}); 
	app.addMenuItem({ cName: "ImportTooltips", cUser: "Import Tooltips", cParent: "Tools", nPos: 0,
		cExec: "importTooltips()", cEnable: "event.rc = (event.target != null);"}); 
} else {
	app.addToolButton({ cName: "ExportTooltips", cLabel: "Export Tooltips", cTooltext: "Export Tooltips", 
		cExec: "exportTooltips()", cEnable: "event.rc = (event.target != null);"});
	app.addToolButton({ cName: "ImportTooltips", cLabel: "Import Tooltips", cTooltext: "Import Tooltips", 
		cExec: "importTooltips()", cEnable: "event.rc = (event.target != null);"});
}

function exportTooltips() {
	var cSummary = "Field name (DO NOT EDIT THIS COLUMN)\tTooltip\r\n";
	for (var i=0; i<this.numFields; i++) {
		var f = this.getField(this.getNthFieldName(i));
		if (f==null) continue;
		cSummary += f.name + "\t" + f.userName + "\r\n";
	}
	var outputFileName = this.documentFileName.replace(/\.pdf$/i,"_Tooltips.txt");
	this.createDataObject(outputFileName, "");
	var summaryStream = util.streamFromString(cSummary, "utf-8");
	this.setDataObjectContents(outputFileName, summaryStream);
	myTrustedExportDataObject(this, outputFileName);
	this.removeDataObject(outputFileName);
}

function importTooltips() {
	console.clear();
	app.alert("Select the tooltips text file...",3);
	var data = readCSV("\t");
	if (data==null || data.length==0) return;
	var counter = 0;
	var warnings = false;
	for (var i=1; i<data.length; i++) {
		if (data[i].length<2) continue;
		var fname = data[i][0];
		var newValue = data[i][1];
		var f = this.getField(fname);
		if (fname==null) {
			console.println("Error! Could not locate a field called: " + fname);
			warnings = true;
			continue;
		}
		try {
			f.userName = newValue;
			counter++;
		} catch (e) {
			console.println("Error! Could not apply the new tooltip value to the field: " + fname);
			warnings = true;
			continue;
		}
	}
	if (warnings) {
		app.alert("Done. " + counter + " fields were successfully edited, but there were some errors. See the Console window for more information.",1);
		console.show();
	} else app.alert("Done. " + counter + " fields were successfully edited.",3);
}

function readCSV(separator) {
	if (separator==null) separator = ";";
	var newDoc = myTrustedNewDoc();
	var filename = "file.csv";
	myTrustedImportDataObject(newDoc,filename);
	if (newDoc.dataObjects==null || newDoc.dataObjects.length!=1) {
		newDoc.closeDoc(true);
		app.alert("Error reading file.");
		return;
	}
	var stream = newDoc.getDataObjectContents(filename);
	var string = util.stringFromStream({oStream:stream, oCharSet:"utf-8"});
	string = string.replace(/\r\n/g,"\n");
	string = string.replace(/\r/g,"\n");
	newDoc.closeDoc(true);
	
	var inputLines = new Array();
	var lines = string.split("\n");
	for (var i=0; i<lines.length; i++) {
		var line = lines[i].replace(/[\r\n]/g,"");
		if (line!="")
			inputLines.push(line.split(separator));
	}
	return inputLines;
}

myExportDataObject = app.trustPropagatorFunction(function(doc,vName){
	app.beginPriv();
	doc.exportDataObject({cName: vName});
	app.endPriv();
});
myTrustedExportDataObject = app.trustedFunction(function(doc,vName) {
	app.beginPriv();
	myExportDataObject(doc,vName);
	app.endPriv();
});

myNewDoc = app.trustPropagatorFunction(function(){
	app.beginPriv();
	return app.newDoc();
	app.endPriv();
});
myTrustedNewDoc = app.trustedFunction(function() {
	app.beginPriv();
	return myNewDoc();
	app.endPriv();
});

myImportDataObject = app.trustPropagatorFunction(function(doc,vName){
	app.beginPriv();
	return doc.importDataObject({cName: vName});
	app.endPriv();
});
myTrustedImportDataObject = app.trustedFunction(function(doc,vName) {
	app.beginPriv();
	return myImportDataObject(doc,vName);
	app.endPriv();
});

// Single License. All Rights Reserved to Gilad Denneboom, 2016. Distribution without permission is not allowed.
// You can contact me at try6767@gmail.com or via my website: http://try67.blogspot.com
