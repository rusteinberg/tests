(function ($) {
  var buttons = $( '.toggle-caption' );

  if( buttons.length > 0 ) {

    buttons.each( function(){
      $( this ).on( 'click', function( event ) {
        event.preventDefault();

        /**
         * On remonte au parent puis on va chercher le bon enfant.
         * (permet d'éviter le recours à next() ou nextAll(), moins performantes)
         */
        var caption = $( this ).parent().find( '.toggleable-figcaption' ).eq(0);

        caption.toggleClass( 'is-open' );

        if( $( this ).attr( 'aria-expanded') === 'false' ) {
          $( this ).attr( 'aria-expanded', 'true' )
        } else {
          $( this ).attr( 'aria-expanded', 'false' )
        }
      });
    });

  }
})(jQuery);