////////////////////////////////////////////////////////////////////////////////
//
//	@file		editor.js
//	@details	Google Docs editor handling functions for Dragon RIA
//
//	@author		Chris Hardy
//	@date		17-Mar-2012
//	@copyright	(C) Copyright Nuance Communications, Inc. 2012 All Rights Reserved.
//				Trade secret and confidential information of Nuance Communications, Inc.
//				Copyright protection claimed includes all forms and matters of
//				copyrightable material and information now allowed by statutory or
//				judicial law or hereinafter granted, including without limitation,
//				material generated from the software programs which are displayed
//				on the screen such as icons, screen display looks, etc.
//
////////////////////////////////////////////////////////////////////////////////

var nuanria = nuanria || {};
nuanria.googledocs = nuanria.googledocs || {};

//(function(){
//    "use strict";

    //-------------------------------------------------------------------------
    // Editor API

    /*
     * Returns an array of rich text editor elements on the page
     */
    nuanria.googledocs.getAll = function () {
        /*var selectors = [
				'.kix-page-header',
				'.kix-page-content-wrapper'
        ];
        var combinedSelector = selectors.join(",");

        return document.querySelectorAll(combinedSelector);*/
	    return document.querySelectorAll(".kix-appview-editor");
    };

    /*
     * Returns the active rich text editor on the page (or null)
     */
    nuanria.googledocs.getActive = function() {
	    var editor = document.querySelector(".kix-appview-editor");
	    if (editor &&
		    document.activeElement == document.querySelector(".docs-texteventtarget-iframe"))
	    {
		    return editor;
	    }
	    else
	    {
		    return null;
	    }
    };

    /*
     * Returns contents and information about the active rich text editor
     */
    nuanria.googledocs.getChanges = function() {
	    var result = {};

        var text = nuan_gGetText();
        var selectionInfo = nuan_gGetSelectionInfo(true);

        result.text = text;
        result.selStart = selectionInfo.start;
        result.selLength = selectionInfo.length;
        result.visibleStart = selectionInfo.visibleStart;
        result.visibleLength = selectionInfo.visibleLength;

	    nuan_gLastCursorStart = selectionInfo.start;
        console.log("getChanges", result);
        return result;
    }

    /*
     * Changes text and/or selection of the active rich text editor
     */
    nuanria.googledocs.makeChanges = function(blockStart, blockLength, text, selStart, selLength) {
        var logString = "makeChanges - blockStart : " + blockStart + ", blockLength : " + blockLength + ", text : " + text + ", selStart : " + selStart + ", selLength : " + selLength;
        console.log(logString);

	    // Often-times, makechanges will be called with only selStart and selLength specified.
	    // This indicates that there is no text update, just selection.
	    var isUpdatingText = text != "" || blockLength > 0;

	    if (isUpdatingText) {
		    console.log("update text");
	        //nuan_gSelectText(blockStart, blockLength);
    	    nuan_gSendText(text);
	    }

        if (selLength !== 0 || blockStart + text.length != selStart) {
    	    setTimeout(function() {
    		    console.log("final selection");
        	    nuan_gSelectText(selStart, selLength);
            }, 0);
        }

        nuan_gLastCursorStart = selStart;
    };

    var nuan_gLastCursorStart = -1;

    /*
     * Returns screen coordinates of a character relative to the editor's document
     */
    nuanria.googledocs.getCharacterRectangle = function(index) {
	    console.log("getCharacterRectangle");

	    var dim = nuan_gGetSelectionDimensions();
	    var top1 = dim[0].top;
	    var left1 = dim[0].left;
	    var top2 = dim[dim.length-1].top;
	    var left2 = dim[dim.length-1].left;

	    var coords;
	    if (nuan_gLastCursorStart == -1) {
		    coords = nuan_gSetCursorApprox(index);
		    nuan_gMouseDownUp(left1, top1, false);
		    nuan_gMouseDownUp(left2+1, top2, true);

	    } else {
		    coords = dim[0];
		    coords.top += coords.height;
		    nuan_gLastCursorStart = -1;
	    }

	    var result = {};
	    result.top = Math.floor(coords.top);
	    result.left = Math.floor(coords.left);
	    result.bottom = result.top + 1;
	    result.right = result.left + 1;
	    return result;
    };

	/*
	* Returns New-Line and New-Paragraph terminator characters
	*/
	nuanria.googledocs.getLineParagraphTerminators = function() {
		return { Line: "\r\n", Paragraph: "\r\n\r\n" };
	}

    //-----------------------------------------------------------------------------
    //-----------------------------------------------------------------------------

    // returns an assoc. array of class names for an element
    function nuan_getClasses(element) {
	    var classes = {};

	    if (!element.className) {
		    return classes;
	    }

	    var className = "";
	    for (var i = 0; i < element.className.length; i++) {
		    var char = element.className[i];
		    if (char == " ") {
			    if (className !== "") {
				    classes[className] = true;
			    }
			    className = "";
		    } else {
			    className += char;
		    }
	    }
	    if (className !== "") {
		    classes[className] = true;
	    }
	    return classes;
    }

    function nuan_gScanDocument(callback) {
	    var container = document.querySelector('.kix-appview-editor');
	    var cursor = document.querySelector('.kix-cursor-caret[style*=rgb\\(0\\,]');
	    var cursorOffset = cursor.parentNode.getBoundingClientRect();
	    var lastParagraph = null;
	    var lastLine = null;
	    var lastTextBlock = null;
	    var lastContentBlock = null;
	    var lastCell = null;
	    //var cursorProximity = null;

	    var elements = container.querySelectorAll('.kix-page-bottom, .kix-lineview, .kix-paragraphrenderer:not([style]), ' +
			     '.kix-lineview-text-block, .kix-selection-overlay, .kix-page, ' +
			     '.kix-cellrenderer, kix-table-column-resize-dragger');
	    for (var i = 0; i < elements.length; i++) {
		    var node = elements[i];
		    var classes = nuan_getClasses(node);

		    // after text block
		    if (classes["kix-page-bottom"] || classes["kix-paragraphrenderer"] || classes['kix-lineview-text-block'] || classes["kix-lineview"] || classes["kix-page-bottom"]) {
			    if (lastTextBlock) {
				    callback("afterTextBlock", lastTextBlock, node);
			    }
			    lastTextBlock = null;
		    }

		    // after every line:
		    if ((classes["kix-page-bottom"] || classes["kix-paragraphrenderer"] || classes["kix-lineview"])) {
			    if (lastLine) {
				    callback("afterLine", lastLine);
			    }
			    lastLine = null;
		    }

		    // after every content block (text block or empty line)
		    if (classes["kix-page-bottom"] || classes["kix-paragraphrenderer"] || classes['kix-lineview-text-block'] || classes["kix-lineview"]) {
			    if (lastContentBlock && node.parentNode.parentNode != lastContentBlock) {
				    var lastContentBlockClasses = nuan_getClasses(lastContentBlock);
				    if (lastContentBlockClasses['kix-lineview']) {
					    callback("contentBlock", lastContentBlock);
				    }

				    callback("afterContentBlockBeforeCR", lastContentBlock, node);

				    // after every paragraph except the last:
				    if (classes["kix-paragraphrenderer"] && !node.style.length && lastParagraph) {
					    callback("betweenParagraphs", lastParagraph);
				    }

				    callback("afterContentBlock", lastContentBlock, node);
			    }
			    lastContentBlock = null;
		    }

		    // after every cell
		    if (classes["kix-cellrenderer"] || classes["kix-table-column-resize-dragger"]) {
			    if (lastCell) {
				    callback("afterCell", lastCell);
				    lastCell = null;
			    }
		    }

		    // before every page:
		    if (classes["kix-page"]) {
			    callback("page", node);
		    }

		    // before every cell:
		    if (classes['kix-cellrenderer']) {
			    callback("cell", node);
			    lastCell = node;
		    }

		    // before every paragraph:
		    if (classes["kix-paragraphrenderer"] && !node.style.length) {
			    callback("paragraph", node);
			    lastParagraph = node;
		    }

		    // before every line:
		    if (classes["kix-lineview"]) {
			    if (callback("line", node) === false) return false;
			    lastLine = node;
			    lastContentBlock = node;
		    }

		    // before text block
		    if (classes['kix-lineview-text-block']) {
			    if (node.previousSibling)
			    {
				    var nodeStyle = window.getComputedStyle(node);
				    var leftPadding = nodeStyle.paddingLeft;
				    if (leftPadding !== "" &&
					    leftPadding !== "0px")
				    {
					    if (callback("tab", node) === false) return false;
				    }
			    }

			    lastContentBlock = node; // this will override an empty line element
			    callback("contentBlock", lastContentBlock);

			    var result = callback("textBlock", node);
			    lastTextBlock = node;

			    if (result === false) return false;
		    }
	    }
    }

    function nuan_gDocumentState() {
	    var start = new Date().getMilliseconds();

	    // turn params into a dict
	    var options = {};
	    for (var i = 0; i < arguments.length; i++) {
		    options[arguments[i]] = true;
	    }

	    // init results object
	    var results = {};
	    if (options["selection"]) {
		    options["count"] = true; // need counting for selection
		    results["selectionStart"] = -1;
		    results["selectionLength"] = -1;
	    }

	    if (options["contentBlocks"]) {
		    options["count"] = true; // need counting for this
		    results["contentBlocks"] = [];
	    }

	    if (options["visible"]) {
		    options["count"] = true; // need counting for this
		    results["visibleStart"] = -1;
		    results["visibleLength"] = 0;
	    }

	    if (options["count"]) results["count"] = 0;
	    if (options["text"]) results["text"] = "";

	    var lineVisible;
	    var textLeft;

	    var selectionStartCoords;
	    var selectionEndCoords;
	    var selectionStartInCell = false;
	    var selectionEndInCell = false;
	    var inCell = false;

	    if (options["selection"]) {

		    var selections = document.querySelectorAll(".kix-selection-overlay");

		    if (selections.length) {
			    var startSelection = selections[0];
			    var startBounds = startSelection.getBoundingClientRect();
			    selectionStartCoords = {
				    left: startBounds.left,
				    top: startBounds.top
			    };
			    var endSelection = selections[selections.length-1];
			    var endBounds = endSelection.getBoundingClientRect();
			    selectionEndCoords = {
				    left: endBounds.right,
				    top: endBounds.top
			    };

		    } else {
			    var cursor = document.querySelector(".kix-cursor-caret[style*=rgb\\(0\\,]");
			    cursor.style.opacity = 1; // ensure cursor is visible during this op
			    var cursorBounds = cursor.getBoundingClientRect();
			    selectionStartCoords = {
				    left: cursorBounds.left,
				    top: cursorBounds.top
			    };
			    selectionEndCoords = {
				    left: cursorBounds.left-1,
				    top: cursorBounds.top
			    };
		    }
	    }

	    // used when determining visible text
	    var editor = document.querySelector('.kix-appview-editor');

	    // use the scanDocument function to find the nodes we're interested in
	    nuan_gScanDocument(function (type, node, arg) {

		    if (type == "afterTextBlock") {
			    if (options["count"] || options["text"]) {
				    // add a space between lines in a paragraph
				    if (node.nextSibling) {
					    // determine if there is a leading space on the next line
					    var line = nuanria.utils.findClosestAncestor(node, '.kix-lineview');
					    var nextLine = line.nextSibling;
					    var text = nextLine != null ? nextLine.textContent : "";
					    var addSpace = nextLine && text.match(/^\s/) === null;
					    
					    // assume one space at the end of each line within a paragraph
					    if (addSpace) {
						    if (options["count"]) {
							    results.count += " ".length;
						    }

						    if (options["text"]) {
							    results.text += " ";
						    }
					    }
				    }
			    }
		    }

		    if (type == "tab") {
			    if (options["count"]) {
				    results.count += 1;
			    }
			    if (options["text"]) {
				    results.text += '\t';
			    }
		    }

		    if (type == "line") {
			    if (options["visible"]) {
				    var lineBounds = node.getBoundingClientRect();
				    var editorBounds = editor.getBoundingClientRect();
				    lineVisible = lineBounds.top > editorBounds.top &&
								      lineBounds.top < editorBounds.top + editorBounds.height;
				    if (lineVisible && results["visibleStart"] == -1) {
					    results["visibleStart"] = results["count"];
				    }
			    }
		    }

		    if (type == "afterLine") {
			    if (options["visible"]) {
				    var lineBounds = node.getBoundingClientRect();
				    var editorBounds = editor.getBoundingClientRect();
				    lineVisible = lineBounds.top > editorBounds.top &&
								      lineBounds.top < editorBounds.top + editorBounds.height;
				    if (lineVisible && results["visibleStart"] != -1) {
					    results["visibleLength"] = results["count"] - results["visibleStart"];
				    }
			    }
		    }

		    if (type == "betweenParagraphs") {
			    if (options["count"]) {
				    results.count += "\r\n".length;
			    }

			    if (options["text"]) {
				    results.text += "\r\n";
			    }
		    }

		    if (type == "cell") {
			    if (options["selection"]) {
				    inCell = true;
				    var cellBounds = node.getBoundingClientRect();
				    if (cellBounds.left <= selectionStartCoords.left &&
					    cellBounds.top <= selectionStartCoords.top &&
					    cellBounds.right >= selectionStartCoords.left &&
					    cellBounds.bottom >= selectionStartCoords.top)
				    {
					    selectionStartInCell = true;
				    }

				    if (cellBounds.left <= selectionEndCoords.left &&
					    cellBounds.top <= selectionEndCoords.top &&
					    cellBounds.right >= selectionEndCoords.left &&
					    cellBounds.bottom >= selectionEndCoords.top)
				    {
					    selectionEndInCell = true;
				    }
			    }
		    }

    /*
		    if (type == "afterCell") {
			    if (options["selection"]) {
				    inCell = false;
				    selectionStartInCell = false;
				    selectionEndInCell = false;
			    }
		    }
    */
		    // todo: contentboundary?

		    if (type == "contentBlock") {
			    if (options["selection"]) {

				    var blockRect = node.getBoundingClientRect();
				    var nodeStyle = window.getComputedStyle(node);
				    textLeft = blockRect.left + parseInt(nodeStyle.paddingLeft, 10);

				    // check to see if selection starts at or before beginning of text block
				    if (results.selectionStart == -1 && (!inCell || selectionStartInCell) &&
					    blockRect.top >= selectionStartCoords.top &&
					    textLeft >= selectionStartCoords.left)
				    {
					    results.selectionStart = results.count;
					    results.selectionStartAccurate = true;
				    }

				    // check to see if selection ends at or before beginning of text block
				    if (results.selectionLength == -1&& (!inCell || selectionEndInCell) &&
					    blockRect.top >= selectionEndCoords.top &&
					    textLeft >= selectionEndCoords.left + 1)
				    {
					    results.selectionLength = results.count - results.selectionStart;
					    results.selectionEndAccurate = true;
				    }
			    }
		    }

		    if (type == "afterContentBlockBeforeCR") {
			    if (options["selection"]) {
				    var nextElement = arg;
				    var nextElementRect = nextElement.getBoundingClientRect();

				    // check whether we've passed the selection start
				    var passedStart = Math.floor(nextElementRect.top) > selectionStartCoords.top ||
								       Math.floor(nextElementRect.top) >= selectionStartCoords.top && Math.floor(nextElementRect.left) > selectionStartCoords.left;
				    if (passedStart && results.selectionStart == -1 && (!inCell || selectionStartInCell)) {
					    results.selectionStart = results.count;
					    results.selectionStartAccurate = true;
				    }

				    // check whether we've passed the selection end
				    var passedEnd = Math.floor(nextElementRect.top) > selectionEndCoords.top ||
								    Math.floor(nextElementRect.top) >= selectionEndCoords.top && Math.floor(nextElementRect.left) > selectionEndCoords.left + 1;
				    if (passedEnd && results.selectionLength == -1 && (!inCell || selectionEndInCell)) {
					    results.selectionLength = results.count - results.selectionStart;
					    results.selectionEndAccurate = true;
				    }
			    }
		    }

		    if (type == "afterContentBlock") {
			    if (options["contentBlocks"]) {
				    var contentBlocks = results["contentBlocks"];
				    var nodeClasses = nuan_getClasses(node);
				    var contentElement = nodeClasses['kix-lineview'] ? null : node;
				    contentBlocks.push({
					    start: contentBlocks.length ? contentBlocks[contentBlocks.length-1].end : 0,
					    end: results.count,
					    element: contentElement
				    });
			    }
		    }

		    if (type == "textBlock") {
			    // we need to iterate the chars individually if we
			    // want to get cursor/selection positioning
			    if (options["selection"]) {
				    var textBlockBounds = node.getBoundingClientRect();
				    var nodeStyle = window.getComputedStyle(node);
				    textLeft = textBlockBounds.left + parseInt(nodeStyle.paddingLeft, 10);
				    var textBlockHasSelectionStart	= Math.floor(textBlockBounds.top) == selectionStartCoords.top &&
												      textLeft <= selectionStartCoords.left &&
												      selectionStartCoords.left <= textLeft + textBlockBounds.width;
				    var textBlockHasSelectionEnd	= Math.floor(textBlockBounds.top) == selectionEndCoords.top &&
												      textLeft <= selectionEndCoords.left &&
												      selectionEndCoords.left <= textLeft + textBlockBounds.width;

				    if (textBlockHasSelectionStart || textBlockHasSelectionEnd) {
					    // get all text nodes and their offsets
					    var textNodes = nuan_getTextNodesIn(node);
					    var textBlockText = node.textContent
										    .replace(new RegExp("\xA0", "g"), " "); // nbsp;

					    // Complexity alert! (In the name of speed...)
					    // We're doing a binary search in the text block to locate
					    // selection information because it is too slow doing it linearly
					    var selectionEnd = -1;

					    // Recursion function used for binary search
					    var checkSelection = function (lowerCharIndex, leftBoundary, upperCharIndex, rightBoundary,
												      beginAtTextNodeIndex, depth,
												      findSelectionStart, findSelectionEnd)
					    {
						    if (depth > 10) {
							    // bail out.. we don't have more than 1024 (2^depth) chars on a line.
							    return;
						    }

						    if (lowerCharIndex == upperCharIndex) return;

						    var mid = lowerCharIndex + Math.floor((upperCharIndex - lowerCharIndex) / 2);

						    // iterate thru textnodes to find the node containing the character we want to look at
						    for (var i = beginAtTextNodeIndex; i < textNodes.length; i++) {
							    var textNodeInfo = textNodes[i];
							    var textNode = textNodeInfo.parent.childNodes[textNodeInfo.siblingPos];
							    var textNodeLen = textNode.nodeValue.length;
							    var findCursorLeft = false;
							    var findSelectionStartLeft = false;
							    var findSelectionEndLeft = false;

							    // check if this text node contains the mid character
							    if (mid >= textNodeInfo.offset && mid <= textNodeInfo.offset + textNodeLen) {
								    // we will set these to true if we need to inspect either side further
								    // for either cursor or selection info
								    var checkLeft = false;
								    var checkRight = false;

								    // get char position
								    var coords = nuanria.utils.getCharacterCoords(textNode, mid - textNodeInfo.offset, true);

								    //var tolerance = (navigator.appName == 'Microsoft Internet Explorer') ? 5 : 0;
								    var tolerance = 0;

								    if (findSelectionStart) {
									    // check if this is the start of the selection
									    if (coords.left - tolerance <= selectionStartCoords.left + 1 &&
										    coords.left + tolerance >= selectionStartCoords.left - 1)
									    {
										    results.selectionStart = results.count + mid;

									    } else if (selectionStartCoords.left < coords.left) {
										    checkLeft = true;
										    findSelectionStartLeft = true;

									    } else {
										    checkRight = true;
									    }
								    }

								    if (findSelectionEnd) {
									    // check if this is the end of the selection (+/-)
									    if (coords.left + tolerance >= selectionEndCoords.left - 1 &&
										    coords.left - tolerance <= selectionEndCoords.left + 1)
									    {
										    selectionEnd = results.count + mid;

									    } else if (selectionEndCoords.left < coords.left) {
										    checkLeft = true;
										    findSelectionEndLeft = true;

									    } else {
										    checkRight = true;
									    }
								    }

								    if (checkLeft) {
									    // recursion happens here:
									    checkSelection(lowerCharIndex, leftBoundary,
												       mid, coords.left,
												       beginAtTextNodeIndex, depth + 1,
												       findSelectionStartLeft && findSelectionStart,
												       findSelectionEndLeft && findSelectionEnd);
								    }

								    if (checkRight) {
									    // recursion happens here:
									    checkSelection(mid, coords.left,
												       upperCharIndex, rightBoundary,
												       i, depth + 1,
												       !findSelectionStartLeft && findSelectionStart,
												       !findSelectionEndLeft && findSelectionEnd);
								    }

								    break;
							    }
						    }
					    };

					    // kick off binary search for selection info
					    var nodeBounds = node.getBoundingClientRect();
					    checkSelection(0, nodeBounds.left,
								       textBlockText.length + 1, nodeBounds.left + nodeBounds.width,
								       0, 0,
								       results.selectionStart == -1 && textBlockHasSelectionStart,
								       results.selectionLength == -1 && textBlockHasSelectionEnd);

					    if (selectionEnd != -1) {
						    results.selectionLength = selectionEnd - results.selectionStart;
					    }
				    }
			    }

			    if (options["count"]) {
				    results.count += node.textContent.length;
			    }

			    if (options["text"]) {
				    results.text += node.textContent
										     .replace(new RegExp("\xA0", "g"), " "); // nbsp;
			    }
		    }
	    });

	    if (options["count"]) {
		    nuan_lastCount = results.count;
	    }

	    if (options["selection"]) {
		    nuan_lastSelectionStart = results.selectionStart;
		    nuan_lastSelectionLength = results.selectionLength;
	    }

	    if (options["debug"]) {
		    var end = new Date().getMilliseconds();
		    if (end < start) end += 1000;
		    console.log(end - start + "ms");
	    }

	    return results;
    }

    function nuan_gGetText() {
	    var text = nuan_gDocumentState("text").text;
	    return text;
    }

    function nuan_gGetCount() {
	    var count = nuan_gDocumentState("count", "debug").count;
	    return count;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Performing selection
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function nuan_gSetCursorApprox(index) {
	    var container = document.querySelector('.kix-appview-editor');
	    var count = 0;
	    var coords = null;

	    // traverse all nodes
	    nuan_gScanDocument(function (type, node) {
		    if (type == "afterTextBlock") {
			    // add a space between lines in a paragraph
			    if (!node.nextSibling) {
				    // determine if there is a leading space on the next line
				    var line = nuanria.utils.findClosestAncestor(node, '.kix-lineview');
				    var nextLine = line.nextSibling;
				    var text = nextLine ? nextLine.textContent : "";
				    var addSpace = nextLine && text.match(/^\s/) === null;

				    // assume one space at the end of each line within a paragraph
				    if (addSpace) {
					    // Update: we don't need to do this any more because gdocs will report
					    // the space properly for us.
					    //count += " ".length;
				    }
			    }
		    }

		    // before every line:
		    if (type == "line") {
			    // use the line element to set cursor to the beginning
			    // of the line because blank lines won't have any text
			    if ((index == count || index == count - 1) && node.textContent === "") {
				    coords = nuanria.utils.getCharacterCoords(node, 0);
				    return false;
			    }
		    }

		    if (type == "betweenParagraphs") {
			    // new line
			    count += "\r\n".length;
		    }

		    if (type == "tab") {
			    count += "\t".length;
			    if (count == index && node.textContent === "") {
				    coords = nuanria.utils.getCharacterCoords(node, 0);
				    return false; // this stops the scan
			    }
		    }

		    // text node:
		    if (type == "textBlock") {
			    var textBlockLength = node.textContent.length;
			    if (count > index) {
				    coords = nuanria.utils.getCharacterCoords(node, 0);
				    return false; // this stops the scan
			    }

			    if (count <= index &&
				    textBlockLength + count >= index)
			    {
				    var textNodes = nuan_getTextNodesIn(node);
				    for (var i = 0; i < textNodes.length; i++) {
					    var textNodeInfo = textNodes[i];
					    if (index >= count + textNodeInfo.offset &&
						    index <= count + textNodeInfo.offset + textNodeInfo.length)
					    {
						    var textNode = textNodeInfo.parent.childNodes[textNodeInfo.siblingPos];
						    coords = nuanria.utils.getCharacterCoords(textNode, index - (count + textNodeInfo.offset));
						    return false; // this stops the scan
					    }
				    }
			    }

			    count += textBlockLength;
		    }
	    });

	    if (coords) {
		    coords.left = coords.left - 1;
		    nuan_gMouseDownUp(coords.left, coords.top, false);
	    }

	    return coords;
    }

    function nuan_findClosestAccuracyOffset(index) {
	    var coords, i;

	    // construct RegExp that we can use to break the line
	    // into the parts that would be selected by double-clicking:
	    var punctuation = "\x21-\x26" +  // ! " # $ % &
					      "\x28-\x2C" +  // ( ) * + ,
					      "\x2E-\x2F" +  // . /
					      "\x3A-\x40" +  // : ; < = > ? @
					      "\x5B-\x5E" +  // [ \ ] ^
					      "\x60"      +  // `
					      "\x7B-\x7E" +  // { | } ~
					      "\u201C-\u201D";   //
	    var space = "\xA0 ";
	    var whitespace = "\r\n" + space;
	    var tab = "\t";
	    var splitRe = new RegExp(tab + "|" +
							     "[" + punctuation + "]+[" + space + "]?" +
							     "|" +
							     "[" + whitespace + "]+" +
							     "|" +
							     "[^" + punctuation + whitespace + "]+["  + space + "]?",
							     "g");

	    var state = nuan_gDocumentState("text", "contentBlocks");

	    var extraInfo = {};
	    if (state.text.length == index) {
		    extraInfo.documentEnd = true;
	    }
	    if (index === 0) {
		    extraInfo.documentStart = true;
	    }

	    var block;
	    for (i = 0; i < state.contentBlocks.length; i++) {
		    block = state.contentBlocks[i];
		    if (block.start <= index && index < block.end) { // should be < or <= block.end ??
			    break;
		    }
	    }


	    // get selection chunks from block
	    var blockText = state.text.substring(block.start, block.end);
	    var chunks = blockText.match(splitRe);
	    if (!chunks) chunks = [];
	    if (chunks[chunks.length-1] == "\r\n") {
		    chunks.pop();
	    }

	    // set cursor to the beginning of the block
	    // we know this will be accurate
	    coords = nuan_gSetCursorApprox(block.start);
	    nuan_gMouseDownUp(coords.left-5, coords.top, false); // todo: are these necessary?
	    nuan_gMouseDownUp(coords.left, coords.top, false);   //	  ?
	    var dim = nuan_gGetSelectionDimensions();
	    var left = dim[0].left;
	    var top = dim[0].top;
	    var right = dim[dim.length-1].right-1;
	    var count = block.start;
	    var chunk = "";

	    var spaceRe = new RegExp("[" + space + "\t]");
	    if (index != count)
	    {
		    // select the chunk that includes the index character
		    for (i = 0; i < chunks.length; i++) {

			    nuan_gMouseDownUp(left, top, false);
			    nuan_gMouseDownUp(left, top, false);

			    dim = nuan_gGetSelectionDimensions();
			    left = dim[dim.length-1].left;
			    top = dim[dim.length-1].top;
			    right = dim[dim.length-1].right;
			    chunk = chunks[i];

			    var prevChunk = chunks[i-1];

			    // highlighting double spaces will select the previous space
			    if (prevChunk &&
				    chunk[0].match(spaceRe) &&
				    prevChunk[prevChunk.length-1].match(spaceRe))
			    {
				    count--;
				    chunk = prevChunk[prevChunk.length-1] + chunk;
			    }

			    var nextChunk = chunks[i+1];

			    // chunk that is not preceeded by a space will not include a following space
			    // [abc]  [,,   ]  [def]	=>		[abc]  [,,]  [  ] / [def]
			    // [abc]  [,, ]    [def]	=>		[abc]  [,,]  [ ] / [def]
			    // [abc]  [, ]     [def]	=>		[abc]  [,]   [ ] / [def]
			    if (prevChunk &&
				    !chunk[0].match(spaceRe) &&
				    !prevChunk[prevChunk.length-1].match(spaceRe) &&
				    chunk[chunk.length-1].match(spaceRe))
			    {
				    if (nextChunk && nextChunk.length && nextChunk[0].match(spaceRe)) {
					    chunks[i+1] = chunk[chunk.length-1] + nextChunk;
				    } else {
					    chunks.splice(i+1, 0, chunk[chunk.length-1]);
				    }

				    chunk = chunk.substr(0, chunk.length-1);
				    chunks[i] = chunk;
			    }

			    if (index <= count + chunk.length) {
				    break;
			    }

			    count += chunk.length;
			    left = right;
		    }
	    }

	    // detect if a space is included at the end of the chunk selection
	    // block.element is undefined for an empty line
	    var endSpaceOffset = 0;
	    if (block.element && i == chunks.length-1) {
		    var textRect = block.element.getBoundingClientRect();

		    var cursor = document.querySelector('.kix-cursor-caret[style*=rgb\\(0\\,]');
		    cursor.style.opacity = 1; // ensure cursor is visible during this op
		    var selectionRect = cursor.getBoundingClientRect();
		    var selectionOverlap = 4; //px
		    if (selectionRect.right > textRect.right + selectionOverlap && !chunk[chunk.length-1].match(spaceRe)) {
			    endSpaceOffset = 1;
		    }
	    }

	    // determine which boundary of the selection is closest to the index
	    // if the index falls on the last chunk of a block, always use the left offset
	    var offsetLeft = index - count;
	    var offsetRight = count + chunk.length - index;

	    var retVal;
	    if (offsetLeft <= offsetRight) {
		    retVal = { index: count, offset: offsetLeft, left: left, top: top, extraInfo: extraInfo };
	    } else {
		    retVal = { index: count + chunk.length, offset: 0 - offsetRight - endSpaceOffset, left: right, top: top, extraInfo: extraInfo };
	    }

	    return retVal;
    }

    // Some browsers (IE) don't render text in a predictable way.
    // This means that Google Docs' internal representation of where text
    // is on the screen doesn't always match up exactly to where it might
    // actually be rendered by the browser.  However, it turns out there are
    // certain locations relative to word boundaries that do always match
    // up. So we can use a technique to reference these known accurate coordinates
    // to accommodate for discrepancies.
    function nuan_gGetAccurateCoords(index) {
	    var accuracyOffset = nuan_findClosestAccuracyOffset(index);
	    var coords = { left: accuracyOffset.left, top: accuracyOffset.top, extraInfo: accuracyOffset.extraInfo };
	    nuan_gMouseDownUp(coords.left-1, coords.top, false);// ensure previous selection is deselected
	    nuan_gMouseDownUp(coords.left, coords.top, false);
	    if (accuracyOffset.offset === 0) {
		    return coords;
	    }

	    var offset = 0 - accuracyOffset.offset;
	    var wordTop = accuracyOffset.top;
	    var i, j, newSelectionWidth;

	    var selectionWidth = nuan_gGetSelectionWidth();
	    if (offset !== 0) {
		    if (offset < 0)  { // accuracy point is to the left
			    for (i = 0; i > offset; i--) {
				    for (j = 0; j < 50; j++) { // assume max char width is 50px
					    coords.left = coords.left + 1;
					    nuan_gMouseDownUp(coords.left, coords.top, true);
					    newSelectionWidth = nuan_gGetSelectionWidth();
					    if (newSelectionWidth != selectionWidth) {
						    selectionWidth = newSelectionWidth;
						    break;
					    }
				    }
			    }

		    } else {
			    for (i = 0; i < offset; i++) {
				    for (j = 0; j < 50; j++) { // assume max char width is 50px
					    coords.left = coords.left - 1;
					    nuan_gMouseDownUp(coords.left, coords.top, true);
					    newSelectionWidth = nuan_gGetSelectionWidth();
					    if (newSelectionWidth != selectionWidth) {
						    selectionWidth = newSelectionWidth;
						    break;
					    }
				    }
			    }
		    }
	    }

	    // deselect the selection
	    //nuan_gMouseDownUp(coords.left+1, coords.top, false);
	    //nuan_gMouseDownUp(coords.left, coords.top, false);
	    return coords;
    }

    function nuan_gSelectText(start, length) {
	    //console.log("nuan_gSelectText(" + start + "," + length + ")");

	    // Note that calling nuan_gGetAccurateCoords can modify the selection
	    var endCoords = nuan_gGetAccurateCoords(start + length);

	    if (!length) {
		    // clear any existing selection
	        nuan_gMouseDownUp(endCoords.left - 5, endCoords.top, false);
	    }

	    var startCoords = null;
	    if (length) {
		    startCoords = nuan_gGetAccurateCoords(start);
	    } else if (endCoords.extraInfo.documentEnd) {
		    startCoords = { left: endCoords.left+1, top: endCoords.top, extraInfo: endCoords.extraInfo };
	    } else if (endCoords.extraInfo.documentStart) {
		    startCoords = { left: 1, top: endCoords.top, extraInfo: endCoords.extraInfo };
	    }

	    if (startCoords && startCoords.extraInfo.documentStart) {
		    startCoords.left = 1;
	    }

	    if (endCoords.extraInfo.documentEnd) {
		    endCoords.left = nuan_gEditor.getBoundingClientRect().width-20;
	    }

	    nuan_gMouseDownUp(endCoords.left, endCoords.top, false);
	    if (startCoords) {
		    nuan_gMouseDownUp(startCoords.left-1, startCoords.top, true);
	    }

	    return nuan_gGetSelectionHash();
    }


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// Getting selection
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    function nuan_gGetSelectionInfo(isDictationInProgress) {

	    var dim1 = nuan_gGetSelectionDimensions();
	    var state = nuan_gDocumentState("selection", "visible");
	    var sel = {
		    start: state.selectionStart,
		    length: state.selectionLength,
		    visibleStart: 0,
		    visibleLength: -1,
		    hash:  nuan_gGetSelectionHash()
		    };

	    if (!isDictationInProgress) {
		    // if dictation isn't in progress we don't need accurate selection info
		    return sel;
	    }

	    if (!state.selectionStartAccurate || !state.selectionEndAccurate) {
		    // three attempts to correct the selection info
		    var tries = 0;
		    for (var i = 0; i < tries; i++) {
			    nuan_gSelectText(sel.start, sel.length);
			    var dim2 = nuan_gGetSelectionDimensions();
			    var compareResult = nuan_gCompareSelectionDimensions(dim1, dim2);

			    if (!compareResult) {
				    break;
			    }

			    if (compareResult.startOffset == "left") {
				    sel.start = sel.start + 1;
			    }

			    if (compareResult.startOffset == "right") {
				    sel.start = sel.start - 1;
			    }

			    if (compareResult.endOffset == "left") {
				    sel.length = sel.length + 1;
			    }

			    if (compareResult.endOffset == "right") {
				    sel.length = sel.length - 1;
			    }
		    }
	    } else {
		    // reselect to cursor position (this will put cursor at start of next line)
		    //nuan_gSelectText(sel.start, sel.length);
	    }

	    sel.visibleStart = state.visibleStart;
	    sel.visibleLength = state.visibleLength;
	    //sel.hash = state.selectionStart + "," + state.selectionLength;
	    sel.hash = nuan_gGetSelectionHash();
	    return sel;
    }

    function nuan_gGetSelectionHash() {
	    //var state = nuan_gDocumentState("selection");
	    //return state.selectionStart + "," + state.selectionLength;
	    var selectionWidth = nuan_gGetSelectionWidth();
	    var cursor = document.querySelector('.kix-cursor-caret[style*=rgb\\(0\\,]');
	    cursor.style.opacity = '1'; // ensure cursor is visible during this op
	    var coords = nuanria.utils.getCoords(cursor, 0);
	    var prevElementWidth = 0;
	    var leftPadding = 0;
	    if (!selectionWidth) {
		    var cursorBounds = cursor.getBoundingClientRect();
		    var prevElement = document.elementFromPoint(cursorBounds.left-1, cursorBounds.top + cursorBounds.height-2);
		    prevElementWidth = prevElement.getBoundingClientRect().width + "," + prevElement.textContent.length;
	    }
	    var hash = coords.left + "," + coords.top + "," + selectionWidth + "," + prevElementWidth + "," + leftPadding;
	    return hash;
    }

    function nuan_gGetSelectionDimensions() {
	    // package up selection info in a way that will
	    // allow for easy comparison and sorting.
	    var selections = { };
	    var container = document.querySelector('.kix-appview-editor');
	    var lineSelections = container.querySelectorAll('.kix-selection-overlay');
	    for (var i = 0; i < lineSelections.length; i++) {
		    var selection = lineSelections[i];
		    var bounds = selection.getBoundingClientRect();
		    if (selections[bounds.top] === undefined) {
			    selections[bounds.top] = {};
		    }
		    selections[bounds.top][bounds.left] = bounds;
	    }

	    // now order these from top to bottom
	    var results = [];
	    var yPositions = Object.keys(selections).sort();
	    for (var y = 0; y < yPositions.length; y++) {
		    var yPos = yPositions[y];
		    var xPositions = Object.keys(selections[yPos]).sort();
		    for (var x = 0; x < xPositions.length; x++) {
			    var xPos = xPositions[x];
			    results.push(selections[yPos][xPos]);
		    }
	    }

	    if (!results.length) {
		    // if there are no selections add the cursor position
		    var cursor = document.querySelector('.kix-cursor-caret[style*=rgb\\(0\\,]');
		    if (cursor) {
			    var cursorBounds = cursor.getBoundingClientRect();
			    var cursorParentBounds = cursor.parentNode.getBoundingClientRect();
			    var selection = {
				    left: cursorParentBounds.left,
				    top: cursorParentBounds.top,
				    width: cursorBounds.width,
				    height: cursorBounds.height,
				    right: cursorParentBounds.left + cursorBounds.width
			    };
			    results.push(selection);
		    }
	    }

	    return results;
    }

    function nuan_gCompareSelectionDimensions(dimensions1, dimensions2) {
	    // check they have the same count
	    if (dimensions1.length != dimensions2.length) {
		    return false;
	    }

	    for (var i = 0; i < dimensions1.length; i++) {
		    var dim1 = dimensions1[i];
		    var dim2 = dimensions2[i];

		    var result = {};
		    if (i === 0) {
			    result.first = true;
		    }

		    if (i == dimensions1.length-1) {
			    result.last = true;
		    }

		    result.sameLine = dim1.top == dim2.top ? true : false;

		    if (dim1.left != dim2.left) {
			    result.startOffset = dim1.left < dim2.left ? "right" : "left";
		    } else if (dim1.width != dim2.width) {
			    result.endOffset = dim1.width < dim2.width ? "right" : "left";
		    }

		    if (!result.sameLine ||
			    result.startOffset ||
			    result.endOffset)
		    {
			    return result;
		    }
	    }

	    return null;
    }

    function nuan_gGetCursorCoords() {
	    var cursor = document.querySelector('.kix-cursor-caret[style*=rgb\\(0\\,]');
	    cursor.style.opacity = 1; // ensure cursor is visible during this op
	    var bounds = cursor.getBoundingClientRect();
	    return {
		    left: bounds.left,
		    top: bounds.bottom
	    };
    }

    // get the total width of all selections in the document
    function nuan_gGetSelectionWidth() {
	    var width = 0;
	    var container = document.querySelector('.kix-appview-editor');
	    var lineSelections = container.querySelectorAll('.kix-selection-overlay');
	    for (var i = 0; i < lineSelections.length; i++) {
		    width += lineSelections[i].getBoundingClientRect().width;
	    }
	    return width;
    }

    var nuan_gEditor;
    function nuan_gMouseDownUp(x, y, shift) {
	    if (!nuan_gEditor) {
		    nuan_gEditor = document.querySelector('.kix-appview-editor');
	    }

	    nuanria.automation.mouseEvent("mousedown", nuan_gEditor, {
		    "clientX"	: x,
		    "clientY"	: y,
		    "shiftKey"	: shift
	    });

	    nuanria.automation.mouseEvent("mouseup", nuan_gEditor, {
		    "clientX"	: x,
		    "clientY"	: y,
		    "shiftKey"	: shift
	    });
    }

    function nuan_gSendText(text) {
	    if (text === "") {
		    nuanria.globals.plugin.sendKeys("{DEL}");
	    } else {
	        console.log("(SendText) Before corrections - [" + text + "]");
		    var html = text.replace(/ /g, "&nbsp;")
					       .replace(/\n/g, "<br/>")
					       .replace(/\t/g, "&#09;");
		    console.log("(SendText) After corrections - [" + html + "]");
	        var doc = document.activeElement.contentDocument;
	        console.log("Before delete ->" + doc.body.innerHTML);
		    doc.body.innerHTML = "";
		    setTimeout(function() { doc.body.innerHTML = html; }, 0);
		    var ev = doc.createEvent("Event");
		    ev.initEvent("paste", true, true);
		    doc.body.dispatchEvent(ev);
	    }
    }

    function nuan_getTextNodesIn(node) {
        var textNodes = [];
        var count = 0;

        function getTextNodes(node, pos) {
            if (node.nodeType == Node.TEXT_NODE) {
                textNodes.push( { offset: count, parent: node.parentNode, siblingPos: pos, length: node.nodeValue.length } );
                count += node.nodeValue.length;
            } else {
                if (node.childNodes) {
                    for (var i = 0, len = node.childNodes.length; i < len; ++i) {
                        getTextNodes(node.childNodes[i], i);
                    }
                }
            }
        }

        getTextNodes(node, -1);
        return textNodes;
    };
//}());