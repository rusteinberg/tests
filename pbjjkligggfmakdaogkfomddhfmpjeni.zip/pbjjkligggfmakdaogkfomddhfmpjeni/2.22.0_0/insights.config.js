// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
window.insights = {
    "options": {
        "fullName": "Accessibility Insights for Web",
        "extensionDescription": "Accessibility Insights for Web helps developers quickly find and fix accessibility issues.",
        "bundled": true,
        "productCategory": "extension",
        "icon16": "icons/brand/blue/brand-blue-16px.png",
        "icon48": "icons/brand/blue/brand-blue-48px.png",
        "icon128": "icons/brand/blue/brand-blue-128px.png",
        "electronIconBaseName": "icons/brand/blue/electron-icons/icon",
        "telemetryBuildName": "Production",
        "appInsightsInstrumentationKey": "5217efad-9690-44fc-9646-04b25a95e63b"
    }
}