# Frogger
Typical Frogger game written in Java (Pepe the Frogger)

## To Run the Project

__Clone the project first__
```
git clone https://github.com/omerbselvi/Frogger.git
```

__Then move to the project directory and run javac, java__

```
cd ../Frogger
javac frogger/main.java
java frogger.main
```
__Enjoy!__

## Screenshots
 ![alt tag](https://vgy.me/mfr01A.png)![alt tag](https://vgy.me/woUA7O.png)
