document.getElementById('colorContrast').addEventListener('click', function() {
    colorContrast();
}, false);

document.getElementById('validatorSelection').addEventListener('click', function() {
    validation();
}, false);

document.getElementById('nodeListener').addEventListener('click', function() {
    nodeListener();
}, false);


function writeColorResults(response) {
    var p = document.getElementById('colorResults')
    p.innerHTML = '<span style="float:right; padding:1em;border: 1px solid black; background-color:'+response.data[0].bg+';color:'+response.data[0].fg+';line-height:2em;display:block;padding:.5em;font-size:1.2em;">Sample</span>'
    +'Foreground: '+response.data[0].fg
    +'<br />Background: '+response.data[0].bg
    +'<br />The contrast ratio is: ' +response.data[0].ratio
    +'<br />Font Size: '+response.data[0].size
    +'<br />Font Weight: '+response.data[0].weight
    +'<br />Opacity: '+response.data[0].opacity
    +'<br />BG Image: '+response.data[0].bgImage
    +'<br />Success: '+response.data[0].success;
}

function nodeListener(){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                runNodeListener();
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        runNodeListener();
                });   
            }
    });   
}

function runNodeListener(){
    chrome.devtools.inspectedWindow.eval("nodeListener()",{ useContentScriptContext: true });
}

function validation(){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                runValidation();
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        runValidation();
                });   
            }
    });   
}

function runValidation() {
    chrome.devtools.inspectedWindow.eval("sendSelectionToValidator()",{ useContentScriptContext: true });
}

function colorContrast(){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                runColorContrast();
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        runColorContrast();
                });   
            }
    });   
}

function runColorContrast() {
    chrome.devtools.inspectedWindow.eval(
        "ia11yVars.colorContrast($0)",
        { useContentScriptContext: true },
        function(response){ // callback from when the test is done
            console.log(response)
            writeColorResults(response);
        }
    );

}
