var testFilters = [];

// get the error string
function errorString(id){
    return "<span class='error'><span class='bold'>Error: </span>"+chrome.i18n.getMessage(id+'_Problem')+"</span>";
}

// get the warning string
function warningString(id){
    return "<span class='warning'><span class='bold'>Warning: </span>"+chrome.i18n.getMessage(id+'_Problem')+"</span>";
}

// get the solution string
function solutionString(id){
    return "<span class='solution'><span class='bold'>Recommend: </span>"+chrome.i18n.getMessage(id+'_Solution')+"</span>";
}


// add any page-wide notes
function addResultsNotes(id, m){
  var p = document.getElementById(id);
  var button = document.createElement('a');
  var buttonAtt = document.createAttribute('href');
  buttonAtt.value="#";
  button.setAttributeNode(buttonAtt);
  button.appendChild(document.createTextNode(m.scopeHTML));
  button.addEventListener('click', function() {
    chrome.devtools.inspectedWindow.eval("inspect(document.querySelector('"+m.scopePath+"'))");
    return false;
  }, false);
  button.innerHTML = stylizedHTML(m.scopeHTML);
  p.innerHTML = "Limited Scope: "
  p.appendChild(button);
}

function addResultsNotesText(id, t){
  var p = document.getElementById(id);
  p.innerHTML = t;
}

// clear the numbers for a test
function clearNumbers(test){
  // clear the total instances count
  var countCell = document.getElementById(test+"-number");
  countCell.textContent = '';
  // clear the hidden instances count
  var countCell = document.getElementById(test+"-hidden");
  countCell.textContent = '';
  // clear the warnings instances count
  var warningsCell = document.getElementById(test+"-warnings");
  warningsCell.textContent = '';
  removeClass(warningsCell,"boldWarning");
  // clear the errors instances count
  var errorsCell = document.getElementById(test+"-errors");
  errorsCell.textContent = '';
  removeClass(errorsCell,"boldError");
  // clear the hidden warnings instances count
  var warningsHiddenCell = document.getElementById(test+"-warnings-hidden");
  warningsHiddenCell.textContent = '';
  // clear the hidden errors instances count
  var errorsHiddenCell = document.getElementById(test+"-errors-hidden");
  errorsHiddenCell.textContent = '';
}

// clears the totals row
function clearTotals(){
  // clear the total instances count
  var countCell = document.getElementById("totalVisible");
  countCell.textContent = '';
  // clear the hidden instances count
  var hiddenCell = document.getElementById("totalHidden");
  hiddenCell.textContent = '';
  // clear the warnings instances count
  var warningsCell = document.getElementById("totalWarnings");
  warningsCell.textContent = '';;
  // clear the errors instances count
  var errorsCell = document.getElementById("totalErrors");
  errorsCell.textContent = '';
  // clear the hidden warnings instances count
  var warningsHiddenCell = document.getElementById("totalHiddenWarnings");
  warningsHiddenCell.textContent = '';
  // clear the hidden errors instances count
  var errorsHiddenCell = document.getElementById("totalHiddenErrors");
  errorsHiddenCell.textContent = '';
}

// reset the totals for a given test
function resetTotals(test) {
  if (typeof issueTotals[test] == 'undefined') {
    issueTotals[test] = {};
  }

  issueTotals[test].count = 0;
  issueTotals[test].warnings = 0;
  issueTotals[test].errors = 0;
  issueTotals[test].hiddenCount = 0;
  issueTotals[test].hiddenWarnings = 0;
  issueTotals[test].hiddenErrors = 0;
  issueTotals[test].issues = [];
}

// add the total to the object
function addToTotals(test,singleTest) {
  issueTotals[test.test].count += test.count;
  issueTotals[test.test].warnings += test.warnCount;
  issueTotals[test.test].errors += test.errorCount;
  issueTotals[test.test].hiddenCount += test.hiddenCount;
  issueTotals[test.test].hiddenWarnings += test.hiddenWarnCount;
  issueTotals[test.test].hiddenErrors += test.hiddenErrorCount;

  if(!singleTest){
    issueTotals['totals'].count += test.count;
    issueTotals['totals'].warnings += test.warnCount;
    issueTotals['totals'].errors += test.errorCount;
    issueTotals['totals'].hiddenCount += test.hiddenCount;
    issueTotals['totals'].hiddenWarnings += test.hiddenWarnCount;
    issueTotals['totals'].hiddenErrors += test.hiddenErrorCount;  
  }

  if(test.errorCount){
    test.data.forEach((item) =>{
      if(!item.hidden){
        item.error.forEach((issue) =>{
          if(typeof issueTotals[test.test].issues[issue] === 'undefined'){
            issueTotals[test.test].issues[issue] = {};
            issueTotals[test.test].issues[issue].errors = 0;
            issueTotals[test.test].issues[issue].warnings = 0;
          }
          issueTotals[test.test].issues[issue].errors++;
        });
      }
    });
  }
  if(test.warnCount){
    test.data.forEach((item) =>{
      if(!item.hidden){
        item.warn.forEach((issue) =>{
          if(typeof issueTotals[test.test].issues[issue] === 'undefined'){
            issueTotals[test.test].issues[issue] = {};
            issueTotals[test.test].issues[issue].errors = 0;
            issueTotals[test.test].issues[issue].warnings = 0;
          }
          issueTotals[test.test].issues[issue].warnings++;
        });
      }
    });
  }    
}

function updateTestTable(testGroup){
  var tbody;
  if(testGroup === ""){
    addClass(document.getElementById('testTableContainer'), 'hide');
    removeClass(document.getElementById('testTotalsTableContainer'), 'hide');
    tbody = document.getElementById('testTotalsTableBody');
  } else {
    addClass(document.getElementById('testTotalsTableContainer'), 'hide');
    removeClass(document.getElementById('testTableContainer'), 'hide');
    tbody = document.getElementById('testTableBody');    
  }
  tbody.innerHTML = "";
  for(var group in issueTotals){
    if((testGroup == "" || testGroup == group) && typeof issueTotals[group] == 'object' && 
        (issueTotals[group].warnings || issueTotals[group].errors)){
      for(var test in issueTotals[group].issues){
        var row = document.createElement('tr');
        var iconclass = testGroup == "" ? "" : "fa fa-check";
        var tdTest, tdGroup;
        if(testGroup === ""){
          tdTest = "<td class='textLeft double-cell-width'>" + test + "</td>";
          tdGroup = "<td class='textLeft cell-width'><button class='groupTestButton flatButton'>" + group + "</button></td>";
        } else {
          tdTest = "<td class='textLeft cell-width'><button class='testFilterButton flatButton' aria-pressed='true'><span class='" + iconclass + "'></span> " + test + "</button></td>";
          tdGroup = "<td class='textLeft' cell-width>" + group + "</td>";
        }
        
        var tdError = "<td class='textCenter cell-width'>" + issueTotals[group].issues[test].errors; + "</td>";
        var tdWarning = "<td class='textCenter cell-width'>" + issueTotals[group].issues[test].warnings; + "</td>";
        row.innerHTML = tdTest + tdError + tdWarning + tdGroup;
        row.dataset.errorCount = issueTotals[group].issues[test].errors;
        row.dataset.warningCount = issueTotals[group].issues[test].warnings;
        tbody.appendChild(row);

        if(testGroup != ""){
          row.dataset.testName = test;
          testFilters.push(test);
          var button = row.querySelector(".testFilterButton");
          button.addEventListener("click", toggleTestFilters(button));
        } else {
          var button = row.querySelector(".groupTestButton");
          button.addEventListener("click", performTest(group));
        }
      }
    }
  }
  if(testGroup === ""){
    updateSpeechOutput("Tests Complete");
  } else {
    updateSpeechOutput("Test Complete");
  }
}

function writeNumbers(test,singleTest){
  var countCell = document.getElementById(test+"-number");
  var errorsCell = document.getElementById(test+"-errors");
  var warningsCell = document.getElementById(test+"-warnings");
  var hiddenCell = document.getElementById(test+"-hidden");
  var errorsHiddenCell = document.getElementById(test+"-errors-hidden");
  var warningsHiddenCell = document.getElementById(test+"-warnings-hidden");

  if(parseInt(countCell.textContent) != issueTotals[test].count || 
    parseInt(errorsCell.textContent) != issueTotals[test].errors || 
    parseInt(warningsCell.textContent) != issueTotals[test].warnings || 
    parseInt(hiddenCell.textContent) != issueTotals[test].hiddenCount || 
    parseInt(errorsHiddenCell.textContent) != issueTotals[test].hiddenErrors || 
    parseInt(warningsHiddenCell.textContent) != issueTotals[test].hiddenWarnings){
    
    countCell.textContent = issueTotals[test].count;
    errorsCell.textContent = issueTotals[test].errors;
    if(issueTotals[test].errors > 0){
      addClass(errorsCell,'boldError');
    } else {
      removeClass(errorsCell,'boldError')
    }
    warningsCell.textContent = issueTotals[test].warnings;
    if(issueTotals[test].warnings > 0){
      addClass(warningsCell,'boldWarning');
    } else {
      removeClass(warningsCell,'boldWarning');
    }
    hiddenCell.textContent = issueTotals[test].hiddenCount;
    errorsHiddenCell.textContent = issueTotals[test].hiddenErrors;
    warningsHiddenCell.textContent = issueTotals[test].hiddenWarnings;

  }

  // updaet the totals row
  if(!singleTest){
    countCell = document.getElementById("totalVisible");
    errorsCell = document.getElementById("totalErrors");
    warningsCell = document.getElementById("totalWarnings");
    hiddenCell = document.getElementById("totalHidden");
    errorsHiddenCell = document.getElementById("totalHiddenErrors");
    warningsHiddenCell = document.getElementById("totalHiddenWarnings");

    countCell.textContent = issueTotals['totals'].count;
    errorsCell.textContent = issueTotals['totals'].errors;
    warningsCell.textContent = issueTotals['totals'].warnings;
    hiddenCell.textContent = issueTotals['totals'].hiddenCount;
    errorsHiddenCell.textContent = issueTotals['totals'].hiddenErrors;
    warningsHiddenCell.textContent = issueTotals['totals'].hiddenWarnings;
  }
}

function cleanNumbers(test){
  var countCell = document.getElementById(test+"-number").innerHTML = "";
  var errorsCell = document.getElementById(test+"-errors").innerHTML = "";
  var warningsCell = document.getElementById(test+"-warnings").innerHTML = "";
  var hiddenCell = document.getElementById(test+"-hidden").innerHTML = "";
  var errorsHiddenCell = document.getElementById(test+"-errors-hidden").innerHTML = "";
  var warningsHiddenCell = document.getElementById(test+"-warnings-hidden").innerHTML = ""; 
  countCell = document.getElementById("totalVisible").innerHTML = "";
  errorsCell = document.getElementById("totalErrors").innerHTML = "";
  warningsCell = document.getElementById("totalWarnings").innerHTML = "";
  hiddenCell = document.getElementById("totalHidden").innerHTML = "";
  errorsHiddenCell = document.getElementById("totalHiddenErrors").innerHTML = "";
  warningsHiddenCell = document.getElementById("totalHiddenWarnings").innerHTML = "";  
}

function updateNumbers2(test, count, hidden, warnings, errors, warningsHidden, errorsHidden){
  
  // update the total number of instances
  var countCell = document.getElementById(test+"-number");
  var previousCount = parseInt(countCell.textContent);
  // if there is no valid number
  if (isNaN(previousCount))  {
    previousCount = 0;
  }
  // add the new amount to the existing amount
  countCell.textContent = previousCount + count;
  
  // update the total number of hidden elements
  var hiddenCell = document.getElementById(test+"-hidden");
  var previousCount = parseInt(hiddenCell.textContent);
  // if there is no valid number
  if (isNaN(previousCount))  {
    previousCount = 0;
  }
  // add the new amount to the existing amount
  hiddenCell.textContent = previousCount + hidden;

  // update the total number of warnings
  var warningsCell = document.getElementById(test+"-warnings");
  var previousWarnings = parseInt(warningsCell.textContent);
  // if there is no valid number
  if (isNaN(previousWarnings))  {
    previousWarnings = 0;
  }
  // add the new amount to the existing amount
  warningsCell.textContent = previousWarnings + warnings;  


  // update the total number of errors
  var errorsCell = document.getElementById(test+"-errors");
  var previousErrors = parseInt(errorsCell.textContent);
  // if there is no valid number
  if (isNaN(previousErrors))  {
    previousErrors = 0;
  }
  // add the new amount to the existing amount
  errorsCell.textContent = previousErrors + errors;  

  // update the total number of hidden errors
  var errorsHiddenCell = document.getElementById(test+"-errors-hidden");
  var previousErrorsHidden = parseInt(errorsHiddenCell.textContent);
  // if there is no valid number
  if (isNaN(previousErrorsHidden))  {
    previousErrorsHidden = 0;
  }
  // add the new amount to the existing amount
  errorsHiddenCell.textContent = previousErrorsHidden + errorsHidden;  

  // update the total number of hidden warnings
  var warningsHiddenCell = document.getElementById(test+"-warnings-hidden");
  var previousWarningsHidden = parseInt(warningsHiddenCell.textContent);
  // if there is no valid number
  if (isNaN(previousWarningsHidden))  {
    previousWarningsHidden = 0;
  }
  // add the new amount to the existing amount
  warningsHiddenCell.textContent = previousWarningsHidden + warningsHidden;  

}

// delete the entries in the results list
function emptyResults(ulId) {
  var myNode = document.getElementById(ulId);
  while (myNode.firstChild) {
    myNode.removeChild(myNode.firstChild);
  }
}

// add CSS to create stylized HTML
function stylizedHTML(str){
  var y = "";
  var openQuote=false;
  for (var i = 0, len = str.length; i < len; i++) {
    if(str[i]=="<"){
      y += '<span class="element">'+'&lt;';
    } else if (str[i]==" " && !openQuote) {
      y += '</span>' + str[i] + '<span class="attribute">';
    } else if (str[i]=="\"" && str[i-1] == "=") {
      y += str[i] + '<span class="value">';
      openQuote = true;
    } else if (str[i]=="\"" && (str[i+1] == " " || str[i+1] == '>')) {
      y += '</span><span class="attribute">' + str[i] + "";
      openQuote = false;
    } else if (str[i]==">") {
      y += '<span class="element">' + '&gt;' + '</span>';
    } else {
      y += str[i];
    }

  }
  return y;
}

//////////// NEED TO FINISH //////////////////
function addColorResults(ulId,m){
/*
    <ul>
  <li>Element: <span id="color-element"></span></li>
  <li>Sample: <span id="color-sample"></span></li>
  <li>Foreground: <span id="color-foreground"></span></li>
  <li>Background: <span id="color-background"></span></li>
  <li>Contrast Ratio: <span id="color-contrast-ratio"></span></li>
  <li>Size: <span id="color-size"></span></li>
  <li>Weight: <span id="color-weight"></span></li>
  <li>Opacity: <span id="color-opacity"></span></li>
  <li>BG Image: <span id="color-background-image"></span></li>
  </ul>
  */

  var ul = document.getElementById(ulId);
  var li = document.createElement("li");
  li.appendChild(document.createTextNode('Element: ' + m.html));
  li.appendChild(document.createTextNode('Element: ' + m.sample));
}

function addResult(ulId, m, frameId, frameURL) {

  var iatCounter = m.iatCounter;

  var show = false;

  // whether the result is an error, warning, or OK
  var status;

  // whether the result is hidden
  var hidden = false;

  hidden = m.hidden;

  // get the number of errors
  var errorLength = m.error.length;
  var error;
  if (errorLength>0){
    error=true;
  } else {
    error=false;
  }

  // get the number of warnings
  var warnLength = m.warn.length;
  var warn;
  if (warnLength>0){
    warn=true;
  } else {
    warn=false;
  }

  // get the number of information messages
  var infoLength = m.info.length;
  var info;
  if (infoLength>0){
    info=true;
  } else {
    info=false;
  }

  // if error, else if warn, else ok
  if(error){
    status = "ERR";
  } else if(warn) {
    status = "WARN";
  } else {
    status = "OK";
  }

  // get the list container
  var ul = document.getElementById(ulId);
  
  // create a new list item
  var li = document.createElement("li");
  li.dataset.status = status;
  li.dataset.hidden = hidden;
  li.dataset.frameid = frameId;
  li.dataset.frameurl = frameURL;
  li.dataset.iat = iatCounter;
  
  show = toggleFilterIndividualItem(hidden, status);
  
  if(!show){
    var liClass = document.createAttribute('class');
    liClass.value = 'hide'
    li.setAttributeNode(liClass);
  }


  var span = document.createElement('span');
  var att = document.createAttribute("class");

  att.value = status;
//  att.value = (error?'err':(warn?'warn':'ok')); 
  span.setAttributeNode(att);
  span.appendChild(document.createTextNode(status));
//  span.appendChild(document.createTextNode((error?' ERR ':(warn?' WARN ':' OK '))));
  li.appendChild(span);


  if(hidden) {
    var spanHidden = document.createElement('span');
    var attHidden = document.createAttribute("class");

    attHidden.value = 'hidden';
    spanHidden.setAttributeNode(attHidden);
    spanHidden.appendChild(document.createTextNode('Hidden'));
    li.appendChild(spanHidden);
  }

  // element code  
  var button = document.createElement('a');
  var buttonAtt = document.createAttribute('href');
  buttonAtt.value="#";
  button.setAttributeNode(buttonAtt);
  button.appendChild(document.createTextNode(m.html));
/*
  button.addEventListener('click', function() {
    chrome.devtools.inspectedWindow.eval("inspect(document.querySelector('"+m.path+"'))");
    return false;
  }, false);
*/

  button.addEventListener('click', showElement(m.path,frameId,frameURL));
  button.addEventListener('mouseover', addHover(m.path,frameId));
  button.addEventListener('mouseout', removeHover(m.path,frameId));

  button.innerHTML = stylizedHTML(m.html);
  li.appendChild(button);

  // info bubbles
  if(infoLength > 0){
    var infoArrayLength = m.info.length;
    for (var j = 0; j < infoArrayLength; j++) {
      var spanInfo = document.createElement('span');
      var spanAtt = document.createAttribute("class");
      spanAtt.value = "note"; 
      spanInfo.setAttributeNode(spanAtt);
      spanInfo.appendChild(document.createTextNode(" " + m.info[j] + " "));
      li.appendChild(spanInfo);
    }
//     ul.appendChild(li);
  }

  var assertionList = null;
  // error lists
  if(errorLength > 0){
    if(!assertionList){
      assertionList = document.createElement("ul");
    }
    var arrayLength = m.error.length;
    for (var i = 0; i < arrayLength; i++) {
      var liAdd = document.createElement("li");
      var testName = "<span class='testName'>" + m.error[i] + "</span> - ";
      liAdd.innerHTML = buildTestNameString(m.error[i]) + errorString(m.error[i]) + " - " + solutionString(m.error[i]);
      liAdd.dataset.test = m.error[i];
      assertionList.appendChild(liAdd);
    }
    if(m.targetPath){
      var sublist = document.createElement("ul");
      var li2 = document.createElement("li");
      var button = document.createElement('a');
      var buttonAtt = document.createAttribute('href');
      buttonAtt.value="#";
      button.setAttributeNode(buttonAtt);
      button.appendChild(document.createTextNode(m.targetHtml));
      button.addEventListener('click', showElement(m.targetPath,frameId,frameURL));
      button.addEventListener('mouseover', addHover(m.targetPath,frameId));
      button.addEventListener('mouseout', removeHover(m.targetPath,frameId));

      button.innerHTML = stylizedHTML(m.targetHtml);
      li2.appendChild(button);
      sublist.appendChild(li2);
      liAdd.appendChild(sublist);
    }

    li.appendChild(assertionList);
  }

  // warnings lists
  if(warnLength > 0){
    if(!assertionList){
      assertionList = document.createElement("ul");
    }
    var arrayLength = m.warn.length;
    for (var i = 0; i < arrayLength; i++) {
      var liAdd = document.createElement("li");
      var testName = "<span class='testName'>" + m.warn[i] + "</span> - ";
      liAdd.innerHTML = buildTestNameString(m.warn[i]) + warningString(m.warn[i]) + " - " + solutionString(m.warn[i]);
      liAdd.dataset.test = m.warn[i];
      assertionList.appendChild(liAdd);
      //ulWarnSub.appendChild(document.createElement("li")).appendChild(document.createTextNode(warningString(m.warn[i]) + " - " + solutionString(m.error[i])));
    }
      li.appendChild(assertionList);
    
//    ul.appendChild(li);
  }

  if(m.relatedNodes && m.relatedNodes.length){
      var sublist = document.createElement("ul");
      var liNodes = document.createElement("li");
      var liRelatedNodes = document.createElement("li");

      if(m.relatedNodes.length > 1){
        liRelatedNodes.innerHTML = "Related Nodes";
      } else {
        liRelatedNodes.innerHTML = "Related Node";
      }
      var listItemClass = document.createAttribute("class");
      listItemClass.value = "no-list-style";
      liNodes.setAttributeNode(listItemClass);


      m.relatedNodes.forEach(function(node){
        var li2 = document.createElement("li");
        var button = document.createElement('a');
        var buttonAtt = document.createAttribute('href');
        buttonAtt.value="#";
        button.setAttributeNode(buttonAtt);
        button.appendChild(document.createTextNode(node.targetHtml));
        button.addEventListener('click', showElement(node.targetPath,frameId,frameURL));
        button.addEventListener('mouseover', addHover(node.targetPath,frameId));
        button.addEventListener('mouseout', removeHover(node.targetPath,frameId));

        button.innerHTML = stylizedHTML(node.targetHtml);
        li2.appendChild(button);
        sublist.appendChild(li2);
      });
      liNodes.appendChild(sublist);    
      assertionList.appendChild(liRelatedNodes);
      assertionList.appendChild(liNodes);
  }

  // images
  if(m.hasOwnProperty("src")){
    if(m.src=="svg"){
      var pNode = document.createElement('p');
      pNode.innerHTML = '<div class="imgPreview">'+m.svg+'</div>';
      li.appendChild(pNode);
    } else if (m.src == 'area') {
      // do nothing
    } else {
      var pNode = document.createElement('p');
      var imgNode = document.createElement("img");
      var src = document.createAttribute('src');
      src.value=m.src;
      var imgCSS = document.createAttribute('class');
      imgCSS.value = 'imgPreview';
      imgNode.setAttributeNode(src);
      imgNode.setAttributeNode(imgCSS);
      pNode.appendChild(imgNode);
      li.appendChild(pNode);

    }
  }

  if(m.hiddenOverride){
    li.className += " hidden"
  }

    ul.appendChild(li);
    //iatCounter += 1;
}

function buildTestNameString(testName){
  var testName;
  switch(testName){
    case "autocompleteMissing":
    case "autocompleteOnInvalidControl":
    case "autocompleteValueIsMalformed":
      testName = "<span style='color: #EE0000; font-weight: bold;'>WCAG 2.1 </span><span class='testName'>" + testName + "</span> - ";
    break;
    default:
      testName = "<span class='testName'>" + testName + "</span> - ";
    break;
  }

  return testName;
}

function showElement(xpath, frameId, frameURL) {
  return function(){
    var script = "var nodes = document.evaluate(\"" + xpath + "\", document, null, XPathResult.ANY_TYPE, null);" +
                "var node = nodes.iterateNext();" +
                "if(node){" +
                "inspect(node);" +
                "}"
            chrome.devtools.inspectedWindow.eval(script, {frameURL:frameURL});
    }
}

function addHover(xpath, frameId) {
  return function(){
    chrome.runtime.sendMessage({
                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                code: "highlightElement('"+xpath+"')",
                frameId: frameId,
                command: "highlight" // get all of the frames
                })
    return false;
  }
}

function removeHover(xpath, frameId) {
  return function(){
    chrome.runtime.sendMessage({
                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                code: "unHighlightElement('"+xpath+"')",
                frameId: frameId,
                command: "highlight" // get all of the frames
                })
  }
}

function addErrors(ul, e) {
  var ol = document.getElementById(olID);
  var ulSub = document.createElement("ul");

  var arrayLength = e.length;
  for (var i = 0; i < arrayLength; i++) {
    ulSub.appendChild(document.createElement("li")).appendChild(document.createTextNode(e[0]));
  }
  ul.appendChild(ulSub);
}

function addClass(elem, c) {
  elem.className += " " + c;

}

function removeClass(elem, c) {
  var regex = new RegExp("(?:^|\\s)" + c + "(?!\\S)",'g');
  //console.log(regex)
  elem.className = elem.className.replace( regex , '' );

}

function toggleFilterIndividualItem(hidden, status){
    var show = true;
    if(!showHidden && hidden==true) {
      // if hidden element and user doesn't want to see hidden elements
      show = false; 
      //do nothing else
    } else if (!showHidden && hidden==false) {
      // if it is not a hidden element and user doesn't want to see hidden elements

      // perform checks for errors and warnings
      if((showErrors && status=='ERR') || showWarnings && status=='WARN') {
        // if show errors and it is an error, or if show warning and is a warning
        show = true;
      } else if (!showErrors && !showWarnings) {
        // if the user has not checked either errors or warnings
        show = true;
      } else {
        show = false;
      }

    } else if (showHidden) {
      // if user wants to see hidden elements
      show = true;
      // perform checks for errors and warnings
      if((showErrors && status=='ERR') || showWarnings && status=='WARN') {
        // if show errors and it is an error, or if show warning and is a warning
        show = true;
      } else if (!showErrors && !showWarnings) {
        // if the user has not checked either errors or warnings
        show = true;
      } else {
        show = false;
      }

    }

    return show;

}

function toggleFilters(filter){
  var elements = document.querySelectorAll('[data-hidden],[data-status]');
  var show = false;

  for(var i = 0; i < elements.length; i++) {
    show = toggleFilterIndividualItem((elements[i].dataset.hidden=='true'?true:false), elements[i].dataset.status);

    if(show){
      removeClass(elements[i],'hide');
    } else {
      addClass(elements[i],'hide');
    }

  }

  var showErrors1 = document.getElementById("showErrors").checked;
  var showWarnings1 = document.getElementById("showWarnings").checked;

  if(!showErrors1 && !showWarnings1){
    showErrors1 = true;
    showWarnings1 = true;
  }
  var rows = document.querySelectorAll('#testTableBody > tr');
  for(var i = 0; i < rows.length; i++){
    if(showErrors1 && showWarnings1){
      removeClass(rows[i], 'hide');
    } else {
      var numErrors = parseInt(rows[i].dataset.errorCount);
      var numWarnings = parseInt(rows[i].dataset.warningCount);
      if((!showWarnings1 && !numErrors) || (!showErrors1 && !numWarnings)){
        addClass(rows[i], 'hide');
      } else {
        removeClass(rows[i], 'hide');
      }
    }
  }

  var speechOutput = "filter " + (filter.checked ? "applied" : "removed");
  updateSpeechOutput(speechOutput);
}


function toggleHidden(){
  var hiddenElements = document.querySelectorAll('[data-hidden="true"]');
  for(var i = 0; i < hiddenElements.length; i++) {
    if(showHidden) {
      removeClass(hiddenElements[i],'hide');
    } else {
      addClass(hiddenElements[i],'hide')
    }
  }
}

function toggleErrors(){
  var hiddenElements = document.querySelectorAll('[data-status="OK"]');
  for(var i = 0; i < hiddenElements.length; i++) {
    if(showHidden) {
      removeClass(hiddenElements[i],'hide');
    } else {
      addClass(hiddenElements[i],'hide')
    }
  }
}

function toggleWarnings(){
  var hiddenElements = document.querySelectorAll('[data-status="WARN"]');
  for(var i = 0; i < hiddenElements.length; i++) {
    if(showHidden) {
      removeClass(hiddenElements[i],'hide');
    } else {
      addClass(hiddenElements[i],'hide')
    }
  }
}

function showw3CFilterButton(url){
  var button = document.getElementById("filterValidator");
  if(url.indexOf("https://validator.w3.org/nu") == 0 || url.indexOf("http://validator.w3.org/nu") == 0){
    removeClass(button, "hide");
  } else {
    addClass(button, "hide");
  }
}

function toggleTestFilters(button){
  return function(){
    var row = button.parentElement.parentElement;
    var test = row.dataset.testName;
    var index = testFilters.indexOf(test);
    if(index != -1){
      testFilters.splice(index, 1);
      var rows = document.querySelectorAll("[data-test='" + test + "']");
      for(var i = 0; i < rows.length; i++){
        addClass(rows[i], 'hide');
        var list = rows[i].parentElement;
        var listItemsCount = list.children.length;
        var hiddenListItemsCount = list.querySelectorAll("li.hide").length;
        if(hiddenListItemsCount === listItemsCount){
          var itemEntry = list.parentElement;
          addClass(itemEntry, 'hide');
        }
      }
      removeClass(button.firstChild, 'fa');
      removeClass(button.firstChild, 'fa-check');
      button.setAttribute("aria-pressed", "false");
    } else {
      testFilters.push(test);
      var rows = document.querySelectorAll("[data-test='" + test + "']");
      for(var i = 0; i < rows.length; i++){
        removeClass(rows[i], 'hide');
        var itemEntry = rows[i].parentElement.parentElement;
        removeClass(itemEntry, 'hide');
      }    
      var testCell = row.firstChild.firstChild;
      addClass(button.firstChild, 'fa');
      addClass(button.firstChild, 'fa-check');
      button.setAttribute("aria-pressed", "true");
    }
  }
}

function performTest(test){
  return function(){
    var button = document.querySelector("[data-test='" + test + "']");
    button.focus();
    button.click();
  }
}

function updateSpeechOutput(text){
  var el = document.querySelector('#speechOutput');
  if(el){
    el.remove();
  }
  el = document.createElement("span");
  el.setAttribute("role", "alert");
  el.setAttribute("aria-live", "assertive");
  el.setAttribute("class", "visually-hidden");
  document.body.appendChild(el);
  el.innerHTML = text;
}