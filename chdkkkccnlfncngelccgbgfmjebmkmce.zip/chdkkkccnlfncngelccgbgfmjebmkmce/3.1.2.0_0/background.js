var tabs = [];
var connections = [];
var zooms = [];

chrome.runtime.onConnect.addListener(function(port){
    var toolkitPanelListener = function(message, sender, sendResponse){
        if(message.message === 'init'){
            connections[message.tabId] = sender;
        } else if(message.message === 'updateActiveTests'){
            if(message.task === 'on' || message.task === 'off'){
                if(typeof tabs[message.tabId] === 'undefined'){
                    tabs[message.tabId] = [];
                }
                var index = tabs[message.tabId].indexOf(message.test);
                if(index !== -1){
                    tabs[message.tabId].splice(index, 1);
                } else {
                    tabs[message.tabId].push(message.test);
                }
            }
        }
    };
    port.onMessage.addListener(toolkitPanelListener);

    port.onDisconnect.addListener(function(port){
        port.onMessage.removeListener(toolkitPanelListener);

        var cons = Object.keys(connections);
        var length = cons.length;
        for(var i = 0; i < length; i++){
            if(connections[cons[i]] == port){
                if(typeof tabs[cons[i]] !== 'undefined'){
                    tabs[cons[i]].forEach((test) =>{
                        chrome.tabs.executeScript(parseInt(cons[i]), {code: "ia11yVars."+test+"({task: 'off'})", allFrames: true});
                    });
                    tabs[cons[i]] = [];
                }
                if(zooms[cons[i]]){
                    var zoomInfo = zooms[cons[i]];
                    var options = {}
                    options.width = zoomInfo.width;
                    options.height = zoomInfo.height;

                    chrome.windows.get(zooms[cons[i]].windowId, function(window){
                        chrome.windows.update(window.id, options, function(window){
                            chrome.tabs.setZoom(cons[i], zoomInfo.zoom, function(){
                                delete zooms[cons[i]];
                            });
                        });
                    });
                }

                delete connections[cons[i]];
            }
        }
    });
});

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {

        // from extension
        if(request.command == 'insert'){
            
            chrome.tabs.executeScript(request.tabId,
                {file: request.file},
                sendResponse);
        } else if (request.command == 'getFrames') {    

            chrome.webNavigation.getAllFrames({
                    tabId: request.tabId
            }, function(response) {
                //console.log(response);
                sendResponse(response);
            });

        } else if (request.command == 'count' || request.command == 'on' || request.command == 'off') {


            chrome.tabs.sendMessage(request.tabId,{
                test: request.test,
                command: request.command
            }, function(response) {
                sendResponse(response);
            });

        } else if (request.command == 'fallback'){
            chrome.tabs.executeScript( request.tabId, {code:request.code, frameId: request.frameId}, function(response){ //matchAboutBlank: true
                sendResponse(typeof response === 'undefined' ? undefined : response[0]); // response comes back as an object within an array with .executeScript, as opposed to just the object with .eval
            } )
        } else if (request.command == 'highlight'){
            chrome.tabs.executeScript( request.tabId, {code: request.code, frameId: request.frameId}) //matchAboutBlank: true
        } else if (request.command == 'toolLoaded'){
            chrome.tabs.executeScript( request.tabId, {code:request.code}, function(response){ //matchAboutBlank: true
                sendResponse(response[0]); // response comes back as an object within an array with .executeScript, as opposed to just the object with .eval
            } )
        } else if (request.command == 'loadTool'){
            chrome.tabs.executeScript( request.tabId, {file:'js/iatoolkit.min.js', allFrames:true}, function(response){ //matchAboutBlank: true
                sendResponse(response[0]); // response comes back as an object within an array with .executeScript, as opposed to just the object with .eval
            } )
        } else if(request.command == "getURL"){
            chrome.tabs.get( request.tabId, function(tab){
                sendResponse({url: tab.url});
            });
        } else if (request.command === 'resize'){
            chrome.tabs.get(request.tabId, function(tab){
                chrome.windows.get(tab.windowId, function(window){
                    var currentWidth, currentHeight;

                    currentWidth = window.width;
                    currentHeight = window.height;

                    var desiredWidth = request.size.restore ? request.size.width : (window.width - tab.width + request.size.width);
                    var desiredHeight = request.size.restore ? request.size.height : (window.height - tab.height + request.size.height);

                    var options = {}
                    if(desiredWidth){
                        options.width = desiredWidth;
                    }
                    if(desiredHeight){
                        options.height = desiredHeight;
                    }
                    chrome.windows.update(window.id, options, function(window){
                        chrome.tabs.getZoom(request.tabId, function(currentZoom){
                            chrome.tabs.setZoom(request.tabId, request.size.zoom, function(){
                                if(request.size.restore){
                                    delete zooms[request.tabId];
                                }
                                else {
                                    zooms[request.tabId] = {};
                                    zooms[request.tabId].width = currentWidth;
                                    zooms[request.tabId].height = currentHeight;
                                    zooms[request.tabId].zoom = currentZoom;
                                    zooms[request.tabId].windowId = tab.windowId;
                                }
                                sendResponse({width: currentWidth, height: currentHeight, zoom: currentZoom});
                            });
                        });
                    });
                });
            });
        }

        return true;
    //}
    
});

