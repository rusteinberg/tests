// create the main panel
chrome.devtools.panels.create(chrome.i18n.getMessage('extensionTitle'), null, "panel.html");

// create the side panel for the Elements panel
chrome.devtools.panels.elements.createSidebarPane(chrome.i18n.getMessage('sidepanelTitle'),
    function(sidebar) {
        sidebar.setPage('side-panel.html');
});
