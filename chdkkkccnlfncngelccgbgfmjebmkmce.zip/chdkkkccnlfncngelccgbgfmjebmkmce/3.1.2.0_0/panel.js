var nodeLimiter = false;
var showHidden = false;
var showErrors = false;
var showWarnings = false;
var iatCounter = 0;

var issueTotals = {}; // hold all of the result totals for the tests

var nodeLimiter = {
    on: false,
    frameId: 0,
    frameURL: null,
    nodePath: null
}

/* send init message to background page */
var backgroundConnection = chrome.runtime.connect({name: "iatoolkit"});
backgroundConnection.postMessage({message: "init", tabId: chrome.devtools.inspectedWindow.tabId});
var originalSize = {
    width: 0,
    height: 0,
    zoom: 0
};

/*
** Attach events to buttons
*/

document.getElementById('runTests').addEventListener('click', function() {
    runTests();
}, false);

document.getElementById('ia11yForms').addEventListener('click', function() {
    toggleToolButtons(this);

}, false);

document.getElementById('ia11yHeadings').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yLandmarks').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yAccessKeys').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yTables').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yLists').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yTitles').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yTextFormatting').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yPageInfo').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yAriaUI').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yAriaLive').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yAriaUsage').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yTabindex').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yBackgroundImages').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yImages').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yPseudoContent').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yInternalLinks').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yTabOrder').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yRichMedia').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yEmptyP').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yFrames').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yAriaHidden').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yContrast').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yLinks').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yLanguages').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yButtons').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

document.getElementById('ia11yIds').addEventListener('click', function() {
    toggleToolButtons(this);
}, false);

function validatorURL(){
    chrome.devtools.inspectedWindow.eval("sendURLToValidator()",{ useContentScriptContext: true });
}
document.getElementById('validatorURL').addEventListener('click', function() {
    runTest(validatorURL);        
}, false);

function validatorDOM(){
    chrome.devtools.inspectedWindow.eval("sendSelectionToValidator()",{ useContentScriptContext: true });
}
document.getElementById('validatorDOM').addEventListener('click', function() {
    runTest(validatorDOM);        
}, false);

function filterValidator(){
    chrome.devtools.inspectedWindow.eval("filterValidator()",{ useContentScriptContext: true })
}
document.getElementById('filterValidator').addEventListener('click', function() {
    runTest(filterValidator);    
}, false);

document.getElementById('ia11yFocusTrack').addEventListener('click', function() {
    toggleFocusShow(this.checked);
}, false);

document.getElementById('ia11yReflow').addEventListener('click', function() {
    toggleReflowShow(this.checked);
}, false);
document.getElementById('reflowlink').addEventListener('click', function(event){
    chrome.tabs.create({url: "https://www.w3.org/WAI/WCAG21/Understanding/reflow.html"});
}, false);

document.getElementById('ia11yTextSpacing').addEventListener('click', function() {
    toggleTextSpacing(this.checked);
}, false);
document.getElementById('textspacinglink').addEventListener('click', function(){
    chrome.tabs.create({url: "https://www.w3.org/WAI/WCAG21/Understanding/text-spacing.html"});
}, false);

document.getElementById('showHidden').addEventListener('click', function() {
    if(this.checked) {
        showHidden = true;
    } else {
        showHidden = false;
    }
    toggleFilters(this);
}, false);

document.getElementById('showErrors').addEventListener('click', function() {
    if(this.checked) {
        showErrors = true;
    } else {
        showErrors = false;
    }
    toggleFilters(this);
}, false);

document.getElementById('showWarnings').addEventListener('click', function() {
    if(this.checked) {
        showWarnings = true;
    } else {
        showWarnings = false;
    }
    toggleFilters(this);
}, false);

document.getElementById('ia11yNodeLimiter').addEventListener('click', function() {

    clearResultsNotes();
    emptyResults('results'); 
    clearAllNumbers();

    if(this.checked) {
        nodeLimiter.on = true;
    
        // load the toolkit
        chrome.runtime.sendMessage({
            tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
            code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
            command: "toolLoaded"
            },function(response){
                if(response){
                    // tool is loaded
                    getCurrentNode();
                } else {
                    // tool needs to be loaded
                   chrome.runtime.sendMessage({
                        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                        command: "loadTool"
                        },function(response){
                            getCurrentNode();
                    });   
                }
        });   
    } else {
        nodeLimiter.on = false;
    }
}, false);

document.getElementById('ia11yTestTotals').addEventListener('click', function(){
    var container = document.getElementById('testTotalsTableContainer');
    if(container.classList.contains('hide')){
        removeClass(container, "hide");
        addClass(document.getElementById('testTableContainer'), 'hide');

        //clear all other buttons
        var buttons = document.getElementsByClassName("toolToggleButton");
        for(var j = 0; j < buttons.length; j++) {
            if(buttons.item(j).getAttribute('aria-pressed')=="true"){
                toggleToolButtons(buttons.item(j));
            }
        }
    }
    if(!document.getElementById("testTotalsTableBody").hasChildNodes()){
        runTests();
    }
    addClass(document.getElementById('resultsHeader'), "hide");
});

function getCurrentNode(){
    // get the current node

    chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        command: "getFrames" // get all of the frames
    }, function(response) { // callback once we have all of the frames
        var arrayLength = response.length; // the number of frames

        // loop through the frames
        for (var i = 0; i < arrayLength; i++) {
            var url = response[i].url;
            if(url.indexOf('#') >= 0){
                url = url.substring(0,url.indexOf('#'));
            }
            // send JS command to turn the tool on
                
            if (url != "about:blank") {
                chrome.devtools.inspectedWindow.eval(
                    "ia11yVars.getCurrentlySelected({nodeLimiter: "+nodeLimiter.on+", frameId: "+response[i].frameId+", frameURL: '"+response[i].url+"'})",
                    { frameURL: url, useContentScriptContext: true},
                    function(response){ // callback from when the test is done
                        if(!response){
                            return true;
                        }
                        if(response.frameURL === response.location){
                            addResultsNotes('resultsNotes', response);    
                            nodeLimiter.frameId = response.frameId;
                            if(response.frameURL.indexOf('#') >= 0){
                                nodeLimiter.frameURL = response.frameURL.substring(0, response.frameURL.indexOf('#'));
                            } else {
                                nodeLimiter.frameURL = response.frameURL;;
                            }
                            nodeLimiter.on = true;
                            nodeLimiter.nodePath = response.scopePath;
                        }
                    }
                );
            }
        }
    });    
}

function clearNodeLimiter() {
    document.getElementById('ia11yNodeLimiter').checked=false;
    nodeLimiter.on = false;
    nodeLimiter.frameURL = null;
    nodeLimiter.frameId = 0;

}


function runTests(){
    addClass(document.getElementById('resultsHeader'), "hide");
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                runTestsToolLoaded();
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        runTestsToolLoaded();
                });   
            }
    });   
}

function runTestsToolLoaded() {

  var buttons;

    chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        command: "getFrames" // get all of the frames
    }, function(response) { // callback once we have all of the frames
        var arrayLength = response.length; // the number of frames
        
        buttons = document.getElementsByClassName("toolToggleButton");
        var test;
                        var url;
                var parentFrameId;
                var frameId;

        var q = queue();
        var hasError = false;

        resetTotals("totals");
        emptyResults('results');
        emptyResults('testTableBody')

        // turn off any running tests
        for(var j = 0; j < buttons.length; j++){
            // clear current test
            if(buttons.item(j).getAttribute('aria-pressed')=="true") {
                test = document.getElementById(buttons.item(j).id).dataset.test; // the test ID to run (based on data-test attribute on the <button>)

                backgroundConnection.postMessage({
                    message: "updateActiveTests", 
                    tabId: chrome.devtools.inspectedWindow.tabId,
                    task: "off",
                    test: test
                });

                for (var i = 0; i < arrayLength; i++) {
                    parentFrameId = response[i].parentFrameId;
                    frameId = response[i].frameId
                    url = response[i].url;

                    if(url.indexOf('#') >= 0){
                        url = url.substring(0,url.indexOf('#'));
                    }
                    // send JS command to turn the tool on
                    
                    if (url != "about:blank") {
                        chrome.devtools.inspectedWindow.eval(
                            "ia11yVars."+test+"({task: 'off',parentFrameId:"+parentFrameId+"})",
                            { frameURL: url, useContentScriptContext: true},
                            function(response){ // callback from when the test is done

                                if(typeof response != 'undefined'){
                                } else {

                                chrome.runtime.sendMessage({
                                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                                    code: "ia11yVars."+test+"({task: 'off',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                                    frameId: frameId,
                                    command: "fallback" // get all of the frames
                                    },function(response){
                                    });

                                }

                            }
                        );
                    }
                }
                buttons.item(j).setAttribute('aria-pressed','false');
                removeClass(document.getElementById(buttons.item(j).id).childNodes[0], "fa");
                removeClass(document.getElementById(buttons.item(j).id).childNodes[0], "fa-check");
            }
        }


        // get the count of assertions for each test
        for(var j = 0; j < buttons.length; j++){
            test = document.getElementById(buttons.item(j).id).dataset.test; // the test ID to run (based on data-test attribute on the <button>)
            
            resetTotals(test);
            clearNumbers(test);
            // delete the old totals before rerunning the test

            if(nodeLimiter.on){
                q.queue(function(res, rej){
                    // var timer = setTimeout(function(){
                    //     hasError = true;
                    //     return res();
                    // }, 10000);
                    var timer = 0;
                    countEval(test, parentFrameId,nodeLimiter,url,nodeLimiter.frameId, nodeLimiter.frameURL, function(){
                        clearTimeout(timer);
                        return res();
                    });
                });
            } else {
                // loop through the frames
                for (var i = 0; i < arrayLength; i++) {
                    // send JS command to turn the tool on
                        parentFrameId = response[i].parentFrameId;
                        frameId = response[i].frameId
                        url = response[i].url;

                        if(url.indexOf('#') >= 0){
                            url = url.substring(0,url.indexOf('#'));
                        }
                        frameURL = url;
                        // send JS command to turn the tool on

                        // countEval(test, parentFrameId,nodeLimiter,url,frameId, frameURL);
                        q.queue(function(res, rej){
                            // var timer = setTimeout(function(){
                            //     hasError = true;
                            //     return res();
                            // }, 10000);
                            var timer = 0;                    
                            countEval(test, parentFrameId,nodeLimiter,url,frameId, frameURL, function(){
                                clearTimeout(timer);
                                return res();
                            });
                        });
                }
            }
        }
        q.wait(function(){
            updateTestTable("");
        });
    });

}



function displayResults(results,frameId, frameURL) {
    addToTotals(results,true);
    writeNumbers(results.test,true);
    if(results.data.length == 0 ){
        // has no data to display
    } else {
        // has data to display

        if(results.scope){
            addResultsNotes('resultsNotes', results);
        }
iatCounter = 0;
        var arrayLength = results.data.length;
        for (var i = 0; i < arrayLength; i++) {
            addResult('results',results.data[i],frameId, frameURL);
        }
    }
}


function runTest(f){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                f();
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        f();
                });   
            }
    });   

}


function toggleFocusShow(show){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                toggleFocusShowToolLoaded(show)
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        toggleFocusShowToolLoaded(show)
                });   
            }
    });   

}

function toggleFocusShowToolLoaded(show){
    


    //clear all other buttons
    chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        command: "getFrames" // get all of the frames
    }, function(response) { // callback once we have all of the frames
        var arrayLength = response.length; // the number of frames
        var test = "focusTrack";
        var url;
        var parentFrameId;
        var frameId;
        var j = 1;
        if(!show){

            backgroundConnection.postMessage({
                message: "updateActiveTests", 
                tabId: chrome.devtools.inspectedWindow.tabId,
                task: "off",
                test: test
            });

            // loop through the frames
            for (var i = 0; i < arrayLength; i++) {
                parentFrameId = response[i].parentFrameId;
                frameId = response[i].frameId
                url = response[i].url;

                if(url.indexOf('#') >= 0){
                    url = url.substring(0,url.indexOf('#'));
                }
                // send JS command to turn the tool on
                    
                if (url != "about:blank") {
                    
                chrome.devtools.inspectedWindow.eval(
                    "ia11yVars.focusTrack({task: 'off',parentFrameId:"+parentFrameId+"})",
                    { frameURL: url, useContentScriptContext: true},
                    function(response){ // callback from when the test is done

                    if(typeof response != 'undefined'){
                    } else {
                        chrome.runtime.sendMessage({
                            tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                            code: "ia11yVars."+test+"({task: 'off',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                            frameId: frameId,
                            command: "fallback" // get all of the frames
                        },function(response){

                        });

                    }

                    }
                );
                } else {

                }

            }
        } else {
            chrome.runtime.sendMessage({
                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                command: "getFrames" // get all of the frames
            }, function(response) { // callback once we have all of the frames
                var arrayLength = response.length; // the number of frames
                var url;
                var parentFrameId;
                var frameId;
                var test = "focusTrack";
                // delete the old totals before rerunning the test
                
                if(nodeLimiter.on){
                    onEval(test,parentFrameId,nodeLimiter,url,nodeLimiter.frameId, nodeLimiter.frameURL,false);
                } else {
                    // loop through the frames
                    for (var i = 0; i < arrayLength; i++) {
                        parentFrameId = response[i].parentFrameId;
                        frameId = response[i].frameId
                        url = response[i].url;
                        
                        if(url.indexOf('#') >= 0){
                            url = url.substring(0,url.indexOf('#'));
                        }
                        frameURL = url;
                        // send JS command to turn the tool on
                        
                        if (url != "about:blank") {
                            onEval(test,parentFrameId,nodeLimiter,url,frameId, frameURL,false);
                        } else {
                            //console.log('g1')
                            addResultsNotesText('resultsNotes', 'Some iframes could not be analyzed');
                        }
                    }
                }
            });
        }
    });
}






function toggleTextSpacing(show){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                toggleTextSpacingToolLoaded(show);
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        toggleTextSpacingToolLoaded(show);
                });   
            }
    });   

}

function toggleTextSpacingToolLoaded(show){
    


    //clear all other buttons
    chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        command: "getFrames" // get all of the frames
    }, function(response) { // callback once we have all of the frames
        var arrayLength = response.length; // the number of frames
        var test = 'textSpacing';
        var url;
        var parentFrameId;
        var frameId;
        var j = 1;
        if(!show){
            // loop through the frames
            for (var i = 0; i < arrayLength; i++) {
                parentFrameId = response[i].parentFrameId;
                frameId = response[i].frameId
                url = response[i].url;

                if(url.indexOf('#') >= 0){
                    url = url.substring(0,url.indexOf('#'));
                }
                // send JS command to turn the tool on
                    
                if (url != "about:blank") {
                    
                chrome.devtools.inspectedWindow.eval(
                    "ia11yVars." + test + "({task: 'off',parentFrameId:"+parentFrameId+"})",
                    { frameURL: url, useContentScriptContext: true},
                    function(response){ // callback from when the test is done

                    if(typeof response != 'undefined'){
                    } else {
                        chrome.runtime.sendMessage({
                            tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                            code: "ia11yVars."+test+"({task: 'off',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                            frameId: frameId,
                            command: "fallback" // get all of the frames
                        },function(response){

                        });

                    }

                    }
                );
                } else {

                }

            }
        } else {
            chrome.runtime.sendMessage({
                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                command: "getFrames" // get all of the frames
            }, function(response) { // callback once we have all of the frames
                var arrayLength = response.length; // the number of frames
                var url;
                var parentFrameId;
                var frameId;
                // delete the old totals before rerunning the test
                
                if(nodeLimiter.on){
                    onEval(test,parentFrameId,nodeLimiter,url,nodeLimiter.frameId, nodeLimiter.frameURL,false);
                } else {
                    // loop through the frames
                    for (var i = 0; i < arrayLength; i++) {
                        parentFrameId = response[i].parentFrameId;
                        frameId = response[i].frameId
                        url = response[i].url;
                        
                        if(url.indexOf('#') >= 0){
                            url = url.substring(0,url.indexOf('#'));
                        }
                        frameURL = url;
                        // send JS command to turn the tool on
                        
                        if (url != "about:blank") {
                            onEval(test,parentFrameId,nodeLimiter,url,frameId, frameURL,false);
                        } else {
                            //console.log('g1')
                            addResultsNotesText('resultsNotes', 'Some iframes could not be analyzed');
                        }
                    }
                }
            });
        }
    });
}

function toggleReflowShow(on){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                toggleReflow(on);
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        toggleReflow(on);
                });   
            }
    });   

}

function toggleReflow(on){
    var size = {};
    if(on){
        size.width = 1280;
        size.height = 1024;
        size.zoom = 4.0;
    } else {
        size.width = originalSize.width;
        size.height = originalSize.height;
        size.zoom = originalSize.zoom;
        size.restore = true;
    }
    chrome.runtime.sendMessage({tabId: chrome.devtools.inspectedWindow.tabId, command: "resize", size: size}, function(response){
        if(on){
            originalSize.width = response.width;
            originalSize.height = response.height;
            originalSize.zoom = response.zoom;
        }
    });
}

function toggleToolButtons(elem){
   chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        code: "if(typeof ia11yVars == 'undefined'){results = false;}else{results = true;}",
        command: "toolLoaded"
        },function(response){
            if(response){
                // tool is loaded
                toggleToolButtonsToolLoaded(elem)
            } else {
                // tool needs to be loaded
               chrome.runtime.sendMessage({
                    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                    command: "loadTool"
                    },function(response){
                        toggleToolButtonsToolLoaded(elem)
                });   
            }
    });   

}

function toggleToolButtonsToolLoaded(elem) {

  var checkedAlready = false;
  //check if already pressed
  if(elem.getAttribute('aria-pressed')=="true") {
    checkedAlready = true;
    addClass(document.getElementById('resultsHeader'), "hide");
    addClass(document.getElementById('testTableContainer'), "hide");
  } else {
    removeClass(document.getElementById('resultsHeader'), "hide");
    removeClass(document.getElementById('testTableContainer'), "hide");
  }

  //clear all other buttons
  var buttons = document.getElementsByClassName("toolToggleButton");
    chrome.runtime.sendMessage({
        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
        command: "getFrames" // get all of the frames
    }, function(response) { // callback once we have all of the frames
        var arrayLength = response.length; // the number of frames
        var test;
                var url;
                var parentFrameId;
                var frameId;
        for(var j = 0; j < buttons.length; j++) {
            if(buttons.item(j).getAttribute('aria-pressed')=="true"){
                test = document.getElementById(buttons.item(j).id).dataset.test; // the test ID to run (based on data-test attribute on the <button>)


                backgroundConnection.postMessage({
                    message: "updateActiveTests", 
                    tabId: chrome.devtools.inspectedWindow.tabId,
                    task: "off",
                    test: test
                });

                // loop through the frames
                for (var i = 0; i < arrayLength; i++) {
                                parentFrameId = response[i].parentFrameId;
                    frameId = response[i].frameId
                    url = response[i].url;

                    if(url.indexOf('#') >= 0){
                        url = url.substring(0,url.indexOf('#'));
                    }
                    // send JS command to turn the tool on
                    
                    if (url != "about:blank") {
                    
                    chrome.devtools.inspectedWindow.eval(
                        "ia11yVars."+test+"({task: 'off',parentFrameId:"+parentFrameId+"})",
                        { frameURL: url, useContentScriptContext: true},
                        function(response){ // callback from when the test is done

                            if(typeof response != 'undefined'){

                            } else {

                            chrome.runtime.sendMessage({
                                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                                code: "ia11yVars."+test+"({task: 'off',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                                frameId: frameId,
                                command: "fallback" // get all of the frames
                                },function(response){

                                });

                            }

                        }
                    );
                    } else {
                        //console.log('g2')
                        addResultsNotesText('resultsNotes', 'Some iframes could not be analyzed');
                    }

                }
                buttons.item(j).setAttribute('aria-pressed','false');

                removeClass(document.getElementById(buttons.item(j).id).childNodes[0], "fa");
                removeClass(document.getElementById(buttons.item(j).id).childNodes[0], "fa-check");

            }
        }
        //clear the results
        emptyResults('results');
        emptyResults('testTableBody')

        //if not previously checked, then check it
        if(!checkedAlready) {
            elem.setAttribute('aria-pressed','true');
            addClass(document.getElementById(elem.id).childNodes[0], "fa");
            addClass(document.getElementById(elem.id).childNodes[0], "fa-check");
            var hasError = false;

            
            resetTotals(document.getElementById(elem.id).dataset.test);

            chrome.runtime.sendMessage({
                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                command: "getFrames" // get all of the frames
            }, function(response) { // callback once we have all of the frames
                var arrayLength = response.length; // the number of frames
                var test = document.getElementById(elem.id).dataset.test; // the test ID to run (based on data-test attribute on the <button>)
                var url;
                var parentFrameId;
                var frameId;

                // delete the old totals before rerunning the test
                var q = queue();
                
                if(nodeLimiter.on){
                    q.queue(function(res, rej){
                        // var timer = setTimeout(function(){
                        //     hasError = true;
                        //     return res();
                        // }, 10000);
                        var timer = 0;
                        onEval(test,parentFrameId,nodeLimiter,url,nodeLimiter.frameId, nodeLimiter.frameURL,true,function(){
                            clearTimeout(timer);
                            return res();
                        });
                    });
                } else  {
                    // loop through the frames
                    for (var i = 0; i < arrayLength; i++) {
                        parentFrameId = response[i].parentFrameId;
                        frameId = response[i].frameId;
                        url = response[i].url;
                        
                        if(url.indexOf('#') >= 0){
                            url = url.substring(0,url.indexOf('#'));
                        }
                        frameURL = url;
                        // send JS command to turn the tool on
                        
                        if (url != "about:blank") {
                            q.queue(function(res, req){
                                // var timer = setTimeout(function(){
                                //     hasError = true;
                                //     return res();
                                // }, 10000);
                                var timer = 0;
                                onEval(test,parentFrameId,nodeLimiter,url,frameId, frameURL,true,function(){
                                    clearTimeout(timer);
                                    return res();
                                });
                            });
                        } else {
                            //console.log(url)
                            //console.log('g3')
                            addResultsNotesText('resultsNotes', 'Some iframes could not be analyzed');
                        }
                    }
                }
                q.wait(function(){
                    updateTestTable(test);
                });                
            });
        }
    });
}

// had to make this a separate function so the variables would be preserved through the asynch calls
function countEval(test,parentFrameId,nodeLimiter,url,frameId, frameURL, callback){

    if (url != "about:blank") {
        // if there's a node limiter, make sure to run the code in the correct frame
        if(nodeLimiter.on){
            chrome.runtime.sendMessage({
                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                code: "ia11yVars."+test+"({task: 'count',frameURL:'"+frameURL+"',parentFrameId:"+parentFrameId+",nodeLimiter: "+nodeLimiter.on+
                ",nodePath: '"+nodeLimiter.nodePath+"'})",
                frameId: frameId,
                command: "fallback" // get all of the frames
                },function(response2){
                    if(response2){
                        addToTotals(response2);
                        writeNumbers(response2.test);
                    }
                    if(callback){
                        callback();
                    }
                    return;
                });
        } else {
            // atempt to run with eval so $0 can be accessed
            chrome.devtools.inspectedWindow.eval(
                "ia11yVars."+test+"({task: 'count',frameURL:'"+frameURL+"',parentFrameId:"+parentFrameId+",nodeLimiter: "+nodeLimiter.on+
                ",nodePath: '"+nodeLimiter.nodePath+"'})",
                { frameURL: url, useContentScriptContext: true},
                function(response){ // callback from when the test is done
                    if(typeof response != 'undefined'){
                        if(response){
                            addToTotals(response);
                            writeNumbers(response.test);
                        }
                        if(callback){
                            callback();
                        }
                        return;
                    } else {
                        chrome.runtime.sendMessage({
                            tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                            code: "ia11yVars."+test+"({task: 'count',frameURL:'"+frameURL+"',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                            frameId: frameId,
                            command: "fallback" // get all of the frames
                            },function(response2){     
                                if(response2){
                                    addToTotals(response2);
                                    writeNumbers(response2.test);         
                                }
                                if(callback){
                                    callback();
                                }
                                return;
                            });
                    }
                }
            );
        }
    } else {
        //console.log('g4')
        addResultsNotesText('resultsNotes', 'Some iframes could not be analyzed');
        if(callback){
            callback();
        }
        return;
    }
}

function onEval(test,parentFrameId,nodeLimiter,url,frameId, frameURL, showResults, callback) {
    if(nodeLimiter.on || parentFrameId === -1){
        backgroundConnection.postMessage({
            message: "updateActiveTests", 
            tabId: chrome.devtools.inspectedWindow.tabId,
            task: "on",
            test: test
        });
    }

    // if there's a node limiter, make sure to run the code in the correct frame
    if(nodeLimiter.on){
        chrome.runtime.sendMessage({
            tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
            code: "ia11yVars."+test+"({task: 'on',frameURL:'"+frameURL+"',parentFrameId:"+parentFrameId+",nodeLimiter: "+nodeLimiter.on+
            ",nodePath: '"+nodeLimiter.nodePath+"'})",
            frameId: frameId,
            command: "fallback" // get all of the frames
            },function(response){
                if(showResults){
                    if(response){
                        displayResults(response, frameId, frameURL);
                    }
                    if(callback){
                        callback();
                    }
                }
                return;
            });
    } else {
        // atempt to run with eval so $0 can be accessed
        chrome.devtools.inspectedWindow.eval(
            "ia11yVars."+test+"({task: 'on',frameURL:'"+frameURL+"',parentFrameId:"+parentFrameId+", nodeLimiter: "+nodeLimiter.on+
            ",nodePath: '"+nodeLimiter.nodePath+"'})",
            { frameURL: url, useContentScriptContext: true},
            function(response){ // callback from when the test is done
                if(typeof response != 'undefined'){
                    if(showResults){
                        if(response){
                            displayResults(response, frameId, frameURL);
                        }
                        if(callback){
                            callback();
                        }
                    }
                    return;
                } else {
                    // fall back to executeScript
                    chrome.runtime.sendMessage({
                        tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                        code: "ia11yVars."+test+"({task: 'on',frameURL:'"+frameURL+"',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                        frameId: frameId,
                        command: "fallback" // get all of the frames
                        },function(response){
                            if(showResults){
                                if(response){
                                    displayResults(response, frameId, frameURL);
                                }
                                if(callback){
                                    callback();
                                }
                            }
                            return;
                        });
                }
            }
        );
    }

}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
});

function clearResultsNotes(){
    document.getElementById('resultsNotes').innerHTML = '';
}

function clearAllNumbers(){
    var buttons = document.getElementsByClassName("toolToggleButton");
    var test, currentTest;
    for(var j = 0; j < buttons.length; j++) {
        test = document.getElementById(buttons.item(j).id).dataset.test;
        clearNumbers(test);
        
        if(buttons.item(j).getAttribute("aria-pressed") == 'true'){
            currentTest = test;
        }

        buttons.item(j).setAttribute('aria-pressed','false');
        removeClass(document.getElementById(buttons.item(j).id).childNodes[0], "fa");
        removeClass(document.getElementById(buttons.item(j).id).childNodes[0], "fa-check");
    }
    clearTotals();
    if(typeof currentTest != 'undefined'){
        backgroundConnection.postMessage({
            message: "updateActiveTests", 
            tabId: chrome.devtools.inspectedWindow.tabId,
            task: "off",
            test: currentTest
        });

        
        chrome.runtime.sendMessage({
            tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
            command: "getFrames" // get all of the frames
        }, function(response) { // callback once we have all of the frames
            var arrayLength = response.length; // the number of frames
            var url;
            var parentFrameId;
            var frameId;
            // loop through the frames
            for (var i = 0; i < arrayLength; i++) {
                            parentFrameId = response[i].parentFrameId;
                frameId = response[i].frameId
                url = response[i].url;

                if(url.indexOf('#') >= 0){
                    url = url.substring(0,url.indexOf('#'));
                }
                // send JS command to turn the tool on
                
                if (url != "about:blank") {                
                    chrome.devtools.inspectedWindow.eval(
                        "ia11yVars."+currentTest+"({task: 'off',parentFrameId:"+parentFrameId+"})",
                        { frameURL: url, useContentScriptContext: true},
                        function(response){ // callback from when the test is done

                            if(typeof response != 'undefined'){

                            } else {

                            chrome.runtime.sendMessage({
                                tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
                                code: "ia11yVars."+currentTest+"({task: 'off',parentFrameId:"+parentFrameId+",nodeLimiter: "+false+"})",
                                frameId: frameId,
                                command: "fallback" // get all of the frames
                                },function(response){

                                });

                            }

                        }
                    );
                }
            }
        });        
    }
}

  chrome.devtools.network.onNavigated.addListener(function receive(event) {
    // new page loaded

    emptyResults('results'); 
    // delete the old totals before rerunning the test
    clearAllNumbers();

    clearResultsNotes();

    clearNodeLimiter();

    showw3CFilterButton(event);

    // reset the filters
    clearFilters();

    // reset track focus
    clearTrackFocus();

    emptyResults("testTableBody")
    emptyResults("testTotalsTableBody")
    addClass(document.getElementById('testTableContainer'), 'hide');
    addClass(document.getElementById('testTotalsTableContainer'), 'hide');
  });

chrome.runtime.sendMessage({
    tabId: chrome.devtools.inspectedWindow.tabId, // the tab ID of the currently inspected window
    command: "getURL" // get all of the frames
}, function(response) { // callback once we have all of the frames
    showw3CFilterButton(response.url);
});

  function clearFilters(){
    showHidden = false;
    showErrors = false;
    showWarnings = false;

    document.getElementById('showHidden').checked = false;
    document.getElementById('showWarnings').checked = false;
    document.getElementById('showErrors').checked = false;    
  }

  function clearTrackFocus(){
    document.getElementById('ia11yFocusTrack').checked = false;
  }

window.onload = function(){
    document.getElementById('version').innerHTML = chrome.runtime.getManifest().version_name;
}
/*
document.getElementById('versionlink').addEventListener('click', function() {
     chrome.tabs.create({ url: "history.html" });
}, false);
*/