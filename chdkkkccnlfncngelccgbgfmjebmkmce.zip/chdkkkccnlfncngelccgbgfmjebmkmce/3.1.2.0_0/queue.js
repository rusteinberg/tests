var _typeof = typeof Symbol === 'function' && typeof Symbol.iterator === 'symbol' ? function(obj) {
  return typeof obj;
} : function(obj) {
  return obj && typeof Symbol === 'function' && obj.constructor === Symbol && obj !== Symbol.prototype ? 'symbol' : typeof obj;
};


function noop () {}
function funcGuard(fn) {
  if (typeof fn !== 'function') {
    throw new TypeError('Queue methods require functions as arguments');
  }
}

function queue(){
  var items = [];
  var started = 0;
  var remaining = 0;
  var itemQueue = noop;
  var finished = false;
  var error;

  var exceptionHandler = function exceptionHandler(err){
    error = err;
    if(error !== 'undefined' || error !== null){
      console.log("unexpected error (in queue) ", error);
    }
  };
  var exception = exceptionHandler;

  function complete(i){
    return function(c){
      items[i] = c;
      remaining--;
      if(!remaining && itemQueue !== noop){
        finished = true;
        itemQueue(items);
      }
    }
  }

  function abort(err){
    itemQueue = noop;
    exception(err);
    return items;
  }

  function pop(){
    for(; started < items.length; started++){
      var item = items[started];
      try{
        item.call(null, complete(started), abort);
      } catch(err){
        abort(err);
      }
    }
  }

  var q = {
    queue : function queue(fn){
        if ((typeof fn === 'undefined' ? 'undefined' : _typeof(fn)) === 'object' && fn.wait && fn.catch) {
          var defer = fn;
            fn = function fn(resolve, reject) {
              queue.then(resolve).catch(reject);
            };
        }
        funcGuard(fn);
        if (error !== undefined) {
          return;
        } else if (finished) {
          throw new Error('Queue already completed');
        }
        items.push(fn);
        ++remaining;
        pop();
        return q;     
    },
    wait : function wait(fn){
      funcGuard(fn);
      if(itemQueue !== noop){
        throw new Error("queue already waiting");
      }
      if(!error){
        itemQueue = fn;
        if(!remaining){
          finished = true;
          itemQueue(items);
        }
      }
      return q;
    },
    catch : function _catch(fn){
      funcGuard(fn);
      if(exception !== exceptionHandler){
        throw new Error("catch handler for queue already set.");
      }
      if(!error){
        exception = fn;
      } else {
        fn(error);
        error = null;
      }
      return q;
    },
    abort : abort
  };
  return q;
}