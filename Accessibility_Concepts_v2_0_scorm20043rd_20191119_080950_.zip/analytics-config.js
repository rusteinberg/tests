
/* Tin Can configuration */

//
// ActivityID that is sent for the statement's object
//
ANALYTICS_COURSE_ID = "https://app.authr.it/activities/course/105028";

//
// CourseName for the activity
//
ANALYTICS_COURSE_NAME = {
    "en-US": "Accessibility Concepts v2.0"
};

//
// CourseDesc for the activity
//
ANALYTICS_COURSE_DESC = {
    "en-US": "This course provides a high level overview of the process for auditing web pages and software for compliance against standards like Section 508 Revised and WCAG 2.0 or 2.1."
};

//
// Pre-configured LRSes that should receive data, added to what is included
// in the URL and/or passed to the constructor function.
//
// An array of objects where each object may have the following properties:
//
//    endpoint: (including trailing slash '/')
//    auth:
//    allowFail: (boolean, default true)
//
ANALYTICS_RECORD_STORES = [
	
];
