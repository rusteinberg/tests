//===============================================================================
//             Copyright(c) Hewlett - Packard Development Company L.P.	       
//                            All rights reserved.     		                  
//===============================================================================
// constraint.js for HP Smart Printing driver.
//
// Version: "1.01.1"
//
var pskPrefix = "psk";
var pskNs = "http://schemas.microsoft.com/windows/2003/08/printing/printschemakeywords";
var pskV11Ns = "http://schemas.microsoft.com/windows/2013/05/printing/printschemakeywordsv11";
var psfPrefix = "psf";
var psfNs = "http://schemas.microsoft.com/windows/2003/08/printing/printschemaframework";
var xsdPrefix = "xsd";
var xsdNs = "http://www.w3.org/2001/XMLSchema";
var xsiPrefix = "xsi";
var xsiNs = "http://www.w3.org/2001/XMLSchema-instance";
var vendorDefinedPrefix = "ns0000";
var venderDefinedNs = "http://schemas.hp.com/ptpc/2006/1";
var bpePrefix = "bpe";
var hpPrefix = "hp";
var hpDefinedNs = "http://schemas.hp.com/ptpc/2006/2";
var bpeNs = "http://www.adobe.com/bpeschema";
var namespaces = {};
namespaces[psfPrefix] = psfNs;
namespaces[pskPrefix] = pskNs;
namespaces[xsdPrefix] = xsdNs;
namespaces[xsiPrefix] = xsiNs;
namespaces[vendorDefinedPrefix] = venderDefinedNs;
namespaces[bpePrefix] = bpeNs;
namespaces[hpPrefix] = hpDefinedNs;
var prefixes = {};
prefixes[psfNs] = psfPrefix;
prefixes[pskNs] = pskPrefix;
prefixes[xsdNs] = xsdPrefix;
prefixes[xsiNs] = xsiPrefix;
prefixes[venderDefinedNs] = vendorDefinedPrefix;
prefixes[bpeNs] = bpePrefix;
prefixes[hpDefinedNs] = hpPrefix;
var NODE_ELEMENT = 1;
var NODE_ATTRIBUTE = 2;
var PREFIX_CANONICAL = "canonical";
var PREFIX_REAL = "real";

if (!String.prototype.trim) {
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g, '');
    };
}

var Product_type = {
    Product_Unknown: -1,
    Product_PCL6: 0,
    Product_PCL3: 1,
    Product_PCLmS: 2,
    Product_PDF: 3,
    Product_PS: 4,
    Product_HyPCL6: 5,
    Product_PCL3GUIBERT: 6,
    Product_ADBPDF: 7
};

var ProductBy = {
    Unknown: 0,
    Model: 1,
    CID: 2
};

var Output_Direction = {
    FACEUP: 0,
    FACEDOWN: 1,
    BOTH: 2
};

//Add any Feature name which is divided into multiple different GPD features with extended options to overcome GPD options size limitation
var expandedFeaturesMap = {
    "psk:PageMediaType": ["ns0000:PageMediaTypeExt1"]
};

var userMarginValues =
{
    __3mm: 3000,
    __5mm: 5000
};

function getPrintCaps() {
    var printCaps = 
        {
        features: [{ inGPD: true, name: "ns0000:JobDestination", dispName: "Job Destination", pickMany: false, options: [{ name: "ns0000:PDF", dispName: "PDF", scoredProps: [{ name: "ns0000:Path", paramRef: "ns0000:JobDestinationPath" }] }, { name: "ns0000:LocalNW_Device", dispName: "Local Network Device", scoredProps: [{ name: "ns0000:IPAddress", paramRef: "ns0000:JobLocalNW_Device_IPAddress" }, { name: "ns0000:HostName", paramRef: "ns0000:JobLocalNW_Device_HostName" }, { name: "ns0000:Protocols_Supported", paramRef: "ns0000:JobLocalNW_Device_Protocols_Supported" }, { name: "ns0000:PDLs_Supported", paramRef: "ns0000:JobPDLs_Supported" }, { name: "ns0000:PrivatePickupSettable", paramRef: "ns0000:JobPrivatePickupSettable" }, { name: "ns0000:PrivatePickupEnabledInDashboard", paramRef: "ns0000:JobPrivatePickupEnabledInDashboard" }] }, { name: "ns0000:PushToClient", dispName: "Push To Client", scoredProps: [{ name: "ns0000:CloudDeliveryType", paramRef: "ns0000:JobCloudDeliveryType" }, { name: "ns0000:RoamUserID", paramRef: "ns0000:JobRoamUserID" }, { name: "ns0000:CloudPrinterUUID", paramRef: "ns0000:JobCloudPrinterUUID" }, { name: "ns0000:IPAddress", paramRef: "ns0000:JobLocalNW_Device_IPAddress" }, { name: "ns0000:HostName", paramRef: "ns0000:JobLocalNW_Device_HostName" }, { name: "ns0000:Protocols_Supported", paramRef: "ns0000:JobLocalNW_Device_Protocols_Supported" }, { name: "ns0000:PrivatePickupSettable", paramRef: "ns0000:JobPrivatePickupSettable" }, { name: "ns0000:PrivatePickupEnabledInDashboard", paramRef: "ns0000:JobPrivatePickupEnabledInDashboard" }] }] }, { inGPD: true, name: "ns0000:JobTelemetryUserOption", dispName: "Telemetry User Option", pickMany: false, options: [{ name: "ns0000:OptOut", dispName: "OptOut" }, { name: "ns0000:OptIn", dispName: "OptIn", scoredProps: [{ name: "ns0000:EventJobRepoPath", paramRef: "ns0000:DocumentEventJobRepoPath" }, { name: "ns0000:appDeployedUUID", paramRef: "ns0000:DocumentappDeployedUUID" }, { name: "ns0000:appDeployedID", paramRef: "ns0000:DocumentappDeployedID" }, { name: "ns0000:appStackType", paramRef: "ns0000:DocumentappStackType" }], props: [{ name: "ns0000:JobQueueType", value: "POG_Queue", type: "xsd:string" }] }] }, { inGPD: false, name: "ns0000:JobStatusMonitor", dispName: "Status Monitor", pickMany: false, options: [{ name: "ns0000:Off", dispName: "Off" }, { name: "ns0000:On", dispName: "On" }] }, { inGPD: false, name: "ns0000:JobDeliveryMode", dispName: "IDS_DELIVERYMODE", pickMany: false, options: [{ name: "ns0000:Normal", dispName: "IDS_NORMAL" }, { name: "ns0000:Secure", dispName: "IDS_SECURE" }] }, { inGPD: true, name: "psk:PageScaling", dispName: "IDS_SCALIING", options: [{ name: "psk:None", dispName: "IDS_ACTUAL_SIZE" }, { name: "ns0000:FitApplicationImageableSizeToPageImageableSize", dispName: "IDS_PRINT_DOC_ON" }, { name: "psk:CustomSquare", dispName: "IDS_SCALE_TO_FIT", scoredProps: [{ name: "psk:Scale", paramRef: "psk:PageScalingScale" }] }, { name: "ns0000:FitToRoll", dispName: "IDS_PAGEMEDIASIZE_FITTOROLL" }], subFeatures: [{ inGPD: false, name: "psk:ScaleOffsetAlignment", dispName: "IDS_WM_OFFSET_FROM", options: [{ name: "psk:BottomCenter", dispName: "IDS_BOTTOM" }, { name: "psk:BottomLeft", dispName: "IDS_BOTTOM_LEFT" }, { name: "psk:BottomRight", dispName: "IDS_BOTTOM_RIGHT" }, { name: "psk:Center", dispName: "IDS_CENTER" }, { name: "psk:RightCenter", dispName: "IDS_RIGHT" }, { name: "psk:LeftCenter", dispName: "IDS_LEFT" }, { name: "psk:TopCenter", dispName: "IDS_TOP" }, { name: "psk:TopLeft", dispName: "IDS_TOP_LEFT" }, { name: "psk:TopRight", dispName: "IDS_TOP_RIGHT" }] }, { inGPD: false, name: "ns0000:TargetMediaSize1", dispName: "IDS_SCALING_PAPERSIZE", options: [{ scoredProps: [{ name: "ns0000:PageScalingTargetMediaSizeName", paramRef: "ns0000:PageScalingTargetMediaSizeName" }, { name: "ns0000:PageScalingTargetMediaSizeWidth", paramRef: "ns0000:PageScalingTargetMediaSizeWidth" }, { name: "ns0000:PageScalingTargetMediaSizeHeight", paramRef: "ns0000:PageScalingTargetMediaSizeHeight" }] }] }] }, { inGPD: false, name: "bpe:JobUniversalDriverPdfPassthrough", dispName: "Adobe Passthrough", pickMany: false, options: [{ name: "bpe:false", dispName: "Off" }, { name: "bpe:true", dispName: "On", scoredProps: [{ name: "hp:PDFVersion", value: "2.0" }] }] }, { "dispName": "IDS_HPPANTONEEMULATION", "inGPD": false, "name": "ns0000:PagePantoneEmulation", "pickMany": false, "options": [{ "dispName": "IDS_OFF", "name": "ns0000:Off" }, { "dispName": "IDS_ON", "name": "ns0000:On" }] }, { inGPD: false, name: "bpe:JobBPECalibrationDue", dispName: "JobBPECalibrationDue", pickMany: false, oneOptionWithScoredProp: true, options: [{ dispName: "JobBPECalibrationDue Option", scoredProps: [{ name: "bpe:CalibrationFlag", value: "false", type: "xsd:boolean" }] }] }, { inGPD: false, name: "bpe:JobAPPrinterUtilityPath", dispName: "JobAPPrinterUtilityPath", pickMany: false, oneOptionWithScoredProp: true, options: [{ dispName: "JobAPPrinterUtilityPath Option", scoredProps: [{ name: "bpe:FullyQualifiedPath", value: "", type: "xsd:string" }] }] }, { inGPD: false, name: "bpe:JobBPELastCalibration", dispName: "JobBPELastCalibration", pickMany: false, oneOptionWithScoredProp: true, options: [{ dispName: "JobBPELastCalibration Option", scoredProps: [{ name: "bpe:TimeStamp", value: "121212", type: "xsd:integer" }] }] }],
        paramDefs: [{ name: "ns0000:JobDestinationPath", props: [{ name: "psk:DisplayName", value: "DestinationPath", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "4", type: "xsd:integer" }, { name: "psf:MaxLength", value: "255", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobLocalNW_Device_IPAddress", props: [{ name: "psk:DisplayName", value: "LocalNW Device IPAddress", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "7", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobLocalNW_Device_HostName", props: [{ name: "psk:DisplayName", value: "LocalNW Device HostName", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "4", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobLocalNW_Device_Protocols_Supported", props: [{ name: "psk:DisplayName", value: "LocalNW Protocols Supported", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "4", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobPDLs_Supported", props: [{ name: "psk:DisplayName", value: "PDLs Supported", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "3", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobCloudDeliveryType", props: [{ name: "psk:DisplayName", value: "Cloud Deliver Type", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "CloudPull", type: "xsd:string" }, { name: "psf:MinLength", value: "5", type: "xsd:integer" }, { name: "psf:MaxLength", value: "32", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobRoamUserID", props: [{ name: "psk:DisplayName", value: "Roam User ID", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "3", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobCloudPrinterUUID", props: [{ name: "psk:DisplayName", value: "Cloud Printer UUID", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "3", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobExtPT", props: [{ name: "psk:DisplayName", value: "Ext PT", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "0", type: "xsd:integer" }, { name: "psf:MaxLength", value: "10240", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:PageMediaSizeCustomSizeName", props: [{ name: "psk:DisplayName", value: "CustomName", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "0", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:DocumentEventJobRepoPath", props: [{ name: "psk:DisplayName", value: "EventJobRepoPath", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "256", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:DocumentappDeployedUUID", props: [{ name: "psk:DisplayName", value: "appDeployedUUID", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:DocumentappDeployedID", props: [{ name: "psk:DisplayName", value: "appDeployedID", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:DocumentappStackType", props: [{ name: "psk:DisplayName", value: "appStackType", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "Prod", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "32", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:DocumentNUpGutter", props: [{ name: "psk:DisplayName", value: "DocumentNUpGutter", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:integer", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "0", type: "xsd:integer" }, { name: "psf:MinValue", value: "0", type: "xsd:integer" }, { name: "psf:MaxValue", value: "250000", type: "xsd:integer" }, { name: "psf:Multiple", value: "1", type: "xsd:integer" }, { name: "psf:UnitType", value: "microns", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:PageMediaTypePrev", props: [{ name: "psk:DisplayName", value: "PageMediaTypePrev", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "psk:Plain", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "256", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:PageInputBinPrev", props: [{ name: "psk:DisplayName", value: "PageInputBinPrev", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "ns0000:UsePrinterSetting", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "256", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobUserResolutionPrev", props: [{ name: "psk:DisplayName", value: "JobUserResolutionPrev", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "ns0000:HPS_Normal", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "256", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:PageBorderlessPrev", props: [{ name: "psk:DisplayName", value: "PageBorderlessPrev", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "psk:None", type: "xsd:string" }, { name: "psf:MinLength", value: "1", type: "xsd:integer" }, { name: "psf:MaxLength", value: "256", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobPrivatePickupSettable", props: [{ name: "psk:DisplayName", value: "Private Pickup is settable or not", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "False", type: "xsd:string" }, { name: "psf:MinLength", value: "4", type: "xsd:integer" }, { name: "psf:MaxLength", value: "10", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:JobPrivatePickupEnabledInDashboard", props: [{ name: "psk:DisplayName", value: "Private Pickup in dashboard is on or off", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "False", type: "xsd:string" }, { name: "psf:MinLength", value: "4", type: "xsd:integer" }, { name: "psf:MaxLength", value: "10", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:DocumentFoldSheetsPerSet", props: [{ name: "psk:DisplayName", value: "DocumentFoldSheetsPerSet", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:integer", type: "xsd:QName" }, { name: "psf:MaxValue", value: "99999", type: "xsd:integer" }, { name: "psf:MinValue", value: "1", type: "xsd:integer" }, { name: "psf:DefaultValue", value: "1", type: "xsd:integer" }, { name: "psf:Multiple", value: "1", type: "xsd:integer" }, { name: "psf:UnitType", value: "pages", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "psk:PageScalingScale", props: [{ name: "psk:DisplayName", value: "IDS_WM_SCALE_RANGE", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:integer", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "100", type: "xsd:integer" }, { name: "psf:MaxValue", value: "400", type: "xsd:integer" }, { name: "psf:MinValue", value: "25", type: "xsd:integer" }, { name: "psf:Multiple", value: "1", type: "xsd:integer" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }, { name: "psf:UnitType", value: "percent", type: "xsd:string" }] }, { name: "ns0000:PageScalingTargetMediaSizeName", props: [{ name: "psk:DisplayName", value: "PageScalingTargetMediaSizeName", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:string", type: "xsd:QName" }, { name: "psf:DefaultValue", value: "ns0000:UsePageMediaSize", type: "xsd:string" }, { name: "psf:MinLength", value: "0", type: "xsd:integer" }, { name: "psf:MaxLength", value: "128", type: "xsd:integer" }, { name: "psf:UnitType", value: "characters", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:PageScalingTargetMediaSizeWidth", props: [{ name: "psk:DisplayName", value: "PageScalingTargetMediaSizeWidth", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:integer", type: "xsd:QName" }, { name: "psf:MaxValue", value: "914400", type: "xsd:integer" }, { name: "psf:MinValue", value: "78994", type: "xsd:integer" }, { name: "psf:DefaultValue", value: "78994", type: "xsd:integer" }, { name: "psf:Multiple", value: "1", type: "xsd:integer" }, { name: "psf:UnitType", value: "microns", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }, { name: "ns0000:PageScalingTargetMediaSizeHeight", props: [{ name: "psk:DisplayName", value: "PageScalingTargetMediaSizeHeight", type: "xsd:string" }, { name: "psf:DataType", value: "xsd:integer", type: "xsd:QName" }, { name: "psf:MaxValue", value: "91000008", type: "xsd:integer" }, { name: "psf:MinValue", value: "139996", type: "xsd:integer" }, { name: "psf:DefaultValue", value: "139996", type: "xsd:integer" }, { name: "psf:Multiple", value: "1", type: "xsd:integer" }, { name: "psf:UnitType", value: "microns", type: "xsd:string" }, { name: "psf:Mandatory", value: "psk:Conditional", type: "xsd:QName" }] }]
    };
    return printCaps;
}
function getAppDefineProductType(scriptContext) {
    var priorityArray = ["PCL6", "PCL", "PCLmS", "PCL3GUIBERT", "ADBPDF", "PDF", "PS"/*, "HybridRaster"*/];
    var supportPdls = safeGetUPBString(scriptContext, "JobPDLs_Supported");
    var product_type;
    var foundPDL;
    var pdls;
    if (supportPdls) {
        pdls = supportPdls.split(";");
        for (var i = 0; i < priorityArray.length; ++i) {
            foundPDL = findInArray(pdls, function (o) {
                return o == priorityArray[i];
            });
            if (foundPDL) {
                if (foundPDL != "PCL") {
                    product_type = "Product_" + foundPDL;
                }
                else {
                    product_type = "Product_PCL3";
                }
                break;
            }
        }
    }
    return product_type;
}
function getAppDefinePDL(scriptContext) {
    var priorityArray = ["PCL6", "PCL", "PCLmS", "PCL3GUIBERT", "ADBPDF", "PDF", "PS"/*, "HybridRaster"*/];
    var supportPdls = safeGetUPBString(scriptContext, "JobPDLs_Supported");
    var pdl;
    var foundPDL;
    var pdls;
    if (supportPdls) {
        pdls = supportPdls.split(";");
        for (var i = 0; i < priorityArray.length; ++i) {
            foundPDL = findInArray(pdls, function (o) {
                return o == priorityArray[i];
            });
            if (foundPDL) {
                pdl = foundPDL;
                break;
            }
        }
    }
    return pdl;
}
function getProductInfo(printTicket, scriptContext, devModeProperties) {
    var productInfo = { productType: Product_type.Product_Unknown, productBy: ProductBy.Unknown, dymargin: 0, outDirection: Output_Direction.FACEDOWN, rotateForLand: false, defaultSets: null, manualDuplexType: null, devCapCategory: null, supportSnapping: false, roamDocumentType: "RAW", remoteDeliveryType: "roam" };
    var cid_name = getCIDname(scriptContext, devModeProperties);
    //check and get the ProductCaps from UPB if FF is updated.
    var productCapsXmlString = safeGetUPBString(scriptContext, "ProductCaps");
    if (!productCapsXmlString) {
        productCapsXmlString = safeGetString(scriptContext.DriverProperties, "ProductCaps");
    }
    var loadedProductCapsXml = loadXMLFromString(printTicket, productCapsXmlString);
    var selectedProductNode, selectedPdl, supportPdls, productTypes, appDefinedPDL;
    var selectedPdlNode;
    var dyMarginStr, outDirectionStr, rotateForLandStr, supportSnappingStr;
    var manual_type_name, devCap_name, supportRoamDocumentType, remoteDeliveryType;
    if (loadedProductCapsXml) {
        // check cid. cid based...
        if (cid_name != "Product_Unknown") {
            selectedProductNode = loadedProductCapsXml.selectSingleNode("/Products/CIDs/CID[@name='" + cid_name + "']");
            if (selectedProductNode != null)
                productInfo.productBy = ProductBy.CID;
        }
        if (selectedProductNode) {
            //get productTypes
            supportPdls = selectedProductNode.getAttribute("productTypes");
            if (supportPdls && supportPdls.length > 0) {
                productTypes = supportPdls.split(",");
                selectedPdl = productTypes[0];

                // JobPDL in UPB is defined in productINfo, use it..
                if (productTypes.length > 1) {
                    //set PDL by UPB.
                    appDefinedPDL = getAppDefineProductType(scriptContext);
                    if (appDefinedPDL) {
                        for (var i = 0; i < productTypes.length; ++i) {
                            if (appDefinedPDL == productTypes[i]) {
                                selectedPdl = productTypes[i];
                                break;
                            }
                        }
                    }
                }

                if (selectedPdl == "Product_PCL3") {
                    productInfo.productType = Product_type.Product_PCL3;
                }
                else if (selectedPdl == "Product_PCL3GUIBERT") {
                    productInfo.productType = Product_type.Product_PCL3GUIBERT;
                }
                else if (selectedPdl == "Product_ADBPDF") {
                    productInfo.productType = Product_type.Product_ADBPDF;
                }
                else if (selectedPdl == "Product_PCLmS") {
                    productInfo.productType = Product_type.Product_PCLmS;
                }
                else if (selectedPdl == "Product_PDF") {
                    productInfo.productType = Product_type.Product_PDF;
                }
                else if (selectedPdl == "Product_PS") {
                    productInfo.productType = Product_type.Product_PS;
                }
                else if (selectedPdl == "Product_HyPCL6") {
                    productInfo.productType = Product_type.Product_HyPCL6;
                }
                else if (selectedPdl == "Product_PCL6") {
                    productInfo.productType = Product_type.Product_PCL6;
                }

                //get common pdl features..
                selectedPdlNode = loadedProductCapsXml.selectSingleNode("/Products/ProductTypes/ProductType[@name='" + selectedPdl + "']");
                if (selectedPdlNode) {
                    dyMarginStr = selectedPdlNode.getAttribute("dyMargin");
                    outDirectionStr = selectedPdlNode.getAttribute("outDirection");
                    rotateForLandStr = selectedPdlNode.getAttribute("rotateForLand");
                    supportSnappingStr = selectedPdlNode.getAttribute("supportSnapping");
                    productInfo.dymargin = dyMarginStr ? parseInt(dyMarginStr) : 0;
                    productInfo.outDirection = outDirectionStr == "FACEUP" ? Output_Direction.FACEUP : Output_Direction.FACEDOWN;
                    productInfo.rotateForLand = rotateForLandStr == "true" ? true : false;
                    productInfo.supportSnapping = supportSnappingStr == "true" ? true : false;
                    productInfo.roamDocumentType = selectedPdlNode.getAttribute("roamDocumentType");
                    productInfo.remoteDeliveryType = selectedPdlNode.getAttribute("remoteDeliveryType");
                }
            }
            // get model specific features
            dyMarginStr = selectedProductNode.getAttribute("dyMargin");
            outDirectionStr = selectedProductNode.getAttribute("outDirection");
            rotateForLandStr = selectedProductNode.getAttribute("rotateForLand");
            supportSnappingStr = selectedProductNode.getAttribute("supportSnapping");
            manual_type_name = selectedProductNode.getAttribute("manualType");
            devCap_name = selectedProductNode.getAttribute("devCap");
            supportRoamDocumentType = selectedProductNode.getAttribute("roamDocumentType");
            remoteDeliveryType = selectedProductNode.getAttribute("remoteDeliveryType");
            if (dyMarginStr) {
                productInfo.dymargin = parseInt(dyMarginStr);
            }
            if (outDirectionStr) {
                productInfo.outDirection = outDirectionStr == "FACEUP" ? Output_Direction.FACEUP : Output_Direction.FACEDOWN;
            }
            if (rotateForLandStr) {
                productInfo.rotateForLand = rotateForLandStr == "true" ? true : false;
            }
            if (supportSnappingStr) {
                productInfo.supportSnapping = supportSnappingStr == "true" ? true : false;
            }
            if (manual_type_name) {
                productInfo.manualDuplexType = manual_type_name;
            }
            if (devCap_name) {
                productInfo.devCapCategory = devCap_name;
            }
            if (supportRoamDocumentType) {
                productInfo.roamDocumentType = supportRoamDocumentType;
            }
            if (remoteDeliveryType) {
                productInfo.remoteDeliveryType = remoteDeliveryType;
            }
        }
        // if CID is not defined.
        else {
            //set PDL by UPB.
            selectedPdl = getAppDefineProductType(scriptContext);
            if (selectedPdl) {
                if (selectedPdl == "Product_PCL3") {
                    productInfo.productType = Product_type.Product_PCL3;
                }
                else if (selectedPdl == "Product_PCLmS") {
                    productInfo.productType = Product_type.Product_PCLmS;
                }
                else if (selectedPdl == "Product_PDF") {
                    productInfo.productType = Product_type.Product_PDF;
                }
                else if (selectedPdl == "Product_PS") {
                    productInfo.productType = Product_type.Product_PS;
                }
                else if (selectedPdl == "Product_HyPCL6") {
                    productInfo.productType = Product_type.Product_HyPCL6;
                }
                else if (selectedPdl == "Product_PCL6") {
                    productInfo.productType = Product_type.Product_PCL6;
                }
                else if (selectedPdl == "Product_PCL3GUIBERT") {
                    productInfo.productType = Product_type.Product_PCL3GUIBERT;
                }
                else if (selectedPdl == "Product_ADBPDF") {
                    productInfo.productType = Product_type.Product_ADBPDF;
                }

                //get common pdl features..
                var selectedPdlNode = loadedProductCapsXml.selectSingleNode("/Products/ProductTypes/ProductType[@name='" + selectedPdl + "']");
                if (selectedPdlNode) {
                    dyMarginStr = selectedPdlNode.getAttribute("dyMargin");
                    outDirectionStr = selectedPdlNode.getAttribute("outDirection");
                    rotateForLandStr = selectedPdlNode.getAttribute("rotateForLand");
                    supportSnappingStr = selectedPdlNode.getAttribute("supportSnapping");
                    productInfo.dymargin = dyMarginStr ? parseInt(dyMarginStr) : 0;
                    productInfo.outDirection = outDirectionStr == "FACEUP" ? Output_Direction.FACEUP : Output_Direction.FACEDOWN;
                    productInfo.rotateForLand = rotateForLandStr == "true" ? true : false;
                    productInfo.supportSnapping = supportSnappingStr == "true" ? true : false;
                    productInfo.roamDocumentType = selectedPdlNode.getAttribute("roamDocumentType");
                    productInfo.remoteDeliveryType = selectedPdlNode.getAttribute("remoteDeliveryType");
                }
            }
        }
    }
    return productInfo;
}
function getCIDname(scriptContext, devModeProperties) {
    // for Rqueue
    // currently Rqueue is CID based.
    var cid_name = devModeProperties ? getStringFromUPBorDevmode(scriptContext, devModeProperties, "CID") : safeGetUPBString(scriptContext, "CID");
    if (cid_name) {
        cid_name = cid_name.toUpperCase();
    }
    else {
        cid_name = "Product_Unknown";
    }
    return cid_name;
}

function validatePrintTicket(printTicket, scriptContext) {
    //debugger;
    var ret = 1;
    var productInfo = getProductInfo(printTicket, scriptContext);

    // valdate device constraints.
    if (checkDeviceConstraints(printTicket, scriptContext, productInfo, null) == 2) {
        ret = 2;
    }

    // validate ticket constraints
    if (checkTicketConstraints(printTicket, scriptContext, null, productInfo, null) == 2) {
        ret = 2;
    }
    return ret;
}
function completePrintCapabilities(printTicket, scriptContext, printCapabilities) {
    //debugger;
    setSelectionNamespace(printCapabilities.XmlNode, psfPrefix, psfNs);
    var printCaps = getPrintCaps();
    var productInfo = getProductInfo(printCapabilities, scriptContext);
    var featureNodesMap = getAllElementsMap(printCapabilities.XmlNode, psfPrefix + ":Feature");

    setNamespace(printCapabilities.XmlNode, bpePrefix, bpeNs);
    setNamespace(printCapabilities.XmlNode, hpPrefix, hpDefinedNs);
    // add HP custom feature and parameter including MTI.
    addFeaturesAndParameters(printCapabilities, printCaps, featureNodesMap);
    // Add custom paper size from UserPropertyBag in shared printer queue. ** not used in potg
    addCustomPaperSize(printCapabilities, scriptContext, featureNodesMap);
    // InputBin constraint None to DeviceSetting
    inputBinAutoSelectConstraintHandling(printCapabilities, productInfo, featureNodesMap);
    // Merge all expanded features into one feature
    mergeExpandedFeatures(printCapabilities, featureNodesMap);

    //device constraints
    checkDeviceConstraints(printCapabilities, scriptContext, productInfo, featureNodesMap);

    updateCustomPaperSizeRange(printCapabilities, scriptContext);

    if (!printTicket)
        return;

    // apply ticket constraints
    checkTicketConstraints(printTicket, scriptContext, printCapabilities, productInfo, featureNodesMap);
    // update Page Imageable Size for LFP products
    updatePageImageableSize(printTicket, scriptContext, printCapabilities, productInfo);
}

function convertDevModeToPrintTicket(devModeProperties, scriptContext, printTicket) {
    if (!devModeProperties) {
        return;
    }
    if (printTicket) {
        setSelectionNamespace(printTicket.XmlNode, psfPrefix, psfNs);
    }
    else return;
    //debugger;
    var value = devModeProperties.GetString("AllValues");
    var values = parseNameValuePairsString(value);
    var printCaps = getPrintCaps();
    var productInfo = getProductInfo(printTicket, scriptContext, devModeProperties);
    var featureNodesMap = getAllElementsMap(printTicket.XmlNode, psfPrefix + ":Feature");

    setNamespace(printTicket.XmlNode, bpePrefix, bpeNs);
    setNamespace(printTicket.XmlNode, hpPrefix, hpDefinedNs);

    addFeaturesAndParameters(printTicket, printCaps, featureNodesMap, values);
    // update PageOutputQuality according to Jobuserresolution selected
    updatePageOutputQualityForRQueue(printTicket, featureNodesMap, productInfo);
    //destination infor
    jobDestInfoToPt(printTicket, scriptContext, productInfo, featureNodesMap);
    // Add UCDE Properties if the queue is R
    ucdePropertiesToPt(printTicket, scriptContext, devModeProperties);
    //SelectedPreset
    jobVarsToPtForRQueue(printTicket, scriptContext, devModeProperties);
    //// add custom paper parameter name : ref ns0000:PageMediaSizeCustomSizeName in shared printer queue. ** not used in potg
    addCustomPaperSize(printTicket, scriptContext, featureNodesMap);
    //device margin
    applyDynamicMargin(printTicket, scriptContext, productInfo, featureNodesMap);
    // setting for telemetry data
    telemetryDataSetToPt(printTicket, scriptContext, featureNodesMap);
    //set expanded feature Option
    updateDevmodeToPtForExpandedFeature(printTicket, featureNodesMap, devModeProperties);
    // Validate if snapping is supported and the manual touch by user is present so as to apply snapping for different media sizes.
    validateAndApplySnapping(printTicket, scriptContext, productInfo, featureNodesMap);
    //add statusMonitor On/Off feature
    jobStatusMonitorPT(printTicket, scriptContext, featureNodesMap);

    //add printer attribute for CID management
    printerAttributeToPt(printTicket, productInfo);

	//validateMediaSize
    validateMediaSize(printTicket, scriptContext, featureNodesMap);

    //validate NUP to add DocumentNUpGutter value in PT
    validateNUP(printTicket, featureNodesMap);

    //Limit resolution with the max application resolution selected
    SetMaxApplicationResolution(printTicket, productInfo, scriptContext, featureNodesMap);

    // set JobDeviceMarigin for LFP products when Scaling
    updateJobDeviceMariginWhenScalingLfpPcl3GuiBert(printTicket, productInfo);

    // This code is needed in Autodesk apps in order to mantain the correct page size in Lanscape scenaries
    correctPageSizeOrientationDevModeToPrintTicket(scriptContext, printTicket, devModeProperties, productInfo);
}

function convertPrintTicketToDevMode(printTicket, scriptContext, devModeProperties) {
    //debugger;
    if (printTicket) {
        setSelectionNamespace(printTicket.XmlNode, psfPrefix, psfNs);
    }
    else return;
    var prevValue = devModeProperties.GetString("AllValues");
    var values = {};
    var printCaps = getPrintCaps();
    var productInfo = getProductInfo(printTicket, scriptContext, devModeProperties);

    if (printCaps.features) {
        extractFeatureValues(printTicket, printCaps.features, values);
    }
    if (printCaps.paramDefs) {
        extractParameterValues(printTicket, printCaps.paramDefs, values);
    }
    var newValue = makeNameValuePairsString(values);
    if (prevValue != newValue) {
        devModeProperties.SetString("AllValues", newValue);
    }

    ptToJobVarsForRQueue(printTicket, devModeProperties);
    //set extesnion feature option in devmode
    updatePtToDevModeForExpandedFeature(printTicket, devModeProperties);
    // save dest modelname
    ptToDevmodeUcde(printTicket, scriptContext, devModeProperties);  //for Rqueue
    //add applyDynamicMarginToDevmode(GPD switch case)
    applyDynamicMarginToDevmode(printTicket);

    // set JobDeviceMarigin for LFP products when Scaling
    updateJobDeviceMariginWhenScalingLfpPcl3GuiBertToDevmode(printTicket, scriptContext, devModeProperties);

    // This code is needed in Autodesk apps in order to mantain the correct page size in Lanscape scenaries
    correctPageSizeOrientationPrintTicketToDevMode(printTicket, scriptContext, devModeProperties, productInfo);
}

///////////////////////////////////////////////////////////////////////////////////////

function checkDeviceConstraints(printTicketOrCapabilities, scriptContext, productInfo, pcFeatureNodesMap) {
    var rootElement = printTicketOrCapabilities.XmlNode.documentElement;
    var validateReturn = 1;
    var i, j = 0;
    var deviceConstraintsFromUpb, deviceConstraints, deviceConst = null;
    var featureWithDefaultOption, featureName;
    var defaultOptionNameIncludingPrefix = "";
    var constrainedOptionsString, constrainedOptionList;
    var featureNode, optionNode, optionNodes, valueNode;
    var curOptionName;
    var isPrintCapabilities = rootElement.baseName == "PrintCapabilities";
    if (printTicketOrCapabilities) {
        setSelectionNamespace(printTicketOrCapabilities.XmlNode, psfPrefix, psfNs);
    }

    // load device constrints from upb.
    deviceConstraintsFromUpb = safeGetUPBString(scriptContext, "ConstrainedAsDeviceSettingsForGPDFeaturesOnly");

    // format : FeatureName1.DeaultOption=Option1,Option2,Option3;FeatureName2.DefaultOption=Option1,Option2,Option3
    // defaultOption not exist, do not validate that feature.
    // defaultOption existed, but no prefix(:), search value from property in option.
    if (!deviceConstraintsFromUpb || deviceConstraintsFromUpb  == "NoConstraitsExisted") {
        return validateReturn;
    }
    deviceConstraints = deviceConstraintsFromUpb.split(";");

    //loop
    for (i = 0; i < deviceConstraints.length; ++i) {
        //FeatureName1.DeaultOption=Option1,Option2,Option3
        deviceConst = deviceConstraints[i].split("=");
        if (deviceConst.length == 2) {
            featureWithDefaultOption = deviceConst[0].split(".");
            featureName = featureWithDefaultOption[0];
            if (featureWithDefaultOption.length == 2) {
                defaultOptionNameIncludingPrefix = featureWithDefaultOption[1];
            }
            else {
                defaultOptionNameIncludingPrefix = "";
            }
            constrainedOptionsString = deviceConst[1];
            // only gpd feature
            featureNode = (pcFeatureNodesMap && pcFeatureNodesMap[featureName]);
            // || (rootElement && getFeatureNode(rootElement, featureName, PREFIX_CANONICAL));

            //for PC setting
            if (isPrintCapabilities && featureNode) {
                constrainedOptionList = constrainedOptionsString.split(",");
                // named option
                if (constrainedOptionsString.indexOf(":") > -1) {
                    for (j = 0; j < constrainedOptionList.length; ++j) {
                        optionNode = featureNode.selectSingleNode(psfPrefix + ":Option[@name='" + constrainedOptionList[j] + "']");
                        if (optionNode) {
                            optionNode.setAttribute("constrained", getNameWithNs(printTicketOrCapabilities.XmlNode, pskNs, "DeviceSettings"));
                        }
                    }
                }
                // unnamed option - find value for scoredProperty or property.
                else {
                    optionNodes = featureNode.selectNodes(psfPrefix + ":Option");
                    for (j = 0; j < optionNodes.length; j++) {
                        optionNode = optionNodes.item(j);
                        // first find scored property value
                        valueNode = optionNode.selectSingleNode(psfPrefix + ":ScoredProperty/" + psfPrefix + ":Value");
                        // find property value if scoredProperty not existed.
                        if (valueNode == null) {
                            valueNode = optionNode.selectSingleNode(psfPrefix + ":Property[@name!='" + pskPrefix + ":DisplayName']/" + psfPrefix + ":Value");
                        }
                        if (valueNode != null && valueNode.firstChild !=null && includedInArray(constrainedOptionList, valueNode.firstChild.nodeValue)) {
                            optionNode.setAttribute("constrained", getNameWithNs(printTicketOrCapabilities.XmlNode, pskNs, "DeviceSettings"));
                        }
                    }
                }
            }
            //For PT validation.
            else if (isPrintCapabilities == false && defaultOptionNameIncludingPrefix){
                featureNode = getFeatureNode(rootElement, featureName, PREFIX_CANONICAL);
                if (featureNode) {
                    constrainedOptionList = constrainedOptionsString.split(",");
                    curOptionName = getSelectedOptionName(featureNode, PREFIX_CANONICAL);
                    // named option.
                    if (curOptionName) {
                        if (includedInArray(constrainedOptionList, curOptionName)) {
                            optionNode = getSelectedOptionNode(featureNode);
                            if (optionNode) {
                                removeChildElements(featureNode, psfPrefix + ":Option");
                                addChildElement(featureNode, psfNs, "Option", defaultOptionNameIncludingPrefix);
                                validateReturn = 2;
                            }
                        }
                    }
                    //unnamed option - check ":" existed
                    else if (constrainedOptionsString.indexOf(":") == -1) {
                        optionNode = getSelectedOptionNode(featureNode);
                        valueNode = optionNode.selectSingleNode(psfPrefix + ":ScoredProperty/" + psfPrefix + ":Value");
                        // find property value if scoredProperty not existed.
                        if (valueNode == null) {
                            valueNode = optionNode.selectSingleNode(psfPrefix + ":Property[@name!='" + pskPrefix + ":DisplayName']/" + psfPrefix + ":Value");
                        }
                        if (valueNode != null && valueNode.firstChild != null && includedInArray(constrainedOptionList, valueNode.firstChild.nodeValue)) {
                            valueNode.firstChild.nodeValue = defaultOptionNameIncludingPrefix;
                            validateReturn = 2;
                        }
                    }
                }
                
            }
        }

    }

    return validateReturn;
}

function checkTicketConstraints(printTicket, scriptContext, printCapabilities, productInfo, pcFeatureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    var validateReturn = 1;
    var i, j = 0;
    var invalidCombinations = [];
    var devCapNodes, devCapNode, devCapName, devCaps, invalidCombinationNodes;
    var invalidCombination;
    var matchedConditions, matchedCondition, mathcedTicketOption, matchedTicketNode;
    var finalConditions, finalCondition, finalTicketOption, finalTicketNode;
    var bMatchedCombination = false;
    var ticketMap = {};
    var optionNode;

    if (printTicket) {
        setSelectionNamespace(printTicket.XmlNode, psfPrefix, psfNs);
    }
    // load ticket constraint xml from dpb
    var ticketConstraintXmlString = safeGetString(scriptContext.DriverProperties, "ConstrainedAsPrintTicketSettingsForGPDFeaturesOnly");
    var ticketConstraintXml = loadXMLFromString(printTicket, ticketConstraintXmlString);

    if (ticketConstraintXml != null ) {
        // collect invalidcombination from constraints xml
        devCapNodes = ticketConstraintXml.selectNodes("/Constraints/DeviceCap");
        if (devCapNodes) {
            for (i = 0; i < devCapNodes.length; i++) {
                devCapNode = devCapNodes.item(i);
                devCapName = devCapNode.getAttribute("name");
                devCaps = devCapName.split(",");
                if (includedInArray(devCaps, productInfo.devCapCategory)) {
                    invalidCombinationNodes = devCapNode.selectNodes("InvalidCombination");
                    for (j = 0; j < invalidCombinationNodes.length; j++) {
                        invalidCombinations.push(invalidCombinationNodes.item(j).text)
                    }
                }
            }
        }
    }

    // load ticket constrints from upb.
    var ticketConstraintsFromUpb = safeGetUPBString(scriptContext, "ConstrainedAsPrintTicketSettingsForGPDFeaturesOnly");
    if (ticketConstraintsFromUpb && ticketConstraintsFromUpb != "NoConstraitsExisted") {
        invalidCombinations = invalidCombinations.concat(ticketConstraintsFromUpb.split(";"))
    }

    // invalidCombination : aFeature.aOption,bFeature.bOption,cFeature.cOption.... |nFeature.nOption,nDefaultOption
    //                         matched feature-option conditions                   | final feature-option condition, valid option
    // invalidCombination[0],invalidCombination[1],invalidCombination[2]
    if (invalidCombinations.length < 1) {
        return validateReturn;
    }
            
    //loop for invalidCombinations
    for (i = 0; i < invalidCombinations.length; ++i) {
        //split two part(feature-option) - matched conditions and final conditions
        invalidCombination = invalidCombinations[i].split("|");
        if (invalidCombination.length == 2) {
            //spilt matched conditions  => aFeature.aOption,bFeature.bOption,cFeature.cOption....
            matchedConditions = invalidCombination[0].split(",");
            //spilt final conditions => nFeature.nOption,nDefaultOption
            finalConditions = invalidCombination[1].split(",");
        }

        if (matchedConditions.length > 0 && finalConditions.length == 2) {
            // matched option loop
            for (j = 0; j < matchedConditions.length; ++j) {
                //aFeature.aOption => matchedCondition[0].matchedCondition[1]
                matchedCondition = matchedConditions[j].split(".");
                if (matchedCondition.length == 2) {
                    //find current ticket option for matched feature.
                    // existed in map
                    if (ticketMap && ticketMap[matchedCondition[0]]) {
                        mathcedTicketOption = ticketMap[matchedCondition[0]];
                    }
                    // not existed.
                    else {
                        matchedTicketNode = getFeatureNode(rootElement, matchedCondition[0], PREFIX_CANONICAL);
                        if (matchedTicketNode) {
                            mathcedTicketOption = getSelectedOptionName(matchedTicketNode, PREFIX_CANONICAL);
                            ticketMap[matchedCondition[0]] = mathcedTicketOption;
                        }
                    }
                }
                // current Feature option matched with current ticket.
                if (mathcedTicketOption != matchedCondition[1]) {
                    bMatchedCombination = false;
                    break;
                }
                else {
                    bMatchedCombination = true;
                }
            }
        }

        if (bMatchedCombination == true) {
            //final feature option
            finalCondition = finalConditions[0].split(".");
            //nFeature.nOption => finalCondition[0].finalCondition[1]
            if (finalCondition.length == 2) {
                if (ticketMap && ticketMap[finalCondition[0]]) {
                    finalTicketOption = ticketMap[finalCondition[0]];
                }
                // not existed.
                else {
                    finalTicketNode = getFeatureNode(rootElement, finalCondition[0], PREFIX_CANONICAL);
                    if (finalTicketNode) {
                        finalTicketOption = getSelectedOptionName(finalTicketNode, PREFIX_CANONICAL);
                        ticketMap[finalCondition[0]] = finalTicketOption;
                    }
                }

                // for Ticket
                if (printCapabilities == null && finalTicketOption == finalCondition[1]) {
                    // invalid.
                    //correct feature node;
                    finalTicketNode = getFeatureNode(rootElement, finalCondition[0], PREFIX_CANONICAL);
                    if (finalTicketNode) {
                        optionNode = getSelectedOptionNode(finalTicketNode);
                        if (optionNode) {
                            removeChildElements(finalTicketNode, psfPrefix + ":Option");
                            addChildElement(finalTicketNode, psfNs, "Option", finalConditions[1]);
                            ticketMap[finalCondition[0]] = finalConditions[1];
                            validateReturn = 2
                        }
                    }
                    else if (validateReturn != 2) {
                        validateReturn = 0
                    }
                }

                //For Capabilities
                // set printTicket constraint to final feature option 
                finalTicketNode = (pcFeatureNodesMap && pcFeatureNodesMap[finalCondition[0]]);
                if (finalTicketNode) {
                    optionNode = finalTicketNode.selectSingleNode(psfPrefix + ":Option[@name='" + finalCondition[1] + "']");
                    if (optionNode && optionNode.getAttribute("constrained") == "psk:None") {
                        optionNode.setAttribute("constrained", getNameWithNs(printCapabilities.XmlNode, pskNs, "PrintTicketSettings"));
                    }
                }
            }
        }

    }// invalidCombinations list loop
    return validateReturn;
}

function updateJobDeviceMariginWhenScalingLfpPcl3GuiBertToDevmode(printTicket, scriptContext, devModeProperties) {
    var productInfo = getProductInfo(printTicket, scriptContext, devModeProperties);
    updateJobDeviceMariginWhenScalingLfpPcl3GuiBert(printTicket, productInfo);
}

function updateJobDeviceMariginWhenScalingLfpPcl3GuiBert(printTicket, productInfo) {
    if (!printTicket || !productInfo) {
        return;
    }

    if (!IsLfpProduct(productInfo)) {
        return;
    }

    if (productInfo && productInfo.productType != Product_type.Product_PCL3GUIBERT) {
        return;
    }

    var scalingFactor = getMarginScaleFactor(printTicket);
    if (scalingFactor != 1) {
        setJobDeviceMariginto0(printTicket);
    }
}

function setJobDeviceMariginto0(printTicket) {
    var jobDeviceMarigin = printTicket.GetFeature("JobDeviceMarigin", venderDefinedNs);
    if (!jobDeviceMarigin || !jobDeviceMarigin.SelectedOption || !jobDeviceMarigin.SelectedOption.Name) {
        return;
    }
    var margin0Name = "Margin0";
    if (jobDeviceMarigin.SelectedOption.Name != margin0Name) {
        var jobDeviceMariginNode = jobDeviceMarigin.XmlNode;
        removeChildElements(jobDeviceMariginNode, psfPrefix + ":Option");
        addChildElement(jobDeviceMariginNode, psfNs, "Option", vendorDefinedPrefix + ":" + margin0Name);
    }
}

function updatePageImageableSize(printTicket, scriptContext, printCapabilities, productInfo) {
    if (!printTicket || !productInfo) {
        return;
    }
    if (!IsLfpProduct(productInfo)) {
        updatePageImageableSizeFromIpp(printTicket, scriptContext, printCapabilities, productInfo);
        return;
    }
    var ptMarginLayoutFeature = printTicket.GetFeature("JobMarginsLayout", venderDefinedNs);
    var ptRemoveBlankAreas = printTicket.GetFeature("JobRemoveBlankAreas", venderDefinedNs);
    var ptScalingMode = printTicket.GetFeature("PageScaling");
    if (IsNeededToReportMargin0ToTheApplication(ptRemoveBlankAreas, ptMarginLayoutFeature, ptScalingMode)) {
        setPageImageableSizeBasedOnMargins(printCapabilities.PageImageableSize, 0, 0, 0, 0);
        return;
    }
    var stdMargin = getUserMarginsValue(printTicket);
    var scalingFactor = getMarginScaleFactor(printTicket);
    setPageImageableSizeBasedOnMargins(printCapabilities.PageImageableSize, Math.round(stdMargin * scalingFactor));
}

function updatePageImageableSizeFromIpp(printTicket, scriptContext, printCapabilities, productInfo) {

    var marginTop, marginBottom, marginLeft, marginRight = 0;

    if (!printTicket || !productInfo || !scriptContext) {
        return;
    }

    var ptDeviceMarginFeature = printTicket.GetFeature("JobDeviceMarigin", venderDefinedNs);
    var ptPageOrientationFeature = printTicket.GetFeature("PageOrientation");
    var valueFromUpb = safeGetUPBString(scriptContext, "MarginFromIPP");

    if (valueFromUpb) {
        var marginList = valueFromUpb.split(",");
        if (marginList.length == 4) {
            try {
                // 1/100 mm to micron
                // based on portraint or height > width
                marginTop = parseInt(marginList[0]) * 10;
                marginBottom = parseInt(marginList[1]) * 10;
                marginLeft = parseInt(marginList[2]) * 10;
                marginRight = parseInt(marginList[3]) * 10;
            }
            catch (e) {
                marginTop = 0;
                marginBottom = 0;
                marginLeft = 0;
                marginRight = 0;
            }
        }
    }

    // without option MarginFromIPP in GPD feature
    if (/*ptDeviceMarginFeature && ptDeviceMarginFeature.SelectedOption && ptDeviceMarginFeature.SelectedOption.Name == "MarginFromIPP"
        && */
        ptDeviceMarginFeature && ptDeviceMarginFeature.SelectedOption && ptDeviceMarginFeature.SelectedOption.Name != "Margin0"
        && (marginTop != marginBottom || marginLeft != marginRight || marginTop != marginRight)) {
        setPageImageableSizeBasedOnMargins(printCapabilities.PageImageableSize, marginTop, marginBottom, marginLeft, marginRight, (ptPageOrientationFeature && ptPageOrientationFeature.SelectedOption && ptPageOrientationFeature.SelectedOption.Name == "Landscape"));
    }

}

function setPageImageableSizeBasedOnMargins(pageImageableSize, marginTop, marginBottom, marginLeft, marginRight, isLandscape) {
    if (!pageImageableSize || !pageImageableSize.ImageableSizeWidthInMicrons || !pageImageableSize.ImageableSizeHeightInMicrons || !marginTop ) {
        return;
    }

    if (!marginBottom || !marginLeft || !marginRight) {
        marginBottom = marginLeft = marginRight = marginTop;
    }

    var imageableAreaProp = getProperty(pageImageableSize.XmlNode, pskNs, "ImageableArea");
    var originHeightProp = getProperty(imageableAreaProp, pskNs, "OriginHeight");
    var originWidthProp = getProperty(imageableAreaProp, pskNs, "OriginWidth");
    var imageableSizeWidthInMicrons = pageImageableSize.ImageableSizeWidthInMicrons;
    var imageableSizeHeightInMicrons = pageImageableSize.ImageableSizeHeightInMicrons;
    var extentWidthProp = getProperty(imageableAreaProp, pskNs, "ExtentWidth");
    var extentHeightProp = getProperty(imageableAreaProp, pskNs, "ExtentHeight");
    //check landscape
    if (imageableSizeWidthInMicrons > imageableSizeHeightInMicrons || isLandscape == true) {
        // page rotate - clockwise only..
        setPropertyValue(originWidthProp, marginTop);
        setPropertyValue(originHeightProp, marginRight);
        setPropertyValue(extentWidthProp, imageableSizeWidthInMicrons - (marginTop + marginBottom));
        setPropertyValue(extentHeightProp, imageableSizeHeightInMicrons - (marginLeft + marginRight));
    }
    //portrait/.
    else {
        setPropertyValue(originWidthProp, marginLeft);
        setPropertyValue(originHeightProp, marginTop);
        setPropertyValue(extentWidthProp, imageableSizeWidthInMicrons - (marginLeft + marginRight));
        setPropertyValue(extentHeightProp, imageableSizeHeightInMicrons - (marginTop + marginBottom));
    }
  
    
}

function IsLfpProduct(productInfo) {
    var isLfp = false;
    if (!productInfo || !productInfo.devCapCategory) {
        return isLfp;
    }

    switch (productInfo.devCapCategory) {
        case "DJ2PCLAT":
        case "DJ2PCLS":
        case "DJ2PCLAZ":
        case "DJ2PST":
        case "DJ2PSZ":
            isLfp = true;
            break;
        default:
            isLfp = false;
            break;
    }

    return isLfp;
}

function IsNeededToReportMargin0ToTheApplication(ptRemoveBlankAreas, ptMarginLayoutFeature, ptScalingMode) {
    var margin0ReportedToApp = false;
    // Cases when the margins reported to the application should be 0
    if ((ptRemoveBlankAreas && ptRemoveBlankAreas.SelectedOption && ptRemoveBlankAreas.SelectedOption.Name == "ON")
        || (ptMarginLayoutFeature && ptMarginLayoutFeature.SelectedOption && (ptMarginLayoutFeature.SelectedOption.Name == "ClipContentsByMargins"
        //|| ptMarginLayoutFeature.SelectedOption.Name == "BorderlessAutomatic"
        //|| ptMarginLayoutFeature.SelectedOption.Name == "BorderlessManual" 
        || ptMarginLayoutFeature.SelectedOption.Name == "Oversize"))
        || (ptScalingMode && ptScalingMode.SelectedOption && ptScalingMode.SelectedOption.Name == "FitToRoll")) {
        margin0ReportedToApp = true;
    }

    return margin0ReportedToApp;
}

function getUserMarginsValue(printTicket) {
    var ptUserMarginsFeature = printTicket.GetFeature("JobUserMargin", venderDefinedNs);
    var result = userMarginValues[0];
    if (ptUserMarginsFeature && ptUserMarginsFeature.SelectedOption && (ptUserMarginsFeature.SelectedOption.Name in userMarginValues)) {
        result = userMarginValues[ptUserMarginsFeature.SelectedOption.Name];
    }

    return result;
}

function getMarginScaleFactor(printTicket) {
    var ptPageScaling = printTicket.GetFeature("PageScaling");
    if (!ptPageScaling || !ptPageScaling.SelectedOption || !ptPageScaling.SelectedOption.Name) {
        return 1;
    }

    var ptPageScalingOptionName = ptPageScaling.SelectedOption.Name;
    var scaleFactor = 1;
    if (ptPageScalingOptionName == "CustomSquare") {
        scaleFactor = getScalingPercentageFactor(printTicket);
    } else if (ptPageScalingOptionName == "FitApplicationImageableSizeToPageImageableSize") {
        scaleFactor = getFitToPaperScalingFactor(printTicket);
    }

    return 1 / scaleFactor;
}

function getScalingPercentageFactor(printTicket) {
    var pageScalingScaleNode = printTicket.GetParameterInitializer("PageScalingScale");
    var pageScalingScale = 100;
    if (pageScalingScaleNode && pageScalingScaleNode.Value) {
        pageScalingScale = pageScalingScaleNode.Value;
    }

    return pageScalingScale / 100.0;
}

function getFitToPaperScalingFactor(printTicket) {
    var mediaSizeFeatureNode = printTicket.GetFeature("PageMediaSize");
    // Word does not provide pagemedia size option in PT
    if (!mediaSizeFeatureNode || !mediaSizeFeatureNode.SelectedOption) {
        return 1;
    }

    var mediaSizeOptionNode = mediaSizeFeatureNode.SelectedOption.XmlNode;
    var mediaSizeWidth = getScoredPropertyValue(mediaSizeOptionNode, pskPrefix + ":MediaSizeWidth");
    var mediaSizeHeight = getScoredPropertyValue(mediaSizeOptionNode, pskPrefix + ":MediaSizeHeight");
    if (!mediaSizeWidth || !mediaSizeHeight) {
        var paramInitMediaSizeWidth = printTicket.GetParameterInitializer("PageMediaSizeMediaSizeWidth");
        var paramInitMediaSizeHeight = printTicket.GetParameterInitializer("PageMediaSizeMediaSizeHeight");
        if (!paramInitMediaSizeWidth || !paramInitMediaSizeHeight || !paramInitMediaSizeWidth.Value || !paramInitMediaSizeHeight.Value) {
            return 1;
        }

        mediaSizeWidth = paramInitMediaSizeWidth.Value;
        mediaSizeHeight = paramInitMediaSizeHeight.Value;
    }

    var paramInitageScalingTargetMediaSizeWidth = printTicket.GetParameterInitializer("PageScalingTargetMediaSizeWidth", venderDefinedNs);
    var paramInitPageScalingTargetMediaSizeHeight = printTicket.GetParameterInitializer("PageScalingTargetMediaSizeHeight", venderDefinedNs);
    if (!paramInitageScalingTargetMediaSizeWidth || !paramInitPageScalingTargetMediaSizeHeight || !paramInitageScalingTargetMediaSizeWidth.Value || !paramInitPageScalingTargetMediaSizeHeight.Value) {
        return 1;
    }

    var pageScalingTargetMediaSizeWidth = paramInitageScalingTargetMediaSizeWidth.Value;
    var pageScalingTargetMediaSizeHeight = paramInitPageScalingTargetMediaSizeHeight.Value;
    return Math.min(pageScalingTargetMediaSizeWidth * 1.0 / mediaSizeWidth, pageScalingTargetMediaSizeHeight * 1.0 / mediaSizeHeight);
}

// Correct Pagesize in Autodesk apps
function correctPageSizeOrientationPrintTicketToDevMode(printTicket, scriptContext, devModeProperties, productInfo) {

    //debugger;

    if (!printTicket || !productInfo) {
        return;
    }

    if (!IsLfpProduct(productInfo)) {
        return;
    }

    var feature = printTicket.GetFeature("PageMediaSize");
    var featureOrientation = printTicket.GetFeature("PageOrientation");
    if (feature == null || feature.selectedOption == null || featureOrientation == null || featureOrientation.selectedOption == null || featureOrientation.selectedOption.Name != "Landscape") {
        devModeProperties.SetInt32("PageMediaSizeWidth", 0);
        devModeProperties.SetInt32("PageMediaSizeHeight", 0);
        devModeProperties.SetString("PageMediaSizeName", "");
        devModeProperties.SetString("PageMediaSizeNs", "");
        return;
    }

    var rootNode = printTicket.XmlNode;
    var pageSizeOptionWidth = getParameterInit(rootNode, pskNs, "PageMediaSizeMediaSizeWidth");
    var pageSizeOptionHeight = getParameterInit(rootNode, pskNs, "PageMediaSizeMediaSizeHeight");
    var width = 0;
    var height = 0;
    if (!pageSizeOptionWidth || !pageSizeOptionHeight) {
        var propertyNodeWidth = getScoredProperty(feature.selectedOption.XmlNode, pskNs, "MediaSizeWidth");
        var propertyNodeHeight = getScoredProperty(feature.selectedOption.XmlNode, pskNs, "MediaSizeHeight");
        if (!propertyNodeWidth || !propertyNodeHeight) {
            devModeProperties.SetInt32("PageMediaSizeWidth", 0);
            devModeProperties.SetInt32("PageMediaSizeHeight", 0);
            devModeProperties.SetString("PageMediaSizeName", "");
            devModeProperties.SetString("PageMediaSizeNs", "");
            return;
        }
        width = getPropertyValue(propertyNodeWidth);
        height = getPropertyValue(propertyNodeHeight);
    } else {
        width = getPropertyValue(pageSizeOptionWidth);
        height = getPropertyValue(pageSizeOptionHeight);

    }

    devModeProperties.SetString("PageMediaSizeName", feature.selectedOption.Name);
    devModeProperties.SetString("PageMediaSizeNs", feature.selectedOption.NamespaceUri);
    devModeProperties.SetInt32("PageMediaSizeWidth", width);
    devModeProperties.SetInt32("PageMediaSizeHeight", height);
}

function correctPageSizeOrientationDevModeToPrintTicket(scriptContext, printTicket, devModeProperties, productInfo) {
    //debugger;
    if (!printTicket || !productInfo) {
        return;
    }

    if (!IsLfpProduct(productInfo)) {
        return;
    }

    var feature = printTicket.GetFeature("PageMediaSize");
    var featureOrientation = printTicket.GetFeature("PageOrientation");
    if (feature == null || feature.selectedOption == null || featureOrientation == null || featureOrientation.selectedOption == null || featureOrientation.selectedOption.Name != "Landscape") {
        return;
    }

    var pageSizeOptionName = devModeProperties.GetString("PageMediaSizeName");
    var pageSizeOptionNs = devModeProperties.GetString("PageMediaSizeNs");
    var pageSizeOptionWidth = devModeProperties.GetInt32("PageMediaSizeWidth");
    var pageSizeOptionHeight = devModeProperties.GetInt32("PageMediaSizeHeight");
    if (!pageSizeOptionName || !pageSizeOptionNs || !pageSizeOptionWidth || !pageSizeOptionHeight) {
        return;
    }

    var rootNode = printTicket.XmlNode;
    var parInitMediaSizeWidth = getParameterInit(rootNode, pskNs, "PageMediaSizeMediaSizeWidth");
    var parInitMediaSizeHeight = getParameterInit(rootNode, pskNs, "PageMediaSizeMediaSizeHeight");
    var width, height;
    if (parInitMediaSizeWidth == null || parInitMediaSizeHeight == null) {
        width = feature.SelectedOption.WidthInMicrons;
        height = feature.SelectedOption.HeightInMicrons;
    } else {
        width = getPropertyValue(parInitMediaSizeWidth);
        height = getPropertyValue(parInitMediaSizeHeight);
    }

    var sameDimensions = width == pageSizeOptionWidth && height == pageSizeOptionHeight;

    if (sameDimensions && (feature.SelectedOption.Name == pageSizeOptionName) ||
        (feature.SelectedOption.Name != "CustomMediaSize" && pageSizeOptionName == "CustomMediaSize")) {
        return;
    }

    var featureNode = feature.XmlNode;
    featureNode.removeChild(featureNode.firstChild);

    if (pageSizeOptionName == "CustomMediaSize") {
        var optionNode = addChildElement(featureNode, psfNs, "Option", pskPrefix + ":" + pageSizeOptionName);
        if (optionNode) {
            addScoredParameter(printTicket, optionNode, "psk:MediaSizeWidth", "psk:PageMediaSizeMediaSizeWidth", pageSizeOptionWidth, "xsd:integer");
            addScoredParameter(printTicket, optionNode, "psk:MediaSizeHeight", "psk:PageMediaSizeMediaSizeHeight", pageSizeOptionHeight, "xsd:integer");
        }
        return;
    }

    if (parInitMediaSizeWidth != null) {
        rootNode.documentElement.removeChild(parInitMediaSizeWidth);
    }

    if (parInitMediaSizeHeight != null) {
        rootNode.documentElement.removeChild(parInitMediaSizeHeight);
    }


    var optionNode = addChildElement(featureNode, psfNs, "Option", prefixes[pageSizeOptionNs] + ":" + pageSizeOptionName);
    if (optionNode) {
        setProperty(optionNode, true, "MediaSizeWidth", pskNs, pageSizeOptionWidth, "integer", xsdNs, true);
        setProperty(optionNode, true, "MediaSizeHeight", pskNs, pageSizeOptionHeight, "integer", xsdNs, true);
    }
}

//quality and resolution
function updatePageOutputQuality(rootElement, featureNodesMap, curUserResVal, productInfo) {
    var ret = 1;
    if (curUserResVal) {
        var pageOutputQuality = (featureNodesMap && featureNodesMap["psk:PageOutputQuality"]) ||
            (rootElement && getFeatureNode(rootElement, "psk:PageOutputQuality", PREFIX_CANONICAL));
        if (pageOutputQuality) {
            var newQualityOption = null;
            if (productInfo.productType != Product_type.Product_PCL3GUIBERT) {
                if (curUserResVal == "ns0000:PQNormal" || curUserResVal == "ns0000:HPS_Normal" || curUserResVal == "ns0000:PQNormalLaser") {
                    newQualityOption = "psk:Normal";
                }
                else if (curUserResVal == "ns0000:HPS_Draft" || curUserResVal == "ns0000:HPS_Economode") {
                    newQualityOption = "psk:Draft";
                }
                else if (curUserResVal == "ns0000:HPS_Best") {
                    newQualityOption = "psk:High";
                }
            }
            else {
                newQualityOption = "psk:High";
            }
            if (newQualityOption) {
                removeChildElements(pageOutputQuality, psfPrefix + ":Option");
                addChildElement(pageOutputQuality, psfNs, "Option", newQualityOption);
                ret = 2;
            }
        }
    }
    return ret;
}
function updatePageOutputQualityForRQueue(printTicket, featureNodesMap, productInfo) {
    var rootElement = printTicket.XmlNode.documentElement;
    var userResolution = (featureNodesMap && featureNodesMap["ns0000:JobUserResolution"]);
    var pageResolution = (featureNodesMap && featureNodesMap["ns0000:PageResolution"]);
    if (userResolution) {
        var userResNode = getSelectedOptionNode(userResolution);
        var curUserResVal = userResNode ? userResNode.getAttribute("name") : null;
        if (curUserResVal) {

            // For HPS_Draft , resolution supported is 300
            if (curUserResVal == "ns0000:HPS_Draft" && pageResolution) {
                removeChildElements(pageResolution, psfPrefix + ":Option");
                pageResValue = "300";
                var optionNode = addChildElement(pageResolution, psfNs, "Option", "ns0000:_300dpi");
                if (optionNode) {
                    var propertyNodeX = addChildElement(optionNode, psfNs, "ScoredProperty", "psk:ResolutionX");
                    var propertyNodeY = addChildElement(optionNode, psfNs, "ScoredProperty", "psk:ResolutionY");
                    if (propertyNodeX) {
                        addValue(propertyNodeX, pageResValue, "xsd:integer");
                    }
                    if (propertyNodeY) {
                        addValue(propertyNodeY, pageResValue, "xsd:integer");
                    }
                }
            }
            // Updating PageOutputQuality based on JobUserResoultuion selected.
            updatePageOutputQuality(rootElement, featureNodesMap, curUserResVal, productInfo);
        }
    }
}

//inputbin
function inputBinAutoSelectConstraintHandling(printCapabilitiesOrTicket, productInfo, featureNodesMap) {
    var ret = 1;
    var rootElement = printCapabilitiesOrTicket.XmlNode.documentElement;
    var JobInputBinNode = (featureNodesMap && featureNodesMap["psk:PageInputBin"]) || (getFeatureNode(rootElement, "psk:PageInputBin", PREFIX_CANONICAL));
    var isPrintCapabilities = rootElement.baseName == "PrintCapabilities";
    if (JobInputBinNode) {
        // constraint to AutoSelect... in capabality.
        if (isPrintCapabilities) {
            var optionNode, optionName;
            var optionNodes = JobInputBinNode.selectNodes(psfPrefix + ":Option");
            for (var i = 0; i < optionNodes.length; i++) {
                optionNode = optionNodes.item(i);
                optionName = getElementName(optionNode, PREFIX_CANONICAL);
                if (optionName && optionName.substring(optionName.indexOf(":") + 1) == "AutoSelect") {
                    optionNode.setAttribute("constrained", getNameWithNs(printCapabilitiesOrTicket.XmlNode, pskNs, "DeviceSettings"));
                    break;
                }
            }
        }
        // change option from AutoSelect to UsePrinterSetting... in ticket
        else {
            optionNodes = getSelectedOptionNode(JobInputBinNode);
            optionName = optionNodes ? optionNodes.getAttribute("name") : null;
            if (optionName && optionName == "psk:AutoSelect") {
                removeChildElements(JobInputBinNode, psfPrefix + ":Option");
                if (productInfo && productInfo.productType == Product_type.Product_PCLmS) {
                    addChildElement(JobInputBinNode, psfNs, "Option", "ns0000:Tray1");
                }
                else {
                    addChildElement(JobInputBinNode, psfNs, "Option", "ns0000:UsePrinterSetting");
                }

                ret = 2;
            }
        }

    }
    return ret;
}

//custom paper in shared printer queue.  
function addCustomPaperSize(printCapabilitiesorTicket, scriptContext, featureNodesMap) {
    var rootElement = printCapabilitiesorTicket.XmlNode.documentElement;
    var isPrintCapabilities = rootElement.baseName == "PrintCapabilities";
    var paperNode = (featureNodesMap && featureNodesMap["psk:PageMediaSize"]) ||
        (getFeatureNode(rootElement, "psk:PageMediaSize", PREFIX_CANONICAL));
    if (paperNode == null) {
        return;
    }
    //add CustomPapersize Name
    if (isPrintCapabilities) {
        var customPaperString = null;
        // exception can be occured in filter because UserProperties can not be accessed in the filter.
        try {
            customPaperString = safeGetString(scriptContext.UserProperties, "CustomMediaSizes");
        }
        catch (e) {
            customPaperString = null;
        }
        if (customPaperString) {
            var customPapers = parseNameValuePairsString(customPaperString);
            var customPaperValue, customPaper, optionNode;
            for (var name in customPapers) {
                customPaperValue = customPapers[name];
                if (customPaperValue) {
                    customPaper = parseCustomPaperValueStringWithCommaDelimeter(customPaperValue);
                    if (customPaper) {
                        optionNode = getOptionNode(paperNode, name);
                        if (optionNode) {
                            removeElement(optionNode);
                        }
                        optionNode = addChildElement(paperNode, psfNs, "Option", name);
                        if (optionNode) {
                            setProperty(optionNode, false, "DisplayName", pskNs, customPaper.dispname, "string", xsdNs, true);
                            setProperty(optionNode, true, "MediaSizeWidth", pskNs, customPaper.width, "integer", xsdNs, true);
                            setProperty(optionNode, true, "MediaSizeHeight", pskNs, customPaper.height, "integer", xsdNs, true);
                        }
                    }
                }
            }
        }
    }
    else {
        var customPaperOptionNode = getOptionNode(paperNode, "psk:CustomMediaSize");
        var paramCustomSizeNameNode, value;
        if (customPaperOptionNode) {
            paramCustomSizeNameNode = getParameterInitNode(printCapabilitiesorTicket.XmlNode, "ns0000:PageMediaSizeCustomSizeName", PREFIX_CANONICAL);
            if (paramCustomSizeNameNode) {
                value = getPropertyValue(paramCustomSizeNameNode);
                setProperty(customPaperOptionNode, false, "DisplayName", pskNs, value, "string", xsdNs, true);
            }
        }
    }
}
// update min/max range for custom paper width/height parameters by UPB "CustomSizeRange"
function updateCustomPaperSizeRange(printCapabilities, scriptContext) {
    var customPaperRangeString = null;
    var sizeList;
    var minPaperWidth, minPaperHeight, maxPaperWidth, maxPaperHeight;
    var paramDefMediaSizeWidthNode, paramDeftMediaSizeHeightNode;
    var propNode;
    // UPB CustomSizeRange (REG_SZ) : MinPrinterWidthInMicrons,MinPrinterHeightInMicrons,MaxPrinterWidthInMicrons,MaxPrinterHeightInMicrons
    // apply these to paramerdef PageMediaSizeMediaSizeWidth / PageMediaSizeMediaSizeHeight
   
    try {
        customPaperRangeString = safeGetString(scriptContext.UserProperties, "CustomSizeRange");
    }
    catch (e) {
        customPaperRangeString = null;
    }
    if (customPaperRangeString) {
        sizeList = customPaperRangeString.split(",");
        if (sizeList.length == 4) {
            try {
                minPaperWidth = parseInt(sizeList[0]);
                minPaperHeight = parseInt(sizeList[1]);
                maxPaperWidth = parseInt(sizeList[2]);
                maxPaperHeight = parseInt(sizeList[3]);
            }
            catch (e) {
                return;
            }
            paramDefMediaSizeWidthNode = getParameterDefNode(printCapabilities.XmlNode, "psk:PageMediaSizeMediaSizeWidth", PREFIX_CANONICAL);
            if (paramDefMediaSizeWidthNode) {
                propNode = getProperty(paramDefMediaSizeWidthNode, psfNs, "MaxValue");
                if (propNode) {
                    setPropertyValue(propNode, maxPaperWidth)
                }
                propNode = getProperty(paramDefMediaSizeWidthNode, psfNs, "MinValue");
                if (propNode) {
                    setPropertyValue(propNode, minPaperWidth)
                }
                propNode = getProperty(paramDefMediaSizeWidthNode, psfNs, "DefaultValue");
                if (propNode) {
                    setPropertyValue(propNode, minPaperWidth)
                }
            }
            paramDeftMediaSizeHeightNode = getParameterDefNode(printCapabilities.XmlNode, "psk:PageMediaSizeMediaSizeHeight", PREFIX_CANONICAL);
            if (paramDeftMediaSizeHeightNode) {
                propNode = getProperty(paramDeftMediaSizeHeightNode, psfNs, "MaxValue");
                if (propNode) {
                    setPropertyValue(propNode, maxPaperHeight)
                }
                propNode = getProperty(paramDeftMediaSizeHeightNode, psfNs, "MinValue");
                if (propNode) {
                    setPropertyValue(propNode, minPaperHeight)
                }
                propNode = getProperty(paramDeftMediaSizeHeightNode, psfNs, "DefaultValue");
                if (propNode) {
                    setPropertyValue(propNode, minPaperHeight)
                }
            }
        }
    }
}

//job destination
function jobDestInfoToPt(printTicket, scriptContext, productInfo, featureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    // job device language and destination
    var dstType = "";
    var destOpt = "";
    // job device language
    // Priority of Job device Language :
    // None -> PDF -> PCL6 -> PCLmS -> PCL -> PS -> Hybrid
    var supportPdl = "";
    var langOpt = "";
    var userId;
    var newUserid;
  
    dstType = safeGetUPBString(scriptContext, "JobDestination");
    if (dstType == "Device") {
        destOpt = "ns0000:Device";
    }
    else if (dstType == "PDF") {
        destOpt = "ns0000:PDF";
    }
    else if (dstType == "LocalNW_Device") {
        destOpt = "ns0000:LocalNW_Device";
    }
    else if (dstType == "PushToClient") {
        // if the login user ID is different from remote printer user ID, set to device so destination selection can be called..
      
        destOpt = "ns0000:PushToClient";
        userId = safeGetUPBString(scriptContext, "JobRoamUserID");
        newUserid = safeGetUPBString(scriptContext, "JobCurrentUserID");
        if (userId && newUserid && userId != newUserid) {
            dstType = "Device";
            destOpt = "ns0000:Device";
        }
    }
    else {
        return;  // if DstType is empty, nothing just return.
    }
    
    // except for PDF, follow the below PDL priority according to the JobPDLs_Supported.
    if (dstType != "PDF") {
        supportPdl = getAppDefinePDL(scriptContext);
        if (supportPdl) {
            if (supportPdl != "PCL") {
                langOpt = "ns0000:" + supportPdl;
            }
            else {
                langOpt = "psk:PCL";
            }
        }
        else {
            if (productInfo.productType == Product_type.Product_PCL3) {
                supportPdl = "PCL"
                langOpt = "psk:PCL";
            }
            else if (productInfo.productType == Product_type.Product_PCLmS) {
                supportPdl = "PCLmS"
                langOpt = "ns0000:PCLmS";
            }
            else if (productInfo.productType == Product_type.Product_PDF) {
                supportPdl = "PCLmS"
                langOpt = "ns0000:PDF";
            }
            else if (productInfo.productType == Product_type.Product_PS) {
                supportPdl = "PS"
                langOpt = "ns0000:PS";
            }
            else if (productInfo.productType == Product_type.Product_PCL3GUIBERT) {
                supportPdl = "PCL3GUIBERT"
                langOpt = "ns0000:PCL3GUIBERT";
            }
            else if (productInfo.productType == Product_type.Product_ADBPDF) {
                supportPdl = "ADBPDF"
                langOpt = "ns0000:ADBPDF";
            }
            else {
                supportPdl = "PCL6"
                langOpt = "ns0000:PCL6";
            }
        }
    }
    // PDF desttype only use PDF rendering
    else {
        langOpt = "ns0000:PDF";
    }
    var jobDevLangFeature = (featureNodesMap && featureNodesMap["psk:JobDeviceLanguage"]) ||
        (rootElement && getFeatureNode(rootElement, "psk:JobDeviceLanguage", PREFIX_CANONICAL));
    if (jobDevLangFeature != null) {
        var jobDevLangOptionNode = getSelectedOptionNode(jobDevLangFeature);
        if (jobDevLangOptionNode != null) {
            var currentlang = jobDevLangOptionNode.getAttribute("name");
            if (currentlang != null && currentlang != langOpt) {
                removeChildElements(jobDevLangFeature, psfPrefix + ":Option")
                addChildElement(jobDevLangFeature, psfNs, "Option", langOpt);
            }
        }
        else {
            addChildElement(jobDevLangFeature, psfNs, "Option", langOpt);
        }
    }
    
    var optionPass = (langOpt == "ns0000:ADBPDF") ? "bpe:true" : "bpe:false";
    var jobUniPassFeature = (featureNodesMap && featureNodesMap["bpe:JobUniversalDriverPdfPassthrough"]) ||
        (rootElement && getFeatureNode(rootElement, "bpe:JobUniversalDriverPdfPassthrough", PREFIX_CANONICAL));
    if (jobUniPassFeature != null) {
        var jobUniPassOptionNode = getSelectedOptionNode(jobUniPassFeature);
        if (jobUniPassOptionNode != null) {
            var name = jobUniPassOptionNode.getAttribute("name");
            if (name != optionPass)
            {
                removeChildElements(jobUniPassFeature, psfPrefix + ":Option")
                jobUniPassOptionNode = addChildElement(jobUniPassFeature, psfNs, "Option", optionPass);
                if (langOpt == "ns0000:ADBPDF" && jobUniPassOptionNode) {
                    var scoredProp = { name: "hp:PDFVersion", value: "2.0", type: "xsd:string" };
                    addScoredProperty(null, jobUniPassOptionNode, null, scoredProp, null);
                }
            }
        }
       
    }
	
	// job destination
    var jobDestFeature = (featureNodesMap && featureNodesMap["ns0000:JobDestination"]) ||
        (rootElement && getFeatureNode(rootElement, "ns0000:JobDestination", PREFIX_CANONICAL));
    if (jobDestFeature != null) {
        var jobDestOptionNode = getSelectedOptionNode(jobDestFeature);
        if (jobDestOptionNode != null) {
            var currentDest = jobDestOptionNode.getAttribute("name");
            if (currentDest != null && currentDest != destOpt) {
                removeChildElements(jobDestFeature, psfPrefix + ":Option")
                jobDestOptionNode = addChildElement(jobDestFeature, psfNs, "Option", destOpt);

                //clear parameter
                // clear parameter related with local/pushtoclient - ip/hostanme/protocol
                if (dstType != "LocalNW_Device" && dstType != "PushToClient") {
                    removeParamInitNode(printTicket, "ns0000:JobLocalNW_Device_IPAddress");
                    removeParamInitNode(printTicket, "ns0000:JobLocalNW_Device_HostName");
                    removeParamInitNode(printTicket, "ns0000:JobLocalNW_Device_Protocols_Supported");
                    removeParamInitNode(printTicket, "ns0000:JobPrivatePickupSettable");
                    removeParamInitNode(printTicket, "ns0000:JobPrivatePickupEnabledInDashboard");

                }
                if (dstType != "LocalNW_Device") {
                    removeParamInitNode(printTicket, "ns0000:JobPDLs_Supported");
                }

                if (dstType != "PushToClient") {
                    removeParamInitNode(printTicket, "ns0000:JobCloudDeliveryType");
                    removeParamInitNode(printTicket, "ns0000:JobRoamUserID");
                    removeParamInitNode(printTicket, "ns0000:JobCloudPrinterUUID");
                }
            }
        }
        else {
            jobDestOptionNode = addChildElement(jobDestFeature, psfNs, "Option", destOpt);
        }

        // common between local/cloud
        if (jobDestOptionNode && (dstType == "LocalNW_Device" || dstType == "PushToClient")) {
            var ipAddress = safeGetUPBString(scriptContext, "JobLocalNW_Device_IPAddress");
            var hostName = safeGetUPBString(scriptContext, "JobLocalNW_Device_HostName");
            var protocol = safeGetUPBString(scriptContext, "JobLocalNW_Device_Protocols_Supported");
            var privatePickupSettable = safeGetUPBString(scriptContext, "JobPrivatePickupSettable");
            var privatePickupEnabledInDashboard = safeGetUPBString(scriptContext, "JobPrivatePickupEnabledInDashboard");

            //IPaddress
            addScoredParameter(printTicket, jobDestOptionNode, "ns0000:IPAddress", "ns0000:JobLocalNW_Device_IPAddress", ipAddress);

            // HostName
            addScoredParameter(printTicket, jobDestOptionNode, "ns0000:HostName", "ns0000:JobLocalNW_Device_HostName", hostName);

            //protocol
            var protocolName = "";
            var protocolArray = ["TCP", "IPP", "IPPS"]; // the protocol array order should be changed to "TCP","IPP","IPPS". this is performance test version
            if (protocol == null) {
                protocol = "TCP";
            }
            var protocol_list = protocol.split(";");
            var jobDelModeFeature = (featureNodesMap && featureNodesMap["ns0000:JobDeliveryMode"]) ||
                (rootElement && getFeatureNode(rootElement, "ns0000:JobDeliveryMode", PREFIX_CANONICAL));
            if (jobDelModeFeature != null) {
                var jobDelModeOptionNode = getSelectedOptionNode(jobDelModeFeature);
                if (jobDelModeOptionNode != null) {
                    var currentOption = jobDelModeOptionNode.getAttribute("name");
                    if (currentOption != null && currentOption == "ns0000:Secure") {
                        protocolName = findInArray(protocol_list, function (o) {
                            return o == "IPPS";
                        });
                    }
                }
            }
            if (!protocolName) {
                for (var i = 0; i < protocolArray.length; ++i) {
                    protocolName = findInArray(protocol_list, function (o) {
                        return o == protocolArray[i];
                    });
                    if (protocolName)
                        break;
                }
            }

            addScoredParameter(printTicket, jobDestOptionNode, "ns0000:Protocols_Supported", "ns0000:JobLocalNW_Device_Protocols_Supported", protocolName);

            // insert scoredporperty and parameter according to PrivatePickupSettable
            addScoredParameter(printTicket, jobDestOptionNode, "ns0000:PrivatePickupSettable", "ns0000:JobPrivatePickupSettable", privatePickupSettable);

            // insert scoredporperty and parameter according to PrivatePickupEnabledInDashboard
            addScoredParameter(printTicket, jobDestOptionNode, "ns0000:PrivatePickupEnabledInDashboard", "ns0000:JobPrivatePickupEnabledInDashboard", privatePickupEnabledInDashboard);

            //set parameters for LocalNW_Device
            if (dstType == "LocalNW_Device") {
                //supportPdl => only one pdl...
                addScoredParameter(printTicket, jobDestOptionNode, "ns0000:PDLs_Supported", "ns0000:JobPDLs_Supported", supportPdl);
            }
            //set parameters for PushToClient
            else if (dstType == "PushToClient") {
                var cloudtype = safeGetUPBString(scriptContext, "JobCloudDeliveryType");
                var cloudPrinterUuid = safeGetUPBString(scriptContext, "JobCloudPrinterUUID");

                //cloudtype : CloudPush / CloudPull / PrintAnywhere / PrivatePickup
                addScoredParameter(printTicket, jobDestOptionNode, "ns0000:CloudDeliveryType", "ns0000:JobCloudDeliveryType", cloudtype);

                // insert scoredporperty and parameter according to JobRoamUserID
                addScoredParameter(printTicket, jobDestOptionNode, "ns0000:RoamUserID", "ns0000:JobRoamUserID", userId);

                // insert scoredporperty and parameter according to JobCloudPushPrinterID
                addScoredParameter(printTicket, jobDestOptionNode, "ns0000:CloudPrinterUUID", "ns0000:JobCloudPrinterUUID", cloudPrinterUuid);

            }

        }

    }// end job destination

}

// vendor property
function jobVarsToPtForRQueue(printTicket, scriptContext, devModeProperties) {
    var rootElement = printTicket.XmlNode.documentElement;
    var prop = getProperty(rootElement, venderDefinedNs, "JobVars");
    if (prop != null)
        rootElement.removeChild(prop);
    prop = addProperty(rootElement, "ns0000:JobVars")
    addProperty(prop, "ns0000:DataType", "String", "xsd:string");
    addProperty(prop, "ns0000:SelectedPreset", devModeProperties.GetString("SelectedPreset"), "xsd:string");
}
function ucdePropertiesToPt(printTicket, scriptContext, devModeProperties) {
    var rootElement = printTicket.XmlNode.documentElement;
    var prop = getProperty(rootElement, venderDefinedNs, "UCDEProperties");
    if (prop != null)
        rootElement.removeChild(prop);
    var valueFromUpb;
    var modelName, queuePortName, networkId, globalDestName;
    var convertMode;

    // add Property for UCDEProperties
    prop = addProperty(rootElement, "ns0000:UCDEProperties")
    addProperty(prop, "ns0000:DataType", "String", "xsd:string");
    // add JobIsRQueue
    addProperty(prop, "ns0000:JobIsRQueue", "true", "xsd:string");
    queuePortName = safeGetString(scriptContext.QueueProperties, "RQueuePortName");
    if (queuePortName) {
        //add JobRQueuePortName
        addProperty(prop, "ns0000:JobRQueuePortName", queuePortName, "xsd:string");
    }
    // add model name
    modelName = getStringFromUPBorDevmode(scriptContext, devModeProperties, "DestName");
    if (modelName != null) {
        //add DestName
        addProperty(prop, "ns0000:DestName", modelName, "xsd:string");
    }
    // add printerdisplayName
    valueFromUpb = safeGetUPBString(scriptContext, "PrinterDisplayName");
    if (valueFromUpb) {
        //add PrinterDisplayName
        addProperty(prop, "ns0000:PrinterDisplayName", valueFromUpb, "xsd:string");
    }
    // if PrinterDisplayName is not existed, replace it as DestName
    else if (modelName != null) {
        //add PrinterDisplayName
        addProperty(prop, "ns0000:PrinterDisplayName", modelName, "xsd:string");
    }

    // addd image path.
    valueFromUpb = getStringFromUPBorDevmode(scriptContext, devModeProperties, "DeviceImagePath");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:DeviceImagePath", valueFromUpb, "xsd:string");
    }

    // addd AskDestConfirmAlways.
    valueFromUpb = getStringFromUPBorDevmodeBool(scriptContext, devModeProperties, "AskDestConfirmAlways");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:AskDestConfirmAlways", valueFromUpb, "xsd:string");
    }

    // addd ShowPrintingTo.
    valueFromUpb = getStringFromUPBorDevmodeBool(scriptContext, devModeProperties, "ShowPrintingTo");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:ShowPrintingTo", valueFromUpb, "xsd:string");
    }

    // add networkID from devmode
    networkId = getStringFromDevmode(devModeProperties, "NetworkID");
    if (networkId) {
        //add networkID
        addProperty(prop, "ns0000:NetworkID", networkId, "xsd:string");
    }

    var globalDestName = getStringFromDevmode(devModeProperties, "GlobalDestName");
    if (globalDestName) {
        //add JobRQueuePortName
        addProperty(prop, "ns0000:GlobalDestName", globalDestName, "xsd:string");
    }

    // add CID property
    valueFromUpb = getStringFromUPBorDevmode(scriptContext, devModeProperties, "CID");
    if (valueFromUpb) {
        //add CID
        addProperty(prop, "ns0000:CID", valueFromUpb, "xsd:string");
    }

    // add JobPrinterUUID
    valueFromUpb = getStringFromUPBorDevmode(scriptContext, devModeProperties, "JobCloudPrinterUUID", "JobPrinterUUID");
    if (valueFromUpb) {
        //add CID
        addProperty(prop, "ns0000:JobPrinterUUID", valueFromUpb, "xsd:string");
    }

    // addd GetPrivatePickupFromDashboardAlways
    valueFromUpb =  getStringFromUPBorDevmodeBool(scriptContext, devModeProperties, "GetPrivatePickupFromDashboardAlways");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:GetPrivatePickupFromDashboardAlways", valueFromUpb, "xsd:string");
    }

    // add JobMDL
    valueFromUpb = getStringFromUPBorDevmode(scriptContext, devModeProperties, "JobMDL");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:JobMDL", valueFromUpb, "xsd:string");
    }

    // add JobProductNumber
    valueFromUpb = getStringFromUPBorDevmode(scriptContext, devModeProperties, "JobProductNumber");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:JobProductNumber", valueFromUpb, "xsd:string");
    }

    // add JobCurrentUserID
    valueFromUpb = safeGetUPBString(scriptContext, "JobCurrentUserID");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:JobCurrentUserID", valueFromUpb, "xsd:string");
    }

    //add NewEnvDestAutoset from UPB True/False => default False
    valueFromUpb = safeGetUPBString(scriptContext, "NewEnvDestAutoset");
    if (valueFromUpb) {
        if (valueFromUpb != "True") {
            addProperty(prop, "ns0000:NewEnvDestAutoset", "False", "xsd:string");
        }
        else {
            addProperty(prop, "ns0000:NewEnvDestAutoset", "True", "xsd:string");
        }
    }

    //Add IRCloudResilience Default: True  it is true from 2021 Dec Release
    addProperty(prop, "ns0000:IRCloudResilience", "True", "xsd:string");

    // add accountLoginId from UPB 
    valueFromUpb = safeGetUPBString(scriptContext, "accountLoginId");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:accountLoginId", valueFromUpb, "xsd:string");
    }

    // add PrivatePickupDashboardSyncVisible
    valueFromUpb = getStringFromUPBorDevmodeBool(scriptContext, devModeProperties, "PrivatePickupDashboardSyncVisible");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:PrivatePickupDashboardSyncVisible", valueFromUpb, "xsd:string");
    }

    // add Printer_Location
    valueFromUpb = safeGetUPBString(scriptContext, "Printer_Location");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:Printer_Location", valueFromUpb, "xsd:string");
    }

    // add Organization. 
    valueFromUpb = safeGetUPBString(scriptContext, "Organization");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:Organization", valueFromUpb, "xsd:string");
    }

    // add StratusID.
    valueFromUpb = safeGetUPBString(scriptContext, "StratusID");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:StratusID", valueFromUpb, "xsd:string");
    }

    // add Account_Type.
    valueFromUpb = safeGetUPBString(scriptContext, "Account_Type");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:Account_Type", valueFromUpb, "xsd:string");
    }

    // add TenantID.
    valueFromUpb = safeGetUPBString(scriptContext, "TenantID");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:TenantID", valueFromUpb, "xsd:string");
    }

    // add OrgType
    valueFromUpb = safeGetUPBString(scriptContext, "OrgType");
    if (valueFromUpb) {
        addProperty(prop, "ns0000:OrgType", valueFromUpb, "xsd:string");
    }

    // add convertMode
    // For Rqueue, defalut convert mode is deep convert.
    try {
        convertMode = devModeProperties.GetInt32("PTConvertMode");
    }
    catch (e) {
        convertMode = 2;
    }
    addProperty(prop, "ns0000:PTConvertMode", convertMode, "xsd:integer");

}
function telemetryDataSetToPt(printTicket, scriptContext, featureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    //get JobTelemetryUserOption feature
    var jobTelemetryUserOption = (featureNodesMap && featureNodesMap["ns0000:JobTelemetryUserOption"]) ||
        (rootElement && getFeatureNode(rootElement, "ns0000:JobTelemetryUserOption", PREFIX_CANONICAL));
    if (jobTelemetryUserOption != null) {
        var jobTelemetryUserOptionNode = getSelectedOptionNode(jobTelemetryUserOption);
        var uPBtelemetryOpt;
        var currentTelemetryOpt;
        // get UserConcent from UPB
        var userConcentStr = safeGetUPBString(scriptContext, "UserConsent");
        if (userConcentStr != null) {
            if (userConcentStr == "True") {
                uPBtelemetryOpt = "ns0000:OptIn";
            }
            else {
                uPBtelemetryOpt = "ns0000:OptOut";
            }
        }
        else {
            return; // if userConcentStr is null, nothing just return.
        }
        // set telemerty option
        if (jobTelemetryUserOptionNode != null) {
            currentTelemetryOpt = jobTelemetryUserOptionNode.getAttribute("name");
            if (currentTelemetryOpt != null && uPBtelemetryOpt != currentTelemetryOpt) {
                removeChildElements(jobTelemetryUserOption, psfPrefix + ":Option")
                jobTelemetryUserOptionNode = addChildElement(jobTelemetryUserOption, psfNs, "Option", uPBtelemetryOpt);
                currentTelemetryOpt = uPBtelemetryOpt;
            }
        }
        else {
            jobTelemetryUserOptionNode = addChildElement(jobTelemetryUserOption, psfNs, "Option", uPBtelemetryOpt);
        }
        //set scored property -DocumentEventJobRepoPath, DocumentappDeployedUUID, and DocumentappDeployedID
        if (jobTelemetryUserOptionNode != null && currentTelemetryOpt == "ns0000:OptIn") {
            //for DocumentEventJobRepoPath
            var jobRepoPath = safeGetUPBString(scriptContext, "EventJsonRepoPath");
            addScoredParameter(printTicket, jobTelemetryUserOptionNode, "ns0000:EventJobRepoPath", "ns0000:DocumentEventJobRepoPath", jobRepoPath);
            //for DocumentappDeployedUUID
            var appDeployedUUID = safeGetUPBString(scriptContext, "appDeployedUUID");
            addScoredParameter(printTicket, jobTelemetryUserOptionNode, "ns0000:appDeployedUUID", "ns0000:DocumentappDeployedUUID", appDeployedUUID);
            //for DocumentappDeployedID
            var appDeployedID = safeGetUPBString(scriptContext, "appDeployedID");
            addScoredParameter(printTicket, jobTelemetryUserOptionNode, "ns0000:appDeployedID", "ns0000:DocumentappDeployedID", appDeployedID);
            //for DocumentappStackType
            var appStackType = safeGetUPBString(scriptContext, "appStackType");
            if (!appStackType) {
                appStackType = "Prod";
            }
            addScoredParameter(printTicket, jobTelemetryUserOptionNode, "ns0000:appStackType", "ns0000:DocumentappStackType", appStackType);
        }
        else {
            removeParamInitNode(printTicket, "ns0000:DocumentEventJobRepoPath");
            removeParamInitNode(printTicket, "ns0000:DocumentappDeployedUUID");
            removeParamInitNode(printTicket, "ns0000:DocumentappDeployedID");
        }
    }
}
function ptToDevmodeUcde(printTicket, scriptContext, devModeProperties) {
    var parentProp = getProperty(printTicket.XmlNode.documentElement, venderDefinedNs, "UCDEProperties");
    var oldGlobalDestName, newGlobalDestName;
    var destName;
    var confrimAlways = false;
    var showPrintingTo = false;
    var childProp, childValue;
    var ptConvertMode = 0;
    var jobExtPT, jobExtPtParamInit;
    var jobDestFeature, jobDestOptionNode, currentDestination;
    var pageRotateFeature, pageRotateOptionNode, currentRotate;
    var newEnvDestAutoset = false;
    var pageScalingFeature, pageScalingOptionNode, currentScaling;
 

    if (parentProp) {
        childProp = getProperty(parentProp, venderDefinedNs, "DestName");
        if (childProp) {
            destName = childProp.firstChild.text
            devModeProperties.SetString("DestName", destName);
        }
        childProp = getProperty(parentProp, venderDefinedNs, "DeviceImagePath");
        if (childProp)
            devModeProperties.SetString("DeviceImagePath", childProp.firstChild.text);
        // set AskDestConfirmAlways
        childProp = getProperty(parentProp, venderDefinedNs, "AskDestConfirmAlways");
        if (childProp) {
            childValue = childProp.firstChild.text;
            if (childValue != null && (childValue == "True" || childValue == "true")) {
                confrimAlways = true;
                devModeProperties.SetBool("AskDestConfirmAlways", 1);
            }
            else {
                confrimAlways = false;
                devModeProperties.SetBool("AskDestConfirmAlways", 0);
            }
        }
        // set ShowPrintingTo
        childProp = getProperty(parentProp, venderDefinedNs, "ShowPrintingTo");
        if (childProp) {
            childValue = childProp.firstChild.text;
            if (childValue != null && (childValue == "True" || childValue == "true")) {
                showPrintingTo = true;
                devModeProperties.SetBool("ShowPrintingTo", 1);
            }
            else {
                showPrintingTo = false;
                devModeProperties.SetBool("ShowPrintingTo", 0);
            }
        }
        // set NetworkID
        childProp = getProperty(parentProp, venderDefinedNs, "NetworkID");
        if (childProp)
            devModeProperties.SetString("NetworkID", childProp.firstChild.text);
        // set global DestName
        childProp = getProperty(parentProp, venderDefinedNs, "GlobalDestName");
        if (childProp) {
            newGlobalDestName = childProp.firstChild.text;
            try {
                oldGlobalDestName = devModeProperties.GetString("GlobalDestName");
            }
            catch (e) {
                oldGlobalDestName = "";
            }
            devModeProperties.SetString("GlobalDestName", newGlobalDestName);
        }
        // set CID
        childProp = getProperty(parentProp, venderDefinedNs, "CID");
        if (childProp)
            devModeProperties.SetString("CID", childProp.firstChild.text);
        //save JobPrinterUUID
        childProp = getProperty(parentProp, venderDefinedNs, "JobPrinterUUID");
        if (childProp)
            devModeProperties.SetString("JobPrinterUUID", childProp.firstChild.text);

        // save GetPrivatePickupFromDashboardAlways
        childProp = getProperty(parentProp, venderDefinedNs, "GetPrivatePickupFromDashboardAlways");
        if (childProp) {
            childValue = childProp.firstChild.text;
            if (childValue != null && (childValue == "True" || childValue == "true")) {
                devModeProperties.SetBool("GetPrivatePickupFromDashboardAlways", 1);
            }
            else {
                devModeProperties.SetBool("GetPrivatePickupFromDashboardAlways", 0);
            }
        }

        // save PrivatePickupDashboardSyncVisible
        childProp = getProperty(parentProp, venderDefinedNs, "PrivatePickupDashboardSyncVisible");
        if (childProp) {
            childValue = childProp.firstChild.text;
            if (childValue != null && (childValue == "True" || childValue == "true")) {
                devModeProperties.SetBool("PrivatePickupDashboardSyncVisible", 1);
            }
            else {
                devModeProperties.SetBool("PrivatePickupDashboardSyncVisible", 0);
            }
        }

        //save JobMDL
        childProp = getProperty(parentProp, venderDefinedNs, "JobMDL");
        if (childProp)
            devModeProperties.SetString("JobMDL", childProp.firstChild.text);

        //save JobProductNumber
        childProp = getProperty(parentProp, venderDefinedNs, "JobProductNumber");
        if (childProp)
            devModeProperties.SetString("JobProductNumber", childProp.firstChild.text);
              
        // decide PTConvertMode from PT/devmode.
        // PTConvertMode - 0: SUPD(skip), 1 : simple convert, 2: deep convert
        //condition1 : Rqueue
        //condition2 : DestName is existed, old and new Destname is same
        //condition3 : AskAlways and showPrintingTo is false
        //condition4 : JobExtPT is existed. => not eixst, set deep Convert
       
        // check jobextPT.
        jobExtPtParamInit = getParameterInit(printTicket.XmlNode, venderDefinedNs, "JobExtPT");
        if (jobExtPtParamInit) {
            jobExtPT = getPropertyValue(jobExtPtParamInit);
        }
        //if jobDestination is device, convert mode 2..
        jobDestFeature = getFeatureNode(printTicket.XmlNode, "ns0000:JobDestination", PREFIX_CANONICAL);
        if (jobDestFeature != null) {
            jobDestOptionNode = getSelectedOptionNode(jobDestFeature);
            if (jobDestOptionNode != null) {
                currentDestination = jobDestOptionNode.getAttribute("name");
            }
        }

        //if PageRotate is AutoRotate, convert mode 2..
        pageRotateFeature = getFeatureNode(printTicket.XmlNode, "ns0000:PageRotate", PREFIX_CANONICAL);
        if (pageRotateFeature != null) {
            pageRotateOptionNode = getSelectedOptionNode(pageRotateFeature);
            if (pageRotateOptionNode != null) {
                currentRotate = pageRotateOptionNode.getAttribute("name");
            }
        }

        // set NewEnvDestAutoset
        childProp = getProperty(parentProp, venderDefinedNs, "NewEnvDestAutoset");
        if (childProp) {
            childValue = childProp.firstChild.text;
            if (childValue != null && (childValue == "True" || childValue == "true")) {
                newEnvDestAutoset = true;
            }
            else {
                newEnvDestAutoset = false;
            }
        }

        //if PageScaling is FitToRoll, convert mode 2..
        pageScalingFeature = getFeatureNode(printTicket.XmlNode, "psk:PageScaling", PREFIX_CANONICAL);
        if (pageScalingFeature != null) {
            pageScalingOptionNode = getSelectedOptionNode(pageScalingFeature);
            if (pageScalingOptionNode != null) {
                currentScaling = pageScalingOptionNode.getAttribute("name");
            }
        }


        //go to destination selection and deep convert.
        if (!destName
            || !newGlobalDestName
            || oldGlobalDestName != newGlobalDestName
            || confrimAlways == true
            || showPrintingTo == true
            || !jobExtPT
            || currentDestination == "ns0000:Device" // add to call destinatio selection, when user is changed.
            || currentRotate == "ns0000:AutoRotate" // add condition for refresh/ARSS
            || newEnvDestAutoset == true // add condition for NewEnvDestAutoSet
            || currentScaling == "ns0000:FitToRoll" // add condition for scaling fittoroll
        ) {
            ptConvertMode = 2;
        }
        else {
            ptConvertMode = 1;
        }
        
        devModeProperties.SetInt32("PTConvertMode", ptConvertMode);
    }
}
function ptToJobVarsForRQueue(printTicket, devModeProperties) {
    var prop = getProperty(printTicket.XmlNode.documentElement, venderDefinedNs, "JobVars");
    if (prop) {
        var prop2 = getProperty(prop, venderDefinedNs, "SelectedPreset");
        if (prop2)
            devModeProperties.SetString("SelectedPreset", prop2.firstChild.text);
    }
}

//dynamic margin
function applyDynamicMargin(printTicket, scriptContext, productInfo, featureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    var dynamicMarginFeature, dynamicMarginOptionNode, selectedOptionName;
    var jobDevLangFeature = (featureNodesMap && featureNodesMap["psk:JobDeviceLanguage"]) ||
        (rootElement && getFeatureNode(rootElement, "psk:JobDeviceLanguage", PREFIX_CANONICAL));
    var jobDestFeature = (featureNodesMap && featureNodesMap["ns0000:JobDestination"]) ||
        (rootElement && getFeatureNode(rootElement, "ns0000:JobDestination", PREFIX_CANONICAL));
    var currentlang = "ns0000:None";
    var currentDest = "ns0000:Device";
    var deviceMarginmm = 0;
    if (jobDevLangFeature != null) {
        var jobDevLangOptionNode = getSelectedOptionNode(jobDevLangFeature);
        if (jobDevLangOptionNode != null) {
            currentlang = jobDevLangOptionNode.getAttribute("name");
        }
    }
    if (jobDestFeature != null) {
        var jobDestOptionNode = getSelectedOptionNode(jobDestFeature);
        if (jobDestOptionNode != null) {
            currentDest = jobDestOptionNode.getAttribute("name");
        }
    }
    dynamicMarginFeature = (featureNodesMap && featureNodesMap["ns0000:JobDeviceMarigin"]) ||
        (rootElement && getFeatureNode(rootElement, "ns0000:JobDeviceMarigin", PREFIX_CANONICAL));
    // Set device margin to 0 - PushToClient with PDF, DeliveryType is Roam, and roamDocumentType is RAW
    if (currentlang == "ns0000:PDF" && currentDest == "ns0000:PushToClient" && productInfo.remoteDeliveryType == "roam" && productInfo.roamDocumentType == "RAW") {
        if (dynamicMarginFeature != null) {
            dynamicMarginOptionNode = getSelectedOptionNode(dynamicMarginFeature);
            selectedOptionName = dynamicMarginOptionNode ? dynamicMarginOptionNode.getAttribute("name") : null;
            if (selectedOptionName != "ns0000:Margin0") {
                removeChildElements(dynamicMarginFeature, psfPrefix + ":Option")
                addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin0");
                selectedOptionName = "ns0000:Margin0";
            }
        }
    }
    // set device marging by CID / borderless
    else if (dynamicMarginFeature && productInfo) {
        dynamicMarginOptionNode = getSelectedOptionNode(dynamicMarginFeature);
        selectedOptionName = dynamicMarginOptionNode ? dynamicMarginOptionNode.getAttribute("name") : null;
        var borderlessPrintingFeature = (featureNodesMap && featureNodesMap["psk:PageBorderless"]) ||
            (rootElement && getFeatureNode(rootElement, "psk:PageBorderless", PREFIX_CANONICAL));
        if (borderlessPrintingFeature) {
            var borderlessPrintingOptionNode = getSelectedOptionNode(borderlessPrintingFeature);
            var selectedborderlessPrintingOptionName = borderlessPrintingOptionNode ? borderlessPrintingOptionNode.getAttribute("name") : null;
            if (selectedborderlessPrintingOptionName == "psk:Borderless") {
                if (selectedOptionName != "ns0000:Margin0") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option")
                    addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin0");
                }
                return;
            }
        }
        var edgeToEdgePrintingFeature = (featureNodesMap && featureNodesMap["ns0000:DocumentMargins"]) ||
            (rootElement && getFeatureNode(rootElement, "ns0000:DocumentMargins", PREFIX_CANONICAL));
        if (edgeToEdgePrintingFeature) {
            var edgeToEdgePrintingOptionNode = getSelectedOptionNode(edgeToEdgePrintingFeature);
            var selectedEdgeToEdgePrintingOptionName = edgeToEdgePrintingOptionNode ? edgeToEdgePrintingOptionNode.getAttribute("name") : null;
            if (selectedEdgeToEdgePrintingOptionName == "ns0000:Alternate") {
                if (selectedOptionName != "ns0000:MarginEdgeToEdge") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option")
                    addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:MarginEdgeToEdge");
                }
                return;
            }
        }

        if (productInfo.dymargin == 100 && selectedOptionName != "ns0000:Margin100") {
            removeChildElements(dynamicMarginFeature, psfPrefix + ":Option");
            dynamicMarginOptionNode = addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin100");
            selectedOptionName = "ns0000:Margin100";
        }
        else if (productInfo.dymargin == 70 && selectedOptionName != "ns0000:Margin70") {
            removeChildElements(dynamicMarginFeature, psfPrefix + ":Option");
            dynamicMarginOptionNode = addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin70");
            selectedOptionName = "ns0000:Margin70";
        }
        else if (productInfo.dymargin == 0 && selectedOptionName != "ns0000:Margin0") {
            removeChildElements(dynamicMarginFeature, psfPrefix + ":Option");
            dynamicMarginOptionNode = addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin0");
            selectedOptionName = "ns0000:Margin0";
        }
        // devicemargin for LFP 5mm
        else if (productInfo.dymargin == 118) {
            // For LFP, JobUserMargin. 3mm/5mm
            var jobUserMarginFeature = (featureNodesMap && featureNodesMap["ns0000:JobUserMargin"]) ||
                (rootElement && getFeatureNode(rootElement, "ns0000:JobUserMargin", PREFIX_CANONICAL));
            if (jobUserMarginFeature != null) {
                var jobUserMarginOptionName = getSelectedOptionName(jobUserMarginFeature, PREFIX_CANONICAL);
                //3mm
                if (jobUserMarginOptionName == "ns0000:__3mm" && selectedOptionName != "ns0000:Margin3mm") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option");
                    dynamicMarginOptionNode = addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin3mm");
                    selectedOptionName = "ns0000:Margin3mm";
                }
                //5mm
                else if (jobUserMarginOptionName == "ns0000:__5mm" && selectedOptionName != "ns0000:Margin5mm") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option");
                    dynamicMarginOptionNode = addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin5mm");
                    selectedOptionName = "ns0000:Margin5mm";
                }
            }
            else {
                // default 5mm
                if (selectedOptionName != "ns0000:Margin5mm") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option");
                    dynamicMarginOptionNode = addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin5mm");
                    selectedOptionName = "ns0000:Margin5mm";
                }
            }
        }
    }
    // set device marging based on margin layout feature
    if (dynamicMarginFeature) {
        var jobMarginsLayoutFeature = (featureNodesMap && featureNodesMap["ns0000:JobMarginsLayout"]) ||
            (rootElement && getFeatureNode(rootElement, "ns0000:JobMarginsLayout", PREFIX_CANONICAL));
        if (jobMarginsLayoutFeature != null) {
            var jobMarginsLayoutOptionNode = getSelectedOptionNode(jobMarginsLayoutFeature);
            if (jobMarginsLayoutOptionNode) {
                var jobMarginsLayoutOptionName = jobMarginsLayoutOptionNode.getAttribute("name");
                if ((jobMarginsLayoutOptionName == "ns0000:Oversize" || jobMarginsLayoutOptionName == "ns0000:ClipContentsByMargins") && selectedOptionName != "ns0000:Margin0") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option")
                    addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin0");
                    selectedOptionName = "ns0000:Margin0";
                }
            }
        }
    }
    // Add margin information to PT for off-center margin product
    if (selectedOptionName && selectedOptionName != "ns0000:Margin0" && selectedOptionName != "ns0000:MarginEdgeToEdge") {
        // set ipp 1/100mm  margin with pre-determinded value.
        if (selectedOptionName == "ns0000:Margin100") {
            deviceMarginmm = 423;
        }
        else if (selectedOptionName == "ns0000:Margin70") {
            deviceMarginmm = 296;
        }
        else if (selectedOptionName == "ns0000:Margin5mm") {
            deviceMarginmm = 499;
        }
        else if (selectedOptionName == "ns0000:Margin3mm") {
            deviceMarginmm = 300;
        }
        addMarginInfoToDynamicMargin(dynamicMarginOptionNode, scriptContext, deviceMarginmm);
    }

}

function addMarginInfoToDynamicMargin(dynamicMarginOptionNode, scriptContext, deviceMarginmm) {
    var valueFromUpb, marginList;
    var marginTop, marginBottom, marginLeft, marginRight = 0;
    var existingProp;
    if (!dynamicMarginOptionNode || !scriptContext || deviceMarginmm <= 0) {
        return;
    }
    valueFromUpb = safeGetUPBString(scriptContext, "MarginFromIPP");
    if (valueFromUpb) {
        marginList = valueFromUpb.split(",");
        if (marginList.length == 4) {
            try {
                // 1/100 mm 
                // based on portraint or height > width
                marginTop = parseInt(marginList[0]);
                marginBottom = parseInt(marginList[1]);
                marginLeft = parseInt(marginList[2]);
                marginRight = parseInt(marginList[3]);
            }
            catch (e) {
                marginTop = 0;
                marginBottom = 0;
                marginLeft = 0;
                marginRight = 0;
            }

            //remove properties
            existingProp = getProperty(dynamicMarginOptionNode, venderDefinedNs, "MarginTop");
            if (existingProp != null)
                dynamicMarginOptionNode.removeChild(existingProp);
            existingProp = getProperty(dynamicMarginOptionNode, venderDefinedNs, "MarginBottom");
            if (existingProp != null)
                dynamicMarginOptionNode.removeChild(existingProp);
            existingProp = getProperty(dynamicMarginOptionNode, venderDefinedNs, "MarginLeft");
            if (existingProp != null)
                dynamicMarginOptionNode.removeChild(existingProp);
            existingProp = getProperty(dynamicMarginOptionNode, venderDefinedNs, "MarginRight");
            if (existingProp != null)
                dynamicMarginOptionNode.removeChild(existingProp);


            //fault-tolerant +-5
            //marginTop
            if (marginTop > 0 && Math.abs(deviceMarginmm - marginTop) > 5) {
                addProperty(dynamicMarginOptionNode, "ns0000:MarginTop", marginTop, "xsd:integer");
            }
            //marginBottom
            if (marginBottom > 0 && Math.abs(deviceMarginmm - marginBottom) > 5) {
                addProperty(dynamicMarginOptionNode, "ns0000:MarginBottom", marginBottom, "xsd:integer");
            }
            //marginLeft
            if (marginLeft > 0 && Math.abs(deviceMarginmm - marginLeft) > 5) {
                addProperty(dynamicMarginOptionNode, "ns0000:MarginLeft", marginLeft, "xsd:integer");
            }
            //marginRight
            if (marginRight > 0 && Math.abs(deviceMarginmm - marginRight) > 5) {
                addProperty(dynamicMarginOptionNode, "ns0000:MarginRight", marginRight, "xsd:integer");
            }
        }
    }
}

function applyDynamicMarginToDevmode(printTicket) {
    var rootElement = printTicket.XmlNode.documentElement;
    var dynamicMarginFeature, dynamicMarginOptionNode, selectedOptionName;
    var borderlessPrintingFeature, borderlessPrintingOptionNode, selectedborderlessPrintingOptionName;
    dynamicMarginFeature = rootElement && getFeatureNode(rootElement, "ns0000:JobDeviceMarigin", PREFIX_CANONICAL);

    // set device marging by borderless
    if (dynamicMarginFeature) {
        dynamicMarginOptionNode = getSelectedOptionNode(dynamicMarginFeature);
        selectedOptionName = dynamicMarginOptionNode ? dynamicMarginOptionNode.getAttribute("name") : null;
        borderlessPrintingFeature = rootElement && getFeatureNode(rootElement, "psk:PageBorderless", PREFIX_CANONICAL);
        if (borderlessPrintingFeature) {
            borderlessPrintingOptionNode = getSelectedOptionNode(borderlessPrintingFeature);
            selectedborderlessPrintingOptionName = borderlessPrintingOptionNode ? borderlessPrintingOptionNode.getAttribute("name") : null;
            if (selectedborderlessPrintingOptionName == "psk:Borderless") {
                if (selectedOptionName != "ns0000:Margin0") {
                    removeChildElements(dynamicMarginFeature, psfPrefix + ":Option")
                    addChildElement(dynamicMarginFeature, psfNs, "Option", "ns0000:Margin0");
                }
                return;
            }
        }
    }

}

function mergeExpandedFeatures(printCapabilities, featureNodesMap) {
    var rootElement = printCapabilities.XmlNode.documentElement;

    for (var key in expandedFeaturesMap) {
        var expandedFeatures = expandedFeaturesMap[key];
        var featureNode = (featureNodesMap && featureNodesMap[key]) ||
            (rootElement && getFeatureNode(rootElement, key, PREFIX_CANONICAL));

        if (featureNode) {
            for (var index in expandedFeatures) {
                var extensionFeatureNode = (featureNodesMap && featureNodesMap[expandedFeatures[index]]) ||
                    (rootElement && getFeatureNode(rootElement, expandedFeatures[index], PREFIX_CANONICAL));

                if (extensionFeatureNode) {
                    var extensionOptionNodes = extensionFeatureNode.selectNodes(psfPrefix + ":Option");
                    for (var i = 0; i < extensionOptionNodes.length; i++) {
                        var extensionOptionNode = extensionOptionNodes.item(i);
                        featureNode.appendChild(extensionOptionNode);
                    }
                    removeElement(extensionFeatureNode);
                }
            }
        }
    }
}

function updateDevmodeToPtForExpandedFeature(printTicket, featureNodesMap, devModeProperties) {
    var rootElement = printTicket.XmlNode.documentElement;

    for (var key in expandedFeaturesMap) {
        var expandedFeatures = expandedFeaturesMap[key];
        var featureNode = (featureNodesMap && featureNodesMap[key]) ||
            (rootElement && getFeatureNode(rootElement, key, PREFIX_CANONICAL));

        if (featureNode != null) {
            var optionNode = getSelectedOptionNode(featureNode);
            var dmFeaturestr = devModeProperties.GetString(key);

            if (optionNode != null) {
                var currentOptionName = optionNode.getAttribute("name");
                if (dmFeaturestr && dmFeaturestr != currentOptionName) {
                    removeChildElements(featureNode, psfPrefix + ":Option")
                    addChildElement(featureNode, psfNs, "Option", dmFeaturestr);
                }
            }
            //Cleanup exisitng extension features from PT
            for (var index in expandedFeatures) {
                extensionFeatureNode = (featureNodesMap && featureNodesMap[expandedFeatures[index]]) ||
                    (rootElement && getFeatureNode(rootElement, expandedFeatures[index], PREFIX_CANONICAL));
                if (extensionFeatureNode) {
                    removeElement(extensionFeatureNode);
                }
            }
        }
    }
}

function updatePtToDevModeForExpandedFeature(printTicket, devModeProperties) {
    var rootElement = printTicket.XmlNode.documentElement;
    for (var key in expandedFeaturesMap) {
        var feature = rootElement && getFeatureNode(rootElement, key, PREFIX_CANONICAL);
        if (feature) {
            var optionNode = getSelectedOptionNode(feature);
            var optionName = optionNode.getAttribute("name");
            devModeProperties.SetString(key, optionName);
        }
    }
}


//validate NUP
function validateNUP(printTicket, featureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    var NUPOptionNode;
    var NUPFeatureNode = (featureNodesMap && featureNodesMap["psk:DocumentNUp"]) ||
        (rootElement && getFeatureNode(rootElement, "psk:DocumentNUp", PREFIX_CANONICAL));
    if (NUPFeatureNode) {
        NUPOptionNode = getSelectedOptionNode(NUPFeatureNode);
        addScoredParameter(printTicket, NUPOptionNode, "ns0000:Gutter", "ns0000:DocumentNUpGutter", 0, "xsd:integer");
    }
}

//validate media size
function validateMediaSize(printTicket, scriptContext, featureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    var mediaSizeOptionNode, mediaSizeOptionName, mediaSizeWidth, mediaSizeHeight;
    var updatedMediaSizeNode, updatedMediaSizeNodeXml;
    var optionNode, optionName;
    var customPaperRangeString, sizeList;
    var minPaperWidth, minPaperHeight, maxPaperWidth, maxPaperHeight;
    var changedToCustomMediaSize = false;
    var paramInitMediaSizeWidthNode, paramInitMediaSizeHeightNode;
    var mediaSizeFeatureNode = (featureNodesMap && featureNodesMap["psk:PageMediaSize"]) ||
        (rootElement && getFeatureNode(rootElement, "psk:PageMediaSize", PREFIX_CANONICAL));
    if (mediaSizeFeatureNode) {
        mediaSizeOptionNode = getSelectedOptionNode(mediaSizeFeatureNode);
        mediaSizeOptionName = mediaSizeOptionNode ? mediaSizeOptionNode.getAttribute("name") : null;
        mediaSizeWidth = getScoredPropertyValue(mediaSizeOptionNode, "psk:MediaSizeWidth");
        mediaSizeHeight = getScoredPropertyValue(mediaSizeOptionNode, "psk:MediaSizeHeight");
        updatedMediaSizeNode = safeGetUPBString(scriptContext, "CapabilityXML");
        if (updatedMediaSizeNode) {
            updatedMediaSizeNodeXml = loadXMLFromString(printTicket, updatedMediaSizeNode);
            if (updatedMediaSizeNodeXml) {
                optionNode = updatedMediaSizeNodeXml.selectSingleNode("//" + psfPrefix + ":Option[@name='" + mediaSizeOptionName + "']");
                if (optionNode) {
                    optionName = getElementName(optionNode, PREFIX_REAL);
                    if (optionName == mediaSizeOptionName && optionNode.getAttribute("constrained") != "psk:None") {
                        removeChildElements(mediaSizeFeatureNode, psfPrefix + ":Option");
                        mediaSizeOptionNode = addChildElement(mediaSizeFeatureNode, psfNs, "Option", "psk:CustomMediaSize");
                        if (mediaSizeOptionNode) {
                            mediaSizeOptionName = "psk:CustomMediaSize";
                            changedToCustomMediaSize = true;
                        }
                    }
                }
                // ****** currently below code not reached.
                else if (mediaSizeOptionName == "psk:CustomMediaSize") {
                    
                    paramInitMediaSizeWidthNode = getParameterInitNode(printTicket.XmlNode, "psk:PageMediaSizeMediaSizeWidth", PREFIX_CANONICAL);
                    paramInitMediaSizeHeightNode = getParameterInitNode(printTicket.XmlNode, "psk:PageMediaSizeMediaSizeHeight", PREFIX_CANONICAL);
                    mediaSizeWidth = getPropertyValue(paramInitMediaSizeWidthNode);
                    mediaSizeHeight = getPropertyValue(paramInitMediaSizeHeightNode);
                    if (!paramInitMediaSizeWidthNode || !paramInitMediaSizeHeightNode || !mediaSizeWidth || !mediaSizeHeight) {
                        return;
                    }

                    var pageOrientationFeatureNode = (featureNodesMap && featureNodesMap["psk:PageOrientation"]) || (rootElement && getFeatureNode(rootElement, "psk:PageOrientation", PREFIX_CANONICAL));
                    var orientationOptionNode, orientationOptionName;
                    if (pageOrientationFeatureNode) {
                        orientationOptionNode = getSelectedOptionNode(pageOrientationFeatureNode);
                        orientationOptionName = orientationOptionNode ? orientationOptionNode.getAttribute("name") : null;
                    }

                    // Fix PageMediaSize synchronization for Autodesk apps when selected PageOrientation is Landscape
                    if (orientationOptionName == "psk:Landscape") {
                        var optionNodes = updatedMediaSizeNodeXml.documentElement.selectNodes(psfPrefix + ":Option");
                        var optionNodeMediaSizeWidth, optionNodeMediaSizeHeight, optionValueMediaSizeWidth, optionValueMediaSizeHeight;
                        var scoredPropDefMediaSizeWidth, scoredPropDefMediaSizeHeight;
                        for (j = 0; j < optionNodes.length; j++) {
                            optionNode = optionNodes.item(j);
                            optionNodeMediaSizeWidth = optionNode.selectSingleNode(psfPrefix + ":ScoredProperty[@name='" + pskPrefix + ":MediaSizeWidth']");
                            optionNodeMediaSizeHeight = optionNode.selectSingleNode(psfPrefix + ":ScoredProperty[@name='" + pskPrefix + ":MediaSizeHeight']");
                            optionValueMediaSizeWidth = getPropertyValue(optionNodeMediaSizeWidth);
                            optionValueMediaSizeHeight = getPropertyValue(optionNodeMediaSizeHeight);
                            if (!optionNodeMediaSizeWidth || !optionNodeMediaSizeHeight || !optionValueMediaSizeWidth || !optionValueMediaSizeHeight) {
                                continue;
                            }

                            if (Math.abs(optionValueMediaSizeHeight - mediaSizeWidth) < 100
                                && Math.abs(optionValueMediaSizeWidth - mediaSizeHeight) < 100) {
                                optionName = getElementName(optionNode, PREFIX_REAL);
                                if (!optionName) {
                                    continue;
                                }

                                mediaSizeOptionName = optionName;
                                removeChildElements(mediaSizeFeatureNode, psfPrefix + ":Option");
                                rootElement.removeChild(paramInitMediaSizeWidthNode);
                                rootElement.removeChild(paramInitMediaSizeHeightNode);

                                mediaSizeOptionNode = addChildElement(mediaSizeFeatureNode, psfNs, "Option", optionName);
                                if (mediaSizeOptionNode) {
                                    scoredPropDefMediaSizeWidth = { name: "psk:MediaSizeWidth", value: optionValueMediaSizeWidth, type: "xsd:integer" };
                                    scoredPropDefMediaSizeHeight = { name: "psk:MediaSizeHeight", value: optionValueMediaSizeHeight, type: "xsd:integer" };
                                    addScoredProperty(null, mediaSizeOptionNode, null, scoredPropDefMediaSizeWidth, null);
                                    addScoredProperty(null, mediaSizeOptionNode, null, scoredPropDefMediaSizeHeight, null);
                                }

                                break;
                            }
                        }
                    }
                }
            }
        }
        // validation customMeidiaSize range for CustomMediaSize
        if (mediaSizeOptionName == "psk:CustomMediaSize") {
            var widthChange = true;
            var heightChange = true;
            if (!changedToCustomMediaSize) {
                paramInitMediaSizeWidthNode = paramInitMediaSizeWidthNode ? paramInitMediaSizeWidthNode:getParameterInitNode(printTicket.XmlNode, "psk:PageMediaSizeMediaSizeWidth", PREFIX_CANONICAL);
                paramInitMediaSizeHeightNode = paramInitMediaSizeHeightNode ? paramInitMediaSizeHeightNode:getParameterInitNode(printTicket.XmlNode, "psk:PageMediaSizeMediaSizeHeight", PREFIX_CANONICAL);
                mediaSizeWidth = getPropertyValue(paramInitMediaSizeWidthNode);
                mediaSizeHeight = getPropertyValue(paramInitMediaSizeHeightNode);
            }
            if (!mediaSizeWidth || !mediaSizeHeight) {
                return;
            }

            minPaperWidth = maxPaperWidth = mediaSizeWidth;
            minPaperHeight = maxPaperHeight = mediaSizeHeight;
            customPaperRangeString = safeGetUPBString(scriptContext, "CustomSizeRange");
            if (customPaperRangeString) {
                sizeList = customPaperRangeString.split(",");
                if (sizeList.length == 4) {
                    try {
                        minPaperWidth = parseInt(sizeList[0]);
                        minPaperHeight = parseInt(sizeList[1]);
                        maxPaperWidth = parseInt(sizeList[2]);
                        maxPaperHeight = parseInt(sizeList[3]);
                    }
                    catch (e) {
                        minPaperWidth = maxPaperWidth = mediaSizeWidth;
                        minPaperHeight = maxPaperHeight = mediaSizeHeight;
                    }
                }
            }
            if (minPaperWidth > mediaSizeWidth) {
                mediaSizeWidth = minPaperWidth;
            }
            else if (maxPaperWidth < mediaSizeWidth) {
                mediaSizeWidth = maxPaperWidth;
            }
            else {
                widthChange = false;
            }

            if (minPaperHeight > mediaSizeHeight) {
                mediaSizeHeight = minPaperHeight;
            }
            else if (maxPaperHeight < mediaSizeHeight) {
                mediaSizeHeight = maxPaperHeight;
            }
            else {
                heightChange = false;
            }

            // create customeMedia sub nodes
            if (changedToCustomMediaSize && mediaSizeOptionNode) {
                addScoredParameter(printTicket, mediaSizeOptionNode, "psk:MediaSizeWidth", "psk:PageMediaSizeMediaSizeWidth", mediaSizeWidth, "xsd:integer");
                addScoredParameter(printTicket, mediaSizeOptionNode, "psk:MediaSizeHeight", "psk:PageMediaSizeMediaSizeHeight", mediaSizeHeight, "xsd:integer");
            }
            //use existing nodes
            else {
                if (paramInitMediaSizeWidthNode && widthChange) {
                    setPropertyValue(paramInitMediaSizeWidthNode, mediaSizeWidth);
                }
                if (paramInitMediaSizeWidthNode && heightChange) {
                    setPropertyValue(paramInitMediaSizeHeightNode, mediaSizeHeight);
                }
               
            }
        }
    }
}

//snapping
function validateAndApplySnapping(printTicket, scriptContext, productInfo, featureNodesMap) {
    if (productInfo && productInfo.supportSnapping == true) {
        var snappingsXmlString = safeGetString(scriptContext.DriverProperties, "Snappings");
        var loadedSnappingsXml = loadXMLFromString(printTicket, snappingsXmlString);
        if (loadedSnappingsXml && !checkTouchbyUser(printTicket, featureNodesMap)) {
            setSnapping(printTicket, featureNodesMap, loadedSnappingsXml);
        }
    }
}
function checkTouchbyUser(printTicket, featureNodesMap) {
    var touchByUser = false;
    var rootElement = printTicket.XmlNode.documentElement;
    var jobTouchByUserNodeFeature = (featureNodesMap && featureNodesMap["ns0000:JobTouchByUser"]) ||
        (rootElement && getFeatureNode(rootElement, "ns0000:JobTouchByUser", PREFIX_CANONICAL));
    if (jobTouchByUserNodeFeature) {
        var jobTouchByUserOptionNode = getSelectedOptionNode(jobTouchByUserNodeFeature);
        var jobTouchByUserOptionNodeName = jobTouchByUserOptionNode.getAttribute("name");
        if (jobTouchByUserOptionNodeName == "ns0000:On")
            touchByUser = true;
        if (jobTouchByUserOptionNodeName == "ns0000:Off")
            touchByUser = false;
    }
    if (!touchByUser && (enableTouchByUser(printTicket, featureNodesMap, "psk:PageMediaType", "ns0000:PageMediaTypePrev") ||
        enableTouchByUser(printTicket, featureNodesMap, "psk:PageInputBin", "ns0000:PageInputBinPrev") ||
        enableTouchByUser(printTicket, featureNodesMap, "psk:PageBorderless", "ns0000:PageBorderlessPrev") ||
        enableTouchByUser(printTicket, featureNodesMap, "ns0000:JobUserResolution", "ns0000:JobUserResolutionPrev"))) {
        touchByUser = true;
    }
    return touchByUser;
}
function enableTouchByUser(printTicket, featureNodesMap, nodeFeatureName, paramInitNodeFeaturePrevName) {
    var touchByUser = false;
    var rootElement = printTicket.XmlNode.documentElement;
    var nodeFeature = (featureNodesMap && featureNodesMap[nodeFeatureName]) ||
        (rootElement && getFeatureNode(rootElement, nodeFeatureName, PREFIX_CANONICAL));
    if (nodeFeature) {
        var nodeOption = getSelectedOptionNode(nodeFeature);
        var nodeOptionName = nodeOption.getAttribute("name");
        var paramInitNodeFeaturePrev = getParameterInitNode(printTicket.XmlNode, paramInitNodeFeaturePrevName, PREFIX_CANONICAL);
        if (paramInitNodeFeaturePrev) {
            var paramInitNodeFeaturePrevValue = getPropertyValue(paramInitNodeFeaturePrev);
            //if previous and current slection does not match
            if (paramInitNodeFeaturePrevValue != nodeOptionName) {
                //update new value
                setParameterInitNode(printTicket.XmlNode, paramInitNodeFeaturePrevName, PREFIX_CANONICAL, nodeOptionName, "xsd:string");
                //update touchByUSer feature to "On"
                var touchByUserNodeFeature = (featureNodesMap && featureNodesMap["ns0000:JobTouchByUser"]) ||
                    (rootElement && getFeatureNode(rootElement, "ns0000:JobTouchByUser", PREFIX_CANONICAL));
                if (touchByUserNodeFeature) {
                    var touchByUserNodeOption = getSelectedOptionNode(touchByUserNodeFeature);
                    var touchByUserNodeOptionName = touchByUserNodeOption.getAttribute("name");
                    if (touchByUserNodeOptionName && touchByUserNodeOptionName != "ns0000:On") {
                        removeChildElements(touchByUserNodeFeature, psfPrefix + ":Option")
                        addChildElement(touchByUserNodeFeature, psfNs, "Option", "ns0000:On");
                        touchByUser = true;
                    }
                }
            }
        }
    }
    return touchByUser;
}
function setSnapping(printTicket, featureNodesMap, snappingDataNode) {
    var rootElement = printTicket.XmlNode.documentElement;
    if (snappingDataNode) {
        var mediaSizeNodeFeature = (featureNodesMap && featureNodesMap["psk:PageMediaSize"]) ||
            (rootElement && getFeatureNode(rootElement, "psk:PageMediaSize", PREFIX_CANONICAL));
        var borderlessNodeFeature = (featureNodesMap && featureNodesMap["psk:PageBorderless"]) ||
            (rootElement && getFeatureNode(rootElement, "psk:PageBorderless", PREFIX_CANONICAL));
        if (mediaSizeNodeFeature && borderlessNodeFeature) {
            var mediaSizeOptionNodeName = getSelectedOptionNode(mediaSizeNodeFeature).getAttribute("name");
            var borderlessOptionNodeName = getSelectedOptionNode(borderlessNodeFeature).getAttribute("name");
            var snapItemsNode = null;
            if (borderlessOptionNodeName == "psk:Borderless") {
                snapItemsNode = snappingDataNode.selectSingleNode("/SnappingData/Snapping[@Option='" + mediaSizeOptionNodeName + "']/BorderlessOn");
            }
            else {
                snapItemsNode = snappingDataNode.selectSingleNode("/SnappingData/Snapping[@Option='" + mediaSizeOptionNodeName + "']/BorderlessOff");
            }
            if (snapItemsNode) {
                var featureName, featureNamePrev, optionName, nodeFeature, nodeCurrentOptionName;
                var snapItems = snapItemsNode.getElementsByTagName("SnapItem");
                for (var i = 0; i < snapItems.length; i++) {
                    featureName = snapItems[i].getAttribute("Feature");
                    featureNamePrev = "ns0000:" + featureName.substring(featureName.indexOf(":") + 1) + "Prev";
                    optionName = snapItems[i].getAttribute("Option");
                    nodeFeature = (featureNodesMap && featureNodesMap[featureName]) ||
                        (rootElement && getFeatureNode(rootElement, featureName, PREFIX_CANONICAL));
                    if (nodeFeature) {
                        nodeCurrentOptionName = getSelectedOptionNode(nodeFeature).getAttribute("name");
                        if (nodeCurrentOptionName && nodeCurrentOptionName != optionName) {
                            removeChildElements(nodeFeature, psfPrefix + ":Option");
                            addChildElement(nodeFeature, psfNs, "Option", optionName);
                        }
                        setParameterInitNode(printTicket.XmlNode, featureNamePrev, PREFIX_CANONICAL, optionName, "xsd:string");
                    }
                }
            }
        }
    }
}

function jobStatusMonitorPT(printTicket, scriptContext, featureNodesMap) {
    var rootElement = printTicket.XmlNode.documentElement;
    var jobStatusMonitor = (featureNodesMap && featureNodesMap["ns0000:JobStatusMonitor"]) ||
        (rootElement && getFeatureNode(rootElement, "ns0000:JobStatusMonitor", PREFIX_CANONICAL));
    var jobStatusMonitorOpt;
    var currentOpt;
      // get JobStatusMonitor from QPB
    var currenJobStatusMonitorOpt = safeGetString(scriptContext.QueueProperties, "Config:CONFIG_NotifyPrinterStatus");
    if (currenJobStatusMonitorOpt != null) {
        if (currenJobStatusMonitorOpt == "False") {
            jobStatusMonitorOpt = "ns0000:Off";
        }
        else {
            jobStatusMonitorOpt = "ns0000:On";
        }
    }
    else {
        jobStatusMonitorOpt = "ns0000:On"
    }

    if (jobStatusMonitor != null) {
        var jobStatusMonitorOptionNode = getSelectedOptionNode(jobStatusMonitor);
        if (jobStatusMonitorOptionNode != null) {
            currentOpt = jobStatusMonitorOptionNode.getAttribute("name");
            if (currentOpt != null && currentOpt != jobStatusMonitorOpt) {
                removeChildElements(jobStatusMonitor, psfPrefix + ":Option");
                addChildElement(jobStatusMonitor, psfNs, "Option", jobStatusMonitorOpt);
            }
        }
        else {
            addChildElement(jobStatusMonitor, psfNs, "Option", jobStatusMonitorOpt);
        }
    }
    // if not existed, create feature.
    else {
        jobStatusMonitor = createChildElement(rootElement, psfNs, "Feature", "ns0000:JobStatusMonitor");
        if (jobStatusMonitor != null) {
            addChildElement(jobStatusMonitor, psfNs, "Option", jobStatusMonitorOpt);
        }
    }
}

function printerAttributeToPt(printTicket, productInfo) {
    var rootElement = printTicket.XmlNode.documentElement;
    var prop = getProperty(rootElement, venderDefinedNs, "PrinterAttributes");
    if (prop != null)
        rootElement.removeChild(prop);

    // add Property for PrinterAttributes
    prop = addProperty(rootElement, "ns0000:PrinterAttributes")
    addProperty(prop, "ns0000:DataType", "String", "xsd:string");

    //devCap type
    if (productInfo.devCapCategory != null) {
        addProperty(prop, "ns0000:RefDevCap", productInfo.devCapCategory, "xsd:string");
    }
    //manual type
    if (productInfo.manualDuplexType != null) {
        addProperty(prop, "ns0000:RefManualType", productInfo.manualDuplexType, "xsd:string");
    }
    //dynamic maring
    addProperty(prop, "ns0000:DyMargin", productInfo.dymargin, "xsd:integer");
    //Output Driection
    addProperty(prop, "ns0000:OutDirection", productInfo.outDirection == Output_Direction.FACEUP ? "FACEUP" : "FACEDOWN", "xsd:string");
    //Rotate For land
    addProperty(prop, "ns0000:RotateForLand", productInfo.rotateForLand == true ? "True" : "False", "xsd:string");
    //support snapping
    addProperty(prop, "ns0000:SupportSnapping", productInfo.supportSnapping == true ? "True" : "False", "xsd:string");
    //roamDocumentType
    if (productInfo.roamDocumentType != null) {
        addProperty(prop, "ns0000:RoamDocumentType", productInfo.roamDocumentType, "xsd:string");
    }
    //remoteDeliveryType
    if (productInfo.remoteDeliveryType != null) {
        addProperty(prop, "ns0000:RemoteDeliveryType", productInfo.remoteDeliveryType, "xsd:string");
    }
    
}

function SetMaxApplicationResolution(printTicket, productInfo, scriptContext, featureNodesMap) {

    if (IsLfpProduct(productInfo))
    {
        var maxAppResolution = safeGetUPBString(scriptContext, "PageMaxAppResolution");
        if (!maxAppResolution) {
            return;
        }

        var rootElement = printTicket.XmlNode.documentElement;
        if (maxAppResolution != "Automatic")
        {
            var pageResolution = (featureNodesMap && featureNodesMap["psk:PageResolution"]) ||
                (rootElement && getFeatureNode(rootElement, "psk:PageResolution", PREFIX_CANONICAL));

            var pageResolutionNode = getSelectedOptionNode(pageResolution);
            var pageResolutionVal = pageResolutionNode ? pageResolutionNode.getAttribute("name") : null;
            var shouldLimit = false;
            var newResolution = "";
            var pageResValue = 0;
            switch (maxAppResolution) {
                case "_300dpi":
                    if (pageResolutionVal != "ns0000:_300dpi") {
                        shouldLimit = true;
                        newResolution = "ns0000:_300dpi";
                        pageResValue = 300;
                    }
                    break;
                case "_600dpi":
                    if (pageResolutionVal == "ns0000:_1200dpi") {
                        shouldLimit = true;
                        newResolution = "ns0000:_600dpi";
                        pageResValue = 600;
                    }
                    break;
                default:

            }

            if (shouldLimit) {
                removeChildElements(pageResolution, psfPrefix + ":Option");
                var optionNode = addChildElement(pageResolution, psfNs, "Option", newResolution);
                if (optionNode) {
                    var propertyNodeX = addChildElement(optionNode, psfNs, "ScoredProperty", "psk:ResolutionX");
                    var propertyNodeY = addChildElement(optionNode, psfNs, "ScoredProperty", "psk:ResolutionY");
                    if (propertyNodeX) {
                        addValue(propertyNodeX, pageResValue, "xsd:integer");
                    }
                    if (propertyNodeY) {
                        addValue(propertyNodeY, pageResValue, "xsd:integer");
                    }
                }
            }               

        }
        var pageMaxAppResolution = (featureNodesMap && featureNodesMap["ns0000:PageMaxAppResolution"]) ||
            (rootElement && getFeatureNode(rootElement, "ns0000:PageMaxAppResolution", PREFIX_CANONICAL));
        removeChildElements(pageMaxAppResolution, psfPrefix + ":Option");
        addChildElement(pageMaxAppResolution, psfNs, "Option", "ns0000:" + maxAppResolution);
            
    }
}

//printcaps function
function extractFeatureValues(printTicket, featureDefs, values) {
    // need to get feature including sub feature.
    var featureDef, featureNode, featureName, optionNodes, optionNode, value;
    var featureNodesMap = getChildElementsMap((printTicket.XmlNode ? printTicket.XmlNode : printTicket), psfPrefix + ":Feature");
    for (var i = 0; i < featureDefs.length; ++i) {
        featureDef = featureDefs[i];
        if (!featureDef)
            continue;
        featureNode = featureNodesMap[featureDef.name];
        if (featureNode) {
            if (featureDef.options || featureDef.source) {
                featureName = (featureDefs.parent ? featureDefs.parent + "+" : "") + featureDef.name;
                optionNodes = featureNode.selectNodes(psfPrefix + ":Option");
                for (var j = 0; j < optionNodes.length; ++j) {
                    optionNode = optionNodes.item(j);
                    value = getElementName(optionNode, PREFIX_CANONICAL);
                    if (value != null) {
                        if (featureDef.pickMany) {
                            values[featureName + "/" + j] = value;
                        }
                        else {
                            values[featureName] = value;
                        }
                    }
                    if (featureDefs.parent) {
                        featureDef.parent = featureDefs.parent;
                    }
                    extractScoredPropertyValues(featureDef, optionNode, j, featureDef.options, value, values)


                    if (!featureDef.pickMany)
                        break;
                }
            }
            if (featureDef.subFeatures) {
                featureDef.subFeatures.parent = featureDef.name;
                extractFeatureValues(featureNode, featureDef.subFeatures, values);
            }
        }
    }
}
function extractParameterValues(printTicket, paramDefs, values) {
    var paramNodesMap = getAllElementsMap(printTicket.XmlNode, psfPrefix + ":ParameterInit");
    var paramDef, paramInitNode, value;
    for (var i = 0; i < paramDefs.length; ++i) {
        paramDef = paramDefs[i];
        if (!paramDef)
            continue;
        paramInitNode = paramNodesMap[paramDef.name];
        if (paramInitNode) {
            value = getPropertyValue(paramInitNode);
            values[paramDef.name] = value;
        }
    }
}
function extractScoredPropertyValues(featureDef, optionNode, optionNumber, optionDefs, optionName, values) {
    var optionDef = findInArray(optionDefs, function (o) {
        var allMatch;
        if (o.name)
            return o.name == optionName;
        else if (o.scoredProps) {
            allMatch = true;
            forEach(o.scoredProps, function (scoredPropDef) {
                /*if (!scoredPropDef.paramRef)*/ { // FUI can generate ScoredProperty with Value even if it is with ParameterRef in PrintCapabilities.
                    var scoredPropValue = getScoredPropertyValue(optionNode, scoredPropDef.name);
                    if (scoredPropDef.value && scoredPropValue != scoredPropDef.value) {
                        allMatch = false;
                        return false; // break
                    }
                }
            });
            return allMatch;
        }
        else if (o.scoredPropsChanges) {
            allMatch = true;
            forEach(o.scoredPropsChanges, function (scoredPropDef) {
                /*if (!scoredPropDef.paramRef)*/ { // FUI can generate ScoredProperty with Value even if it is with ParameterRef in PrintCapabilities.
                    var scoredPropValue = getScoredPropertyValue(optionNode, scoredPropDef.to);
                    if (scoredPropDef.value && scoredPropValue != scoredPropDef.value) {
                        allMatch = false;
                        return false; // break
                    }
                }
            });
            return allMatch;
        }
        return false;
    });
    if (optionDef && optionDef.scoredProps) {
        forEach(optionDef.scoredProps, function (scoredPropDef) {
            /*if (!scoredPropDef.paramRef)*/ { // FUI can generate ScoredProperty with Value even if it is with ParameterRef in PrintCapabilities.
                var scoredPropValue = getScoredPropertyValue(optionNode, scoredPropDef.name);
                if (scoredPropValue != null) {
                    var scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropDef.name, optionNumber);
                    values[scoredPropFullName] = scoredPropValue;
                }
            }
        });
    }
    else if (optionDef && optionDef.scoredPropsChanges) {
        forEach(optionDef.scoredPropsChanges, function (scoredPropDef) {
            /*if (!scoredPropDef.paramRef)*/ { // FUI can generate ScoredProperty with Value even if it is with ParameterRef in PrintCapabilities.
                var scoredPropValue = getScoredPropertyValue(optionNode, scoredPropDef.to);
                if (scoredPropValue != null) {
                    var scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropDef.to, optionNumber);
                    values[scoredPropFullName] = scoredPropValue;
                }
            }
        });
    }
    else if (!optionDef) {
        // HACK: Support for options not defined in PrintCaps (like custom media size)
        var scoredPropNodes = optionNode.selectNodes(psfPrefix + ":ScoredProperty");
        var scoredPropNames = [];
        var paramRefNode, scoredPropNode, scoredPropName, scoredPropFullName, scoredPropValue, scoredPropType;
        for (var j = 0; j < scoredPropNodes.length; ++j) {
            scoredPropNode = scoredPropNodes.item(j);
            scoredPropName = getElementName(scoredPropNode, PREFIX_CANONICAL);
            scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropName, optionNumber);
            scoredPropValue = getPropertyValue(scoredPropNode);
            scoredPropType = getPropertyType(scoredPropNode);
            if (scoredPropValue != null) {
                values[scoredPropFullName] = scoredPropValue;
            }
            else {
                paramRefNode = scoredPropNode.selectSingleNode(psfPrefix + ":ParameterRef");
                if (paramRefNode != null) {
                    var paramRefName = getElementName(paramRefNode, PREFIX_CANONICAL);
                    values[getScoredPropRefName(scoredPropFullName)] = paramRefName;
                }
            }
            if (scoredPropType != null) {
                scoredPropNames.push(scoredPropName + "+" + scoredPropType);
            }
            else {
                scoredPropNames.push(scoredPropName);
            }


        }
        if (scoredPropNames.length > 0) {
            values[getScoredPropsArrayName(featureDef, optionNumber)] = scoredPropNames.join(",");
        }
    }
}
function addFeaturesAndParameters(printCapabilitiesOrPrintTicket, printCaps, featureNodesMap, values) {
    var paramDefsMap = {};
    forEach(printCaps.paramDefs, function (paramDef) {
        paramDefsMap[paramDef.name] = paramDef;
    });
    forEach(printCaps.features, function (featureDef) {
        addFeature(printCapabilitiesOrPrintTicket.XmlNode.documentElement, featureDef, values, featureNodesMap, paramDefsMap);
    });
    var isPrintCapabilities = printCapabilitiesOrPrintTicket.XmlNode.documentElement.baseName == "PrintCapabilities";
    var paramNodesMap = getAllElementsMap(printCapabilitiesOrPrintTicket.XmlNode,
        psfPrefix + (isPrintCapabilities ? ":ParameterDef" : ":ParameterInit"));
    forEach(printCaps.paramDefs, function (paramDef) {
        addParameter(printCapabilitiesOrPrintTicket.XmlNode.documentElement, paramDef, values, paramNodesMap);
    });
}
function addFeature(parentNode, featureDef, values, featureNodesMap, paramDefsMap) {
    var document = parentNode.ownerDocument;
    var isPrintCapabilities = document.documentElement.baseName == "PrintCapabilities";
    var featureNode = addFeatureContainer(parentNode, featureDef, featureNodesMap);
    var selectedOptionNode;
    if (featureNode) {
        var optionNumber, optionName, optionDef, optionNode, scoredPropNamesString, scoredPropNames, scoredPropDefs;
        if (featureDef.source && !isPrintCapabilities) {
            selectedOptionNode = getSelectedOptionNode(featureNode);
            if (selectedOptionNode) {
                removeElement(selectedOptionNode);
            }
            for (optionNumber = 0; ; ++optionNumber) {
                optionName = values[(featureDef.parent ? featureDef.parent + "+" : "") + featureDef.name + (featureDef.pickMany ? "/" + optionNumber : "")]; // may be undefined in case of unnamed Option
                if (!optionName)
                    break;
                optionDef = { name: optionName };
                // scoredProperty format : Name+DataType
                scoredPropNamesString = values[getScoredPropsArrayName(featureDef, optionNumber)];
                if (scoredPropNamesString) {
                    scoredPropNames = scoredPropNamesString.split(",");
                    scoredPropDefs = [];
                    forEach(scoredPropNames, function (scoredPropNameWithType) {
                        var scoredPropValueType = scoredPropNameWithType.split("+");
                        var scoredPropName = scoredPropValueType[0];
                        var scoredPropDef = { name: scoredPropName };
                        var scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropName, optionNumber);
                        var scoredPropValue = values[scoredPropFullName];
                        if (scoredPropValue) {
                            scoredPropDef.value = scoredPropValue;
                            if (scoredPropValueType[1]) {
                                scoredPropDef.type = scoredPropValueType[1];
                            }
                        }
                        else {
                            var scoredPropRefName = values[getScoredPropRefName(scoredPropFullName)];
                            if (scoredPropRefName) {
                                scoredPropDef.paramRef = scoredPropRefName;
                            }
                        }
                        scoredPropDefs.push(scoredPropDef);
                    });
                    optionDef.scoredProps = scoredPropDefs;
                }
                optionNode = addOption(featureDef, featureNode, optionDef, optionNumber, values, paramDefsMap);
                if (!optionNode)
                    break;
                if (!featureDef.pickMany)
                    break;
            }
        }
        else if (featureDef.options) {
            if (isPrintCapabilities) {
                for (var i = 0; i < featureDef.options.length; ++i) {
                    optionDef = featureDef.options[i];
                    if (!optionDef)
                        continue;
                    addOption(featureDef, featureNode, optionDef);
                }
            }
            else {
                for (optionNumber = 0; ; ++optionNumber) {
                    optionName = values[(featureDef.parent ? featureDef.parent + "+" : "") + featureDef.name + (featureDef.pickMany ? "/" + optionNumber : "")]; // may be undefined in case of unnamed Option
                    // find matching option definition (all ScoredProperties with immediate Value should match)
                    // if there is no property with immediate Value defined, then first option definition is taken
                    optionDef = findInArray(featureDef.options, function (o) {
                        if (o.name)
                            return o.name == optionName;
                        else if (o.scoredProps) {
                            var allMatch = true;
                            forEach(o.scoredProps, function (scoredPropDef) {
                                if (!scoredPropDef.paramRef) {
                                    var scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropDef.name, optionNumber);
                                    var scoredPropValue = values[scoredPropFullName];
                                    // HACK for one option with scoredProperies => scoredProperies can be changeable without option change.
                                    if (featureDef.oneOptionWithScoredProp == true && scoredPropValue != null) {
                                        return true;
                                    }
                                    else if (!scoredPropValue || (scoredPropDef.value && scoredPropValue != scoredPropDef.value)) {
                                        allMatch = false;
                                        return false; // break
                                    }
                                }
                            });
                            return allMatch;
                        }
                        return false;
                    });
                    if (!optionDef && !optionName)
                        break;
                    // HACK: support for options which are not defined in PrintCaps
                    var isUnknownOption = !optionDef;
                    if (!optionDef) {
                        optionDef = { name: optionName };
                        // scoredProperty format : Name+DataType
                        scoredPropNamesString = values[getScoredPropsArrayName(featureDef, optionNumber)];
                        if (scoredPropNamesString) {
                            scoredPropNames = scoredPropNamesString.split(",");
                            scoredPropDefs = [];
                            forEach(scoredPropNames, function (scoredPropNameWithType) {
                                var scoredPropValueType = scoredPropNameWithType.split("+");
                                var scoredPropName = scoredPropValueType[0];
                                var scoredPropDef = { name: scoredPropName };
                                var scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropName, optionNumber);
                                var scoredPropValue = values[scoredPropFullName];
                                if (scoredPropValue) {
                                    scoredPropDef.value = scoredPropValue;
                                    if (scoredPropValueType[1]) {
                                        scoredPropDef.type = scoredPropValueType[1];
                                    }
                                }
                                else {
                                    var scoredPropRefName = values[getScoredPropRefName(scoredPropFullName)];
                                    if (scoredPropRefName) {
                                        scoredPropDef.paramRef = scoredPropRefName;
                                    }
                                }
                                scoredPropDefs.push(scoredPropDef);
                            });
                            optionDef.scoredProps = scoredPropDefs;
                        }
                    }
                    if (!isUnknownOption || !findElementNode(featureNode, psfPrefix + ":Option", optionName, PREFIX_CANONICAL)) {
                        if (optionNumber == 0)
                            removeChildElements(featureNode, psfPrefix + ":Option");
                        optionNode = addOption(featureDef, featureNode, optionDef, optionNumber, values, paramDefsMap);
                        if (!optionNode)
                            break;
                    }
                    if (!featureDef.pickMany)
                        break;
                }
            }
        }
        if (featureDef.subFeatures) {
            var subFeature;
            for (var i = 0; i < featureDef.subFeatures.length; ++i) {
                subFeature = featureDef.subFeatures[i];
                if (!subFeature)
                    continue;
                subFeature.parent = featureDef.name;
                addFeature(featureNode, subFeature, values, featureNodesMap, paramDefsMap);
            }
        }
        if (featureDef.removes) {
            if (isPrintCapabilities) {
                for (var i = 0; i < featureDef.removes.length; ++i) {
                    optionDef = featureDef.removes[i];
                    if (!optionDef)
                        continue;
                    removeOption(featureDef, featureNode, optionDef);
                }
            }
        }
        if (featureDef.scoredPropsChanges) {
            if (isPrintCapabilities) {
                changeOptionsScoredProperties(featureDef, featureNode, featureDef.scoredPropsChanges);
            }
        }
    }
    if (!isPrintCapabilities) {
        selectedOptionNode = getSelectedOptionNode(featureNode);
        if (!selectedOptionNode) { // remove empty features
            removeElement(featureNode);
            featureNode = null;
        }
    }
    return featureNode;
}
function addFeatureContainer(parentNode, featureDef, featureNodesMap) {
    var document = parentNode.ownerDocument;
    var isPrintCapabilities = document.documentElement.baseName == "PrintCapabilities";
    var name = featureDef.name;
    var isExistingInGPD = featureDef.inGPD || (featureNodesMap != null && featureNodesMap[name] != null);
    var featureNode = null;
    // isExistion definition should be match with current GPD.
    // the feature is existed in current GPD, the isExisting def should be true.
    if (isExistingInGPD == true) {
        featureNode = (featureNodesMap && featureNodesMap[name]) ||
            (getFeatureNode(parentNode, name, PREFIX_CANONICAL));
        if (featureNode && featureNode.parentNode != parentNode) {
            removeElement(featureNode);
            parentNode.appendChild(featureNode);
        }
    }
    else {
        featureNode = (featureNodesMap && featureNodesMap[name]);
    }

    if (!featureNode) {
        featureNode = createChildElement(parentNode, psfNs, "Feature", name);
        if (isPrintCapabilities) {
            setProperty(featureNode, false, "DisplayName", pskNs, featureDef.dispName || featureDef.name + " Feature", "string", xsdNs, true);
            setProperty(featureNode, false, "SelectionType", psfNs, getNameWithNs(document, pskNs, featureDef.pickMany ? "PickMany" : "PickOne"), "QName", xsdNs, true);
        }
    }

    return featureNode;
}
function addOption(featureDef, featureNode, optionDef, optionNumber, values, paramDefsMap) {
    var name = optionDef.name;
    var document = featureNode.ownerDocument;
    var isPrintCapabilities = document.documentElement.baseName == "PrintCapabilities";
    var optionNode = addChildElement(featureNode, psfNs, "Option", name);

    if (isPrintCapabilities) {
        setProperty(optionNode, false, "DisplayName", pskNs, optionDef.dispName || optionDef.name + " Option", "string", xsdNs, true);
    }
    if (optionDef.scoredProps) {
        forEach(optionDef.scoredProps, function (scoredPropDef) {
            if (!isPrintCapabilities && !scoredPropDef.type && paramDefsMap) {
                // get type from referenced parameter definition
                if (scoredPropDef.paramRef) {
                    var paramDef = paramDefsMap[scoredPropDef.paramRef];
                    if (paramDef) {
                        var typeProp = findInArray(paramDef.props, function (prop) {
                            return prop.name == "psf:DataType";
                        });
                        if (typeProp) {
                            scoredPropDef.type = typeProp.value;
                        }
                    }
                }
            }
            addScoredProperty(featureDef, optionNode, optionNumber, scoredPropDef, values);
        });
    }
    if (optionDef.props) {
        forEach(optionDef.props, function (propDef) {
            addProperty(optionNode, propDef.name, propDef.value, propDef.type);
        });
    }
    if (!name && isElementEmpty(optionNode)) {
        removeElement(optionNode);
        optionNode = null;
    }
    return optionNode;
}
function addScoredProperty(featureDef, optionNode, optionNumber, scoredPropDef, values) {
    var document = optionNode.ownerDocument;
    var isPrintCapabilities = document.documentElement.baseName == "PrintCapabilities";
    var scoredPropFullName, value;
    var propertyNode = addChildElement(optionNode, psfNs, "ScoredProperty", scoredPropDef.name);

    if (isPrintCapabilities) {
        var paramRefName = scoredPropDef.paramRef;
        if (paramRefName) {
            removeChildElements(propertyNode);
            addChildElement(propertyNode, psfNs, "ParameterRef", paramRefName);
        }
        else if (scoredPropDef.value != null) {
            addValue(propertyNode, scoredPropDef.value, scoredPropDef.type);
        }
    }
    else {
        // HACK for one option with scoredProperies => scoredProperies can be changeable without option change.
        if (featureDef && featureDef.oneOptionWithScoredProp == true) {
            scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropDef.name, optionNumber);
            value = values[scoredPropFullName];
            addValue(propertyNode, value, scoredPropDef.type);
        }
        else if (scoredPropDef.value !=null ) { // ScoredProperty value is fixed for current option
            addValue(propertyNode, scoredPropDef.value, scoredPropDef.type);
        }
        else if (scoredPropDef.paramRef) { // ScoredProperty value should be specified via parameter (only if not PickMany feature)
            scoredPropFullName = getScoredPropertyFullName(featureDef, scoredPropDef.name, optionNumber);
            value = values[scoredPropFullName]; // FUI can generate ScoredProperty with Value even if it is with ParameterRef in PrintCapabilities.
            //if (featureDef.pickMany && value) { // add as immediate Value only if feature is PickMany and ScoredProperty was generated with immediate Value by FUI
            if (value || value == "") {
                addValue(propertyNode, value, scoredPropDef.type);
            }
            else if (values[scoredPropDef.paramRef] || values[scoredPropDef.paramRef] == "") { // otherwise, if there is a value for this ScoredProperty (either ParameterRef or immediate), add as ParameterRef
                removeChildElements(propertyNode);
                addChildElement(propertyNode, psfNs, "ParameterRef", scoredPropDef.paramRef);
            }
        }
    }
    if (isElementEmpty(propertyNode)) {
        removeElement(propertyNode);
        propertyNode = null;
    }
    return propertyNode;
}
function addValue(parentNode, value, type) {
    var document = parentNode.ownerDocument;
    removeChildElements(parentNode);
    var valueNode = addChildElement(parentNode, psfNs, "Value");
    setAttributeWithNs(valueNode, xsiNs, "type", toRealNameWithNs(document, type || "xsd:string"));
    valueNode.text = value;
    return valueNode;
}
function removeOption(featureDef, featureNode, optionDef) {
    var name = optionDef.name;
    var optionNode = getOptionNode(featureNode, name);
    if (optionNode) {
        removeElement(optionNode);
    }
}
function changeOptionsScoredProperties(featureDef, featureNode, scoredPropDef) {
    var nextNode = featureNode.firstChild;
    var scoredPropDef, childnode;
    while (nextNode != null) {
        if (nextNode.baseName == "Option") {
            for (var i = 0; i < featureDef.scoredPropsChanges.length; ++i) {
                scoredPropDef = featureDef.scoredPropsChanges[i];
                if (!scoredPropDef)
                    continue;
                childnode = nextNode.firstChild;
                while (childnode != null) {
                    if (childnode.baseName == "ScoredProperty") {
                        if (childnode.getAttribute("name") == scoredPropDef.from)
                            childnode.setAttribute("name", scoredPropDef.to);
                    }
                    childnode = childnode.nextSibling;
                }
            }
        }
        nextNode = nextNode.nextSibling;
    }
}
function addParameter(parentNode, paramDef, values, paramNodesMap) {
    var document = parentNode.ownerDocument;
    var isPrintCapabilities = document.documentElement.baseName == "PrintCapabilities";
    var parameterNode = paramNodesMap && paramNodesMap[paramDef.name];

    if (isPrintCapabilities) {
        if (paramDef.props && paramDef.props.length > 0) {
            if (!parameterNode)
                parameterNode = createChildElement(parentNode, psfNs, "ParameterDef", paramDef.name);
            forEach(paramDef.props, function (propDef) {
                addProperty(parameterNode, propDef.name, propDef.value, propDef.type);
            });
        }
    }
    else {
        var value = values[paramDef.name];
        if (value || value == "") {
            if (!parameterNode)
                parameterNode = createChildElement(parentNode, psfNs, "ParameterInit", paramDef.name);
            var typeProp = findInArray(paramDef.props, function (p) {
                return p.name == "psf:DataType";
            });
            addValue(parameterNode, value, typeProp && typeProp.value);
        }
    }

    return parameterNode;
}
function addProperty(parentNode, name, value, type) {
    var propertyNode = addChildElement(parentNode, psfNs, "Property", name);
    if (value || value == "") {
        addValue(propertyNode, value, type);
    }
    return propertyNode;
}
function makeFeatureValuesMap(printTicket, featureNodes) {
    var values = {};
    var featureNode, featureName, featureValues;
    var optionNodes, optionNode, value, featureValue;
    for (var i = 0; i < featureNodes.length; ++i) {
        featureNode = featureNodes.item(i);
        featureName = getElementName(featureNode, PREFIX_CANONICAL);
        featureValues = [];
        optionNodes = featureNode.selectNodes(psfPrefix + ":Option");
        for (var j = 0; j < optionNodes.length; ++j) {
            optionNode = optionNodes.item(j);
            value = getElementName(optionNode, PREFIX_CANONICAL);
            if (value != null)
                featureValues.push(value);
        }
        featureValue = featureValues.join(",");
        values[featureName] = featureValue;
    }
    return values;
}

// pt function
// for feature
function getFeatureNode(parentNode, name, prefixType) {
    return findElementNode(parentNode, psfPrefix + ":Feature", name, prefixType);
}

//for parameter
function getParameterInitNode(parentNode, name, prefixType) {
    return findElementNode(parentNode, psfPrefix + ":ParameterInit", name, prefixType);
}
function getParameterDefNode(parentNode, name, prefixType) {
    return findElementNode(parentNode, psfPrefix + ":ParameterDef", name, prefixType);
}
function getParameterInit(node, keywordNamespace, propertyName) {
    return searchByAttributeName(
        node,
        psfPrefix + ":ParameterInit",
        keywordNamespace,
        propertyName);
}
function setParameterInitNode(parentNode, name, prefixType, value, type) {
    var param = getParameterInitNode(parentNode, name, prefixType);
    if (!param) {
        param = createChildElement(parentNode.documentElement, psfNs, "ParameterInit", name);
    }
    if (param) {
        addValue(param, value, type);
    }
    return param;
}
function addScoredParameter(printTicket, targetOptionNode, scoredPropertyName, paramName, paramValue, paramValueType) {
    if (targetOptionNode == null || scoredPropertyName == null || paramName == null)
        return;

    var propertyNode = addChildElement(targetOptionNode, psfNs, "ScoredProperty", scoredPropertyName);
    var paramInitNode = getParameterInitNode(printTicket.XmlNode, paramName, PREFIX_CANONICAL);
    addChildElement(propertyNode, psfNs, "ParameterRef", paramName);
    if (paramInitNode) {
        removeChildElements(paramInitNode, psfPrefix + ":Value");
        if (paramValueType == null || paramValueType== "xsd:string" ) {
            addValue(paramInitNode, paramValue ? paramValue : "", "xsd:string");
        }
        else {
            addValue(paramInitNode, paramValue, paramValueType);
        }
    }
    else {
        paramInitNode = createChildElement(printTicket.XmlNode.documentElement, psfNs, "ParameterInit", paramName);
        if (paramValueType == null || paramValueType == "xsd:string") {
            addValue(paramInitNode, paramValue ? paramValue : "", "xsd:string");
        }
        else {
            addValue(paramInitNode, paramValue, paramValueType);
        }
    }
}
function removeParamInitNode(printTicket, paramName) {
    var rootElement = printTicket.XmlNode.documentElement;
    if (paramName == null) {
        return;
    }
    var paramInitNode = getParameterInitNode(printTicket.XmlNode, paramName, PREFIX_CANONICAL);
    if (paramInitNode) {
        rootElement.removeChild(paramInitNode);
        paramInitNode = null;
    }
}

//for option
function getOptionNode(featureNode, optionName, prefixType) {
    var name = parseNameWithNs(featureNode, optionName, prefixType);
    if (!name.name || !name.ns)
        return null;
    var optionNode = searchByAttributeName(featureNode, psfPrefix + ":Option", name.ns, name.name);
    return optionNode;
}
function getSelectedOptionNode(featureNode) {
    var optionNode = featureNode.selectSingleNode(psfPrefix + ":Option");
    return optionNode;
}
function getSelectedOptionName(featureNode, prefixType) {
    var optionNode = featureNode.selectSingleNode(psfPrefix + ":Option");
    return optionNode ? getElementName(optionNode, prefixType) : null;
}

//for property
function getProperty(node, keywordNamespace, propertyName) {
    return searchByAttributeName(
        node,
        psfPrefix + ":Property",
        keywordNamespace,
        propertyName);
}
function getPropertyValue(propertyNode) {
    var valueNode = getPropertyFirstValueNode(propertyNode);
    if (valueNode) {
        var child = valueNode.firstChild;
        if (child) {
            return child.nodeValue;
        }
        else {
            return ""; // if value node existed but child txt is null, do as empty..
        }
            
    }
    return null;
}
function getPropertyType(propertyNode) {
    if (!propertyNode) {
        return null;
    }
    var nodeName = propertyNode.nodeName;
    if ((nodeName.indexOf(":Property") < 0) &&
        (nodeName.indexOf(":ScoredProperty") < 0) &&
        (nodeName.indexOf(":ParameterInit") < 0)) {
        return null;
    }
    var valueNode = getPropertyFirstValueNode(propertyNode);
    if (valueNode) {
        var type = valueNode.getAttribute(xsiPrefix + ":type");
        return type;
    }
    return null;
}
function getPropertyFirstValueNode(propertyNode) {
    if (!propertyNode) {
        return null;
    }
    var nodeName = propertyNode.nodeName;
    if ((nodeName.indexOf(":Property") < 0) &&
        (nodeName.indexOf(":ScoredProperty") < 0) &&
        (nodeName.indexOf(":ParameterInit") < 0)) {
        return null;
    }
    var valueNode = propertyNode.selectSingleNode(psfPrefix + ":Value");
    return valueNode;
}
function setProperty(featureNode, scored, name, nameNs, value, type, typeNs, keepExisting) {
    var document = featureNode.ownerDocument;
    var propertyNode;
    if (scored == true) {
        propertyNode = searchByAttributeName(featureNode, psfPrefix + ":ScoredProperty", nameNs, name);
    }
    else {
        propertyNode = searchByAttributeName(featureNode, psfPrefix + ":Property", nameNs, name);
    }
    if (propertyNode && keepExisting)
        return;
    if (!propertyNode) {
        if (scored == true) {
            propertyNode = document.createNode(NODE_ELEMENT, getNameWithNs(document, psfNs, "ScoredProperty"), psfNs);
        }
        else {
            propertyNode = document.createNode(NODE_ELEMENT, getNameWithNs(document, psfNs, "Property"), psfNs);
        }
        propertyNode.setAttribute("name", getNameWithNs(document, nameNs, name));
        featureNode.appendChild(propertyNode);
    }
    var valueNode = propertyNode.selectSingleNode(psfPrefix + ":Value");
    if (!valueNode) {
        valueNode = document.createNode(NODE_ELEMENT, getNameWithNs(document, psfNs, "Value"), psfNs);
        propertyNode.appendChild(valueNode);
    }
    setAttributeWithNs(valueNode, xsiNs, "type", getNameWithNs(document, typeNs, type));
    valueNode.text = value;
}
function setPropertyValue(propertyNode, value) {
    var valueNode = getPropertyFirstValueNode(propertyNode);
    if (valueNode) {
        var child = valueNode.firstChild;
        if (child) {
            child.nodeValue = value;
            return child;
        }
    }
    return null;
}
function getScoredProperty(node, keywordNamespace, scoredPropertyName) {
    return searchByAttributeName(
        node,
        psfPrefix + ":ScoredProperty",
        keywordNamespace,
        scoredPropertyName);
}
function getScoredPropertyValue(optionNode, name) {
    var scoredPropertyNode = findElementNode(optionNode, psfPrefix + ":ScoredProperty", name, PREFIX_CANONICAL);
    if (!scoredPropertyNode)
        return null;
    var value = getPropertyValue(scoredPropertyNode);
    return value;
}
function getScoredPropertyFullName(featureDef, scoredPropName, optionNumber) {
    if (featureDef.pickMany)
        return (featureDef.parent ? featureDef.parent + "+" : "") + featureDef.name + "/" + optionNumber + "/" + scoredPropName;
    else
        return (featureDef.parent ? featureDef.parent + "+" : "") + featureDef.name + "/" + scoredPropName;
}
function getScoredPropsArrayName(featureDef, optionNumber) {
    return (featureDef.parent ? featureDef.parent + "+" : "") + featureDef.name + (featureDef.pickMany ? "/" + optionNumber : "") + "/sprops";
}
function getScoredPropRefName(scoredPropFullName) {
    return scoredPropFullName + "/ref";
}
function getScoredPropertyParamRefName(optionNode, name) {
    var scoredPropertyNode = findElementNode(optionNode, psfPrefix + ":ScoredProperty", name, PREFIX_CANONICAL);
    if (!scoredPropertyNode)
        return null;
    var paramRefNode = scoredPropertyNode.selectSingleNode(psfPrefix + ":ParameterRef");
    if (!paramRefNode)
        return null;
    var paramname = getElementName(paramRefNode, PREFIX_CANONICAL);;
    return paramname;
}
function insertQNameScoredProperty(optionNode, name, value) {
    var propertyNode = addChildElement(optionNode, psfNs, "ScoredProperty", name);
    addValue(propertyNode, value, "xsd:QName");
    return propertyNode;
}

//xml element function
function getChildElementsMap(parentNode, tagName) {
    var parentElement = parentNode.documentElement ? parentNode.documentElement : parentNode;
    var map = {};
    var node, name, prevNode, isNodeNested, isPrevNodeNested;
    var nodes = parentElement.selectNodes(tagName);
    for (var i = 0; i < nodes.length; ++i) {
        node = nodes.item(i);
        name = getElementName(node, PREFIX_REAL);
        prevNode = map[name];
        if (prevNode) { // duplicate feature detected
            isNodeNested = node.parentNode != parentElement;
            isPrevNodeNested = prevNode.parentNode != parentElement;
            if (!isNodeNested && isPrevNodeNested) // prefer nested feature
                node = prevNode;
        }
        map[name] = node;
    }
    return map;
}
function getAllElementsMap(parentNode, tagName) {
    var documentRoot = parentNode.ownerDocument ? parentNode.ownerDocument.documentElement : parentNode.documentElement;
    var map = {};
    var node, name, prevNode, isNodeNested, isPrevNodeNested;
    var nodes = documentRoot.selectNodes(tagName);
    for (var i = 0; i < nodes.length; ++i) {
        node = nodes.item(i);
        name = getElementName(node, PREFIX_CANONICAL);
        prevNode = map[name];
        if (prevNode) { // duplicate feature detected
            isNodeNested = node.parentNode != documentRoot;
            isPrevNodeNested = prevNode.parentNode != documentRoot;
            if (!isNodeNested && isPrevNodeNested) // prefer nested feature
                node = prevNode;
        }
        map[name] = node;
    }
    return map;
}
function findElementNode(parentNode, tag, elementName, prefixType) {
    var name = parseNameWithNs(parentNode, elementName, prefixType);
    if (!name.name || !name.ns)
        return null;
    var node = searchByAttributeName(parentNode, tag, name.ns, name.name);
    return node;
}
function getElementName(optionNode, prefixType) {
    var realName = optionNode.getAttribute("name");
    if (!realName)
        return null;
    if (prefixType == PREFIX_REAL)
        return realName;
    var name = parseNameWithNs(optionNode, realName, PREFIX_REAL);
    if (!name.name || !name.ns)
        return null;
    var optionName = getNameWithNs(optionNode, name.ns, name.name, prefixType);
    return optionName;
}
function addChildElement(parentNode, tagNs, tagName, nameCanonical) {
    var document = parentNode.ownerDocument;
    var child = nameCanonical ?
        findElementNode(parentNode, getNameWithNs(document, tagNs, tagName, PREFIX_CANONICAL), nameCanonical, PREFIX_CANONICAL) : null;
    if (!child) {
        child = createChildElement(parentNode, tagNs, tagName, nameCanonical);
    }
    return child;
}
function createChildElement(parentNode, tagNs, tagName, nameCanonical) {
    var document = parentNode.ownerDocument;
    var child = document.createNode(NODE_ELEMENT, getNameWithNs(document, tagNs, tagName), tagNs);
    if (nameCanonical) {
        child.setAttribute("name", toRealNameWithNs(document, nameCanonical));
    }
    parentNode.appendChild(child);
    return child;
}
function removeElement(elementNode) {
    if (elementNode.parentNode) {
        elementNode.parentNode.removeChild(elementNode);
    }
}
function removeChildElements(elementNode, name) {
    var child;
    var childElements = elementNode.selectNodes(name || "*");
    for (var i = 0; i < childElements.length; ++i) {
        child = childElements.item(i);
        elementNode.removeChild(child);
    }
}
function isElementEmpty(elementNode) {
    var childElements = elementNode.selectNodes("*");
    return childElements.length == 0;
}

// Xml node function
function setSelectionNamespace(xmlNode, prefix, namespace) {
    xmlNode.setProperty(
        "SelectionNamespaces",
        "xmlns:"
        + prefix
        + "='"
        + namespace
        + "'"
    );
}
function searchByAttributeName(node, tagName, keywordNamespace, nameAttribute) {
    if (!node ||
        !tagName ||
        !keywordNamespace ||
        !nameAttribute) {
        return null;
    }
    var xPathQuery = "descendant::"
        + tagName
        + "[substring-after(@name,':')='"
        + nameAttribute
        + "']"
        + "[name(namespace::*[.='"
        + keywordNamespace
        + "'])=substring-before(@name,':')]"
        ;
    return node.selectSingleNode(xPathQuery);
}
function getPrefixForNamespace(node, namespace) {
    if (!node) {
        return null;
    }
    // navigate to the root element of the document.
    var rootNode = node.documentElement;
    // Query to retrieve the list of attribute nodes for the current node
    // that matches the namespace in the 'namespace' variable.
    var xPathQuery = "namespace::node()[.='"
        + namespace
        + "']";
    var namespaceNode = rootNode.selectSingleNode(xPathQuery);
    if (!namespaceNode)
        return null;
    return namespaceNode.baseName;
}
function getNamespaceForPrefix(node, prefix) {
    if (!node) {
        return null;
    }
    // navigate to the root element of the document.
    var rootNode = node.ownerDocument ? node.ownerDocument.documentElement : node.documentElement;
    // Query to retrieve the list of attribute nodes for the current node
    // that matches the namespace in the 'namespace' variable.
    var xPathQuery = "namespace::node()[name(.)='"
        + prefix
        + "']";
    var namespaceNode = rootNode.selectSingleNode(xPathQuery);
    if (!namespaceNode)
        return null;
    return namespaceNode.value;
}

//xml namespace
function toRealNameWithNs(node, nameWithNs) {
    var parsedName = parseNameWithNs(null, nameWithNs, PREFIX_CANONICAL);
    var realNameWithNs = getNameWithNs(node, parsedName.ns, parsedName.name, PREFIX_REAL);
    return realNameWithNs;
}
function getNameWithNs(node, ns, name, prefixType) {
    var prefix = prefixType != PREFIX_CANONICAL ? getPrefixForNamespace(node, ns) :
        prefixes[ns];
    if (!prefix)
        return null;
    return prefix + ":" + name;
}
function parseNameWithNs(node, nameWithNs, prefixType) {
    var parts = nameWithNs.split(':', 2);
    var prefix = parts.length > 1 ? parts[0] : null;
    var localName = parts.length > 1 ? parts[1] : parts[0];
    var ns = prefix == null ? null :
        prefixType == PREFIX_REAL ? getNamespaceForPrefix(node, prefix) :
            namespaces[prefix];
    return { ns: ns, name: localName };
}
function setAttributeWithNs(element, attributeNs, attributeName, value) {
    var document = element.ownerDocument;
    var attributeNode = document.createNode(NODE_ATTRIBUTE, getNameWithNs(document, xsiNs, "type"), xsiNs);
    attributeNode.value = value;
    element.setAttributeNode(attributeNode);
}

//property bag function
function safeGetString(propertyBag, name) {
    try {
        var str = propertyBag.GetString(name);
        return str;
    }
    catch (e) {
        return null;
    }
}
function safeGetByteArrays(propertyBag, name) {
    try {
        var bytearrays = propertyBag.GetBytes(name);
        return bytearrays;
    }
    catch (e) {
        return null;
    }
}
function loadXMLFromString(printTicket, str) {
    try {
        var ticketXmlNode = printTicket.XmlNode;
        var strXML = ticketXmlNode.cloneNode(false);
        strXML.loadXML(str);
        if (strXML.documentElement != null) {
            return strXML;
        }
    }
    catch (e) {
        return null;
    }
    return null;
}
function safeGetUPBString(scriptContext, upbName) {
    var stringValue;
    try {
        stringValue = safeGetString(scriptContext.UserProperties, upbName);
    }
    catch (e) {
        stringValue = null;
    }
    return stringValue;
}
function getStringFromUPBorDevmode(scriptContext, devModeProperties, upbName, devmodeName) {
    var stringValue = "";

    if (!upbName)
        return;

    // if it existed in user property bag, use it first.
    try {
        stringValue = safeGetString(scriptContext.UserProperties, upbName);
    }
    catch (e) {
        stringValue = null;
    }
    if (stringValue == null) {
        try {
            stringValue = devModeProperties.GetString(devmodeName ? devmodeName : upbName);
        }
        catch (e) {
            stringValue = "";
        }
    }
    return stringValue;
}
function getStringFromUPBorDevmodeBool(scriptContext, devModeProperties, upbName, devmodeName) {
    var stringValue = "";

    if (!upbName)
        return;

    // if it existed in user property bag, use it first.
    try {
        stringValue = safeGetString(scriptContext.UserProperties, upbName);
    }
    catch (e) {
        stringValue = null;
    }
    if (!stringValue) {
        try {
            var stringBoolean = devModeProperties.GetBool(devmodeName ? devmodeName : upbName);
            if (stringBoolean == 1) {
                stringValue = "True";
            }
            else {
                stringValue = "False";
            }
        }
        catch (e) {
            stringValue = "False";
        }
    }
    return stringValue;
}
function getStringFromDevmode(devModeProperties, devmodeName) {
    var stringValue = "";

    if (!devmodeName)
        return;

    try {
        stringValue = devModeProperties.GetString(devmodeName ? devmodeName : upbName);
    }
    catch (e) {
        stringValue = null;
    }

    return stringValue;
}

//utility function
function parseNameValuePairsString(nameValuePairsString) {
    var values = {};
    if (nameValuePairsString) {
        var pair, parts, name, value;
        var nameValuePairs = nameValuePairsString.split(";");
        for (var i = 0; i < nameValuePairs.length; ++i) {
            pair = nameValuePairs[i];
            parts = split2(pair, "=");
            name = parts[0].trim();
            if (!name)
                continue;
            value = parts.length > 1 ? parts[1] : null;
            if (value) {
                if (value == "%00") {
                    value = "";
                } else {
                    value = value.replace(/%3B/g, ";");
                    value = value.replace(/%25/g, "%");
                }
            }
            values[name] = value;
        }
    }
    return values;
}
function parseCustomPaperValueStringWithCommaDelimeter(valuesString) {
    var customPaper = {};
    if (valuesString) {
        var valueList = valuesString.split(",");
        if (valueList.length == 3) {
            var dispalyname = valueList[0];
            if (dispalyname) {
                dispalyname = dispalyname.replace(/%2C/g, ",");
                dispalyname = dispalyname.replace(/%25/g, "%");
            }
            customPaper.dispname = dispalyname;
            var widthStr = valueList[1];
            if (widthStr) {
                customPaper.width = parseInt(widthStr);
            }
            var heightStr = valueList[2];
            if (heightStr) {
                customPaper.height = parseInt(heightStr);
            }
        }
    }
    return customPaper;
}
function makeNameValuePairsString(values, separator) {
    separator = separator || ";\r\n";
    var valuePairs = [];
    var value;
    for (var name in values) {
        value = values[name];
        if (value) {
            value = value.replace(/%/g, "%25");
            value = value.replace(/;/g, "%3B");
        } else {
            value = "%00";  // specify NULL value.
        }

        valuePairs.push(name + "=" + value);
    }
    var str = valuePairs.join(separator);
    return str;
}
function findInArray(array, predicate) {
    if (!array) return;
    var item;
    for (var i = 0; i < array.length; ++i) {
        item = array[i];
        if (!item)
            continue;
        if (predicate(item))
            return item;
    }
}
function includedInArray(array, item) {
    if (!array) return false;
    for (var i = 0; i < array.length; ++i) {
        if (item == array[i]) {
            return true;
        }
    }
    return false;
}
function forEach(array, action) {
    if (!array) return;
    var item;
    for (var i = 0; i < array.length; ++i) {
        item = array[i];
        if (!item)
            continue;
        var result = action(item);
        if (result === false)
            break;
    }
}
function split2(str, separator) {
    var index = str.indexOf(separator);
    if (index >= 0) {
        return [str.substr(0, index), str.substr(index + 1)];
    }
    else {
        return [str];
    }
}

function setNamespace(node, nameSpace, nameSpaceUrl) {
    var optionNode = node.documentElement;

    try {
        optionNode.setAttribute("xmlns:" + nameSpace, nameSpaceUrl);
    } catch (e) {
        // Not failing. Using defaults
    }
}
