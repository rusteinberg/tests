//Extension Script

var nuanria = nuanria || {};

// This is needed for ability to call JS API loaded by page itself. In Chrome and Firefox
// scripts are running in separate sandboxes, so extension doe not have access to the page's
// internal scripts.
nuanria.ScriptBridge = function(wnd, loadCallback)
{
	"use strict";

	this.invokeFunction = invokeFunction;
	this.invokeScript = invokeScript;

	var responseTimeout = 2000;

	var bridgeId = Math.floor(Math.random() * 0xFFFF); //Generate random ID in order to filter own responses only 
	var bridgeResponseEventName = 'nuanria-ScriptBridge-response: ' + bridgeId;
	var eventId = 0;

	var responseQueue = {};

	setTimeout(inject);

	function inject()
	{
		try
		{
			// The injected script should be running in the context of page. That can be done via
			// inserting SCRIPT element into the DOM
			var ScriptElement = wnd.document.createElement('script');
			if (nuanria.utils.isChrome())
			{
				ScriptElement.src = chrome.extension.getURL('jslib/nuanria.PageContext.js');
			}
			else if (nuanria.utils.isFirefox())
			{
				ScriptElement.src = browser.extension.getURL('jslib/nuanria.PageContext.js');
			}
			else if (nuanria.utils.isIE())
			{
				//TODO: Add IE support
			}
			(wnd.document.head || wnd.document.documentElement).appendChild(ScriptElement);
			ScriptElement.onload = function()
			{
				ScriptElement.parentNode.removeChild(ScriptElement);
				if (loadCallback)
				{
					setTimeout(loadCallback);
				}
			};

			wnd.addEventListener(bridgeResponseEventName, onInjectedScriptResponse);
		}
		catch (err)
		{
			if (nuanria.utils)
			{
				nuanria.utils.logError('ScriptBridge inject Error: ' + err.stack);
			}
			else if (console)
			{
				console.log('ScriptBridge inject Error: ' + err.stack);
			}
		}
	}

	function invokeFunction(Name, argsArr, noResponse, optionalFn)
	{
		try
		{
			if (!argsArr)
			{
				// Create empty array for undefined/null argument
				argsArr = [];
			}
			if (argsArr.constructor !== Array)
			{
				nuanria.utils.logError('ScriptBridge - invokeFunction Error: Invalid arguments');
				return false;
			}

			var fnData = {};
			fnData.type = 'function';
			fnData.Name = Name;
			fnData.args = argsArr;
			fnData.optional = optionalFn; // True if this JS is optional/may not exist.
			fnData.needResponse = !noResponse;

			return invoke(fnData);
		}
		catch (err)
		{
			nuanria.utils.logError('ScriptBridge invokeFunction Error: ' + err.stack);
		}
	}

	function invokeScript(Script, noResponse)
	{
		try
		{
			var scriptData = {};
			scriptData.type = 'script';
			scriptData.Script = Script;
			scriptData.needResponse = !noResponse;

			return invoke(scriptData);
		}
		catch (err)
		{
			nuanria.utils.logError('ScriptBridge invokeScript Error: ' + err.stack);
		}
	}

	function invoke(data)
	{
		data.responseEvent = bridgeResponseEventName;
		data.id = ++eventId;
		var event = new CustomEvent('nuanria-ScriptBridge-request', { detail: data });
		wnd.dispatchEvent(event);

		if (data.needResponse)
		{
			var res = responseQueue[data.id];
			if (res)
			{
				delete responseQueue[data.id];
				if (res.success)
				{
					return res.response;
				}
				else
				{
					nuanria.utils.logError('ScriptBridge "' + (data.Name ? data.Name : data.Script) + '" Error: ' + res.errMsg);
					return undefined;
				}
			}
			else if(!data.optional)
			{
				nuanria.utils.logError('ScriptBridge "' + (data.Name ? data.Name : data.Script) + '" Error: No response');
			}
		}
	}

	function onInjectedScriptResponse(arg)
	{
		try
		{
			var data = arg.detail;
			if (data)
			{
				if (data.type === 'response')
				{
					if (data.id == eventId)
					{
						responseQueue[data.id] = data.resultObj;
					}
				}
				else if (data.type === 'logging')
				{
					// This is just a message for log
					nuanria.utils.log(data.message);
				}
				else
				{
					nuanria.utils.logError('ScriptBridge - Unexpected response: ' + JSON.stringify(data));
				}
			}
			else
			{
				nuanria.utils.logError('ScriptBridge - onInjectedScriptResponse: Empty income data');
			}
		}
		catch (exc)
		{
			nuanria.utils.logError('ScriptBridge - onInjectedScriptResponse error: ' + exc.message);
		}
	}
};
