////////////////////////////////////////////////////////////////////////////////
//
//	@file		nuanria.meditech.js
//	@details	Dictation support for Meditech controls
//
//	@author		Andrew Kalashnikov
//	@date		22-Jun-2017
//	@copyright	(C) Copyright Nuance Communications, Inc. 2017 All Rights Reserved.
//				Trade secret and confidential information of Nuance Communications, Inc.
//				Copyright protection claimed includes all forms and matters of
//				copyrightable material and information now allowed by statutory or
//				judicial law or hereinafter granted, including without limitation,
//				material generated from the software programs which are displayed
//				on the screen such as icons, screen display looks, etc.
//
////////////////////////////////////////////////////////////////////////////////

var nuanria = nuanria || {};
nuanria.Meditech = nuanria.Meditech || {};

(function(){
	"use strict";

	var lineTerminator = "\n";
	var ActiveControl = null;
	
	if (!nuanria.ScriptBridge)
	{
		delete nuanria.contexts["meditech-api"];
		return;
	}

	var jsBridge = new nuanria.ScriptBridge(window, null);
	if (!jsBridge)
	{
		return;
	}

	nuanria.Meditech.enable = function(editor) {
	};

	nuanria.Meditech.disable = function(editor) {
	};

	nuanria.Meditech.getActive = function() {
		// 'MSpeechAPI' function is optional. It does not exist in non-Meditech pages, so pass true as 4th argument in order
		// to avoid errors logging.
		var init = jsBridge.invokeFunction('MSpeechAPI', ['initialize()'], false, true);
		if(init && init.length == 1 && init[ 0 ] == true) {
			var ID = jsBridge.invokeFunction('MSpeechAPI', ['controls.getCurrentControl()']);
			if(ID && ID.length == 1 && ID[ 0 ] != null) {
				ActiveControl = ID[ 0 ];
				return document.activeElement;
			}
		}
		return false;
	};

	nuanria.Meditech.getChanges = function() {
		nuanria.Meditech.getActive();
		if (ActiveControl == "") {
			nuanria.utils.logError("Can't find Meditech editor", "getChanges");
			return {};
		}

		var result = {};

		var text = getText(ActiveControl);
		var selRange = getSelRange(ActiveControl);

		result.text = text;
		result.selStart = selRange.start;
		result.selLength = selRange.length;
		
		var visibleRange = getVisibleRange(ActiveControl);
		result.visibleStart = visibleRange.visibleStart;
		result.visibleLength = visibleRange.visibleLength;

		// Don't log protected information (text), only its length.
		nuanria.utils.log("meditech.getChanges('" + ActiveControl + "'): TextLength=" + (result.text ? result.text.length : 0) +
			", Selection(" + result.selStart + ", " + result.selLength +
			"), Visible(" + result.visibleStart + ", " + result.visibleLength + ")");
		return result;
	};

	nuanria.Meditech.makeChanges = function(blockStart, blockLength, text, selStart, selLength) {

		nuanria.Meditech.getActive();

		nuanria.utils.log("Meditech.makeChanges: '" + ActiveControl + "', (" +
			blockStart + ", " + blockLength + "), TextLength=" + (text ? text.length : 0) +
			", (" + selStart + ", " + selLength + ")");

		if (ActiveControl == "") {
			nuanria.utils.logError("Can't find Meditech editor", "makeChanges");
			return;
		}

		var textLength = text.length;
		if (blockLength !== 0 || textLength) {
			// replace '\r\n' on '\n'
			if (text.indexOf('\r\n') >= 0) {
				text = text.replace(new RegExp('\r\n','g'), lineTerminator);
				var offset = textLength - text.length;
				if (offset > 0 && selStart >= blockStart + textLength) {
					selStart = selStart - offset;
				}
			}
			selectText(ActiveControl, blockStart, blockLength);
			sendText(ActiveControl, text);
		}

		selectText(ActiveControl, selStart, selLength);
	};

	nuanria.Meditech.getCharacterRectangle = function(index) {
		nuanria.Meditech.getActive();
		if (ActiveControl == "") {
			nuanria.utils.logError("Can't find Meditech editor", "getCharacterRectangle");
			return;
		}

		var result = {};
		var coords = getCharCoords(ActiveControl, index);
		result.top = coords.b;
		result.left = coords.r;
		result.bottom = result.top + 1;
		result.right = result.left + 1;

		// adjust result for dpi scaling
		if (window.devicePixelRatio) {
			result.top = Math.floor(result.top * window.devicePixelRatio);
			result.left = Math.floor(result.left * window.devicePixelRatio);
			result.bottom = Math.floor(result.bottom * window.devicePixelRatio);
			result.right = Math.floor(result.right * window.devicePixelRatio);
		}

		nuanria.utils.log("Meditech:GetCharacterRectangle", index, JSON.stringify(result));
		return result;
	};

	/*
	* Returns New-Line and New-Paragraph terminator characters
	*/
	nuanria.Meditech.getLineParagraphTerminators = function() {
		return { Line: lineTerminator, Paragraph: lineTerminator + lineTerminator };
	}

	//-----------------------------------------------------------------------------
	// Meditech API
	function getText(id) {
		var text = jsBridge.invokeFunction('MSpeechAPI', ['control.text.read(id)', id]);
		if (text && text.length == 1 && text[ 0 ] != null) {
			return text[ 0 ];
		}
		return "";
	}

	function getSelRange(id) {
		var sel = jsBridge.invokeFunction('MSpeechAPI', ['control.selection.getRange(id)', id]);
		if (sel && sel.length == 2) {
			return {
				start: sel[ 0 ],
				length: sel[ 1 ]
			};
		}
		return { start: 0, length: 0 };
	}

	function getVisibleRange(id) {
		var visibleSel = jsBridge.invokeFunction('MSpeechAPI', ['control.visible.getRange(id)', id]);
		if (visibleSel && visibleSel.length == 2) {
			return {
				visibleStart: visibleSel[ 0 ],
				visibleLength: visibleSel[ 1 ]
			};
		}
		return { visibleStart: 0, visibleLength: 0 };
	}

	function selectText(id, start, length) {
		jsBridge.invokeFunction('MSpeechAPI', ['control.selection.setRange(id,point#,extent#)', id, start, length]);
	}

	function sendText(id, text) {
		var sel = getSelRange(id);
		jsBridge.invokeFunction('MSpeechAPI', ['control.text.write(id,point#,extent#,text)', id, sel.start, sel.length, text]);
	}

	function getCharCoords(id, index) {
		var rect = jsBridge.invokeFunction('MSpeechAPI', ['control.text.getClientRect(id,point#,extent#)', id, index, 0]);
		if (rect && rect.length == 4) {
			return {
				l: rect[ 0 ],
				t: rect[ 1 ],
				r: rect[ 2 ],
				b: rect[ 3 ]
			};
		}
		return { l: 0, t: 0, r: 0, b: 0 };
	}
}());