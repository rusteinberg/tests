﻿//DESCRIPTION:Change all shared URL hyperlink destinations in the document to non-shared

// Modified 2021-09-15
// Keith Gilbert, Gilbert Consulting
// gilbertconsulting.com

Pre();
  
function Pre () {  
	// Check to make sure all required conditions are met
	if (!app.documents.length) { 
		alert("No InDesign documents are open. Please open a document and try again.");
		return;
	}
	Main();
	// app.doScript(Main, undefined, undefined, UndoModes.ENTIRE_SCRIPT,"Run Script");
}  

function Main() {
	var myDoc = app.activeDocument;
	var myNumHyperlinks = myDoc.hyperlinks.count();
    var myCount = 0;
	var myBadCount = 0;
	for (var i=myNumHyperlinks-1; i >= 0; i--) {
		var myHyperlink = myDoc.hyperlinks[i];
		try { // This try/catch is necessary when the hyperlink destination is invalid, such as a URL destination that is set to just 'http://'
			if (myHyperlink.destination.hidden == false) {
				if (myHyperlink.source.constructor.name != "CrossReferenceSource") { // The hyperlink is not a cross reference
					var myDestURL = myHyperlink.destination.destinationURL;
					var myHyperlinkName = myHyperlink.name;
					var myHyperlinkSource = myHyperlink.source;
					try {
						var myCStyle = myHyperlinkSource.sourceText.appliedCharacterStyle;
					}
					catch (e) {}
					myHyperlink.remove();	
					i++;
					var myNewDestination = myDoc.hyperlinkURLDestinations.add(myDestURL, {hidden:true});
					var myNewHyperlink = myDoc.hyperlinks.add(myHyperlinkSource,myNewDestination);
					myNewHyperlink.name = myHyperlinkName;
					try {
						myNewHyperlink.source.sourceText.appliedCharacterStyle = myCStyle;
					}
					catch (e) {}
					myCount++;
				}
			}
		}
		catch (e2) {
			myBadCount++;
		}
	}
    alert (myCount+" hyperlink shared destinations fixed. "+myBadCount+" hyperlink(s) are broken or have invalid destinations.");
}