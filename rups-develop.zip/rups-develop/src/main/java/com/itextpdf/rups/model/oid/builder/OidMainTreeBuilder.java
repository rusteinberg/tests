/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation with the addition of the
    following permission added to Section 15 as permitted in Section 7(a):
    FOR ANY PART OF THE COVERED WORK IN WHICH THE COPYRIGHT IS OWNED BY
    APRYSE GROUP. APRYSE GROUP DISCLAIMS THE WARRANTY OF NON INFRINGEMENT
    OF THIRD PARTY RIGHTS

    This program is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU Affero General Public License for more details.
    You should have received a copy of the GNU Affero General Public License
    along with this program; if not, see http://www.gnu.org/licenses or write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA, 02110-1301 USA, or download the license from the following URL:
    http://itextpdf.com/terms-of-use/

    The interactive user interfaces in modified source and object code versions
    of this program must display Appropriate Legal Notices, as required under
    Section 5 of the GNU Affero General Public License.

    In accordance with Section 7(b) of the GNU Affero General Public License,
    a covered work must retain the producer line in every PDF that is created
    or manipulated using iText.

    You can be released from the requirements of the license by purchasing
    a commercial license. Buying such a license is mandatory as soon as you
    develop commercial activities involving the iText software without
    disclosing the source code of your own applications.
    These activities include: offering paid services to customers as an ASP,
    serving PDFs on the fly in a web application, shipping iText with a closed
    source product.

    For more information, please contact iText Software Corp. at this
    address: sales@itextpdf.com
 */
package com.itextpdf.rups.model.oid.builder;

import com.itextpdf.rups.model.oid.OidTreeNode;

import java.util.Map;
import static com.itextpdf.rups.model.oid.OidTreeNode.entry;

/**
 * Static class for building an "OID -> Display Name" mapping tree from the
 * very root.
 */
public final class OidMainTreeBuilder {
    private OidMainTreeBuilder() {
        // static class
    }

    /**
     * Tree: *
     */
    public static OidTreeNode build() {
        // @formatter:off
        return new OidTreeNode(null, Map.ofEntries(
          entry("0", OidItuTTreeBuilder.build()),
          entry("1", "iso", Map.ofEntries(
            entry("0", "standard", Map.ofEntries(
              entry("32004", createIso32004Tree())
            )),
            entry("1", "registration-authority", Map.ofEntries(
              entry("2", "document-type")
            )),
            entry("2", OidIsoMemberBodyTreeBuilder.build()),
            entry("3", OidIsoIdentifiedOrganizationTreeBuilder.build())
          )),
          entry("2", OidJointIsoItuTTreeBuilder.build())
        ));
        // @formatter:on
    }

    /**
     * Tree: 1.0.32004.*
     *
     * @see <a href="https://pdfa.org/resource/iso-ts-32004-integrity-protection/">
     * Integrity protection in encrypted documents in PDF 2.0
     * </a>
     */
    private static OidTreeNode createIso32004Tree() {
        // @formatter:off
        return new OidTreeNode("iso32004", Map.ofEntries(
          entry("0", "modules", Map.ofEntries(
            entry("1", "pdfmac")
          )),
          entry("1", "pdfmac", Map.ofEntries(
            entry("0", "id-ct-pdfMacIntegrityInfo"),
            entry("1", "id-kdf-pdfMacWrapKdf"),
            entry("2", "id-attr-pdfMacData")
          ))
        ));
        // @formatter:on
    }
}
