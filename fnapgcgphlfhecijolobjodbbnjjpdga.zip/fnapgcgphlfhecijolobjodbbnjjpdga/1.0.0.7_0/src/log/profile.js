/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
IBMa.DAP.Log=IBMa.DAP.Log||{},IBMa.DAP.Log.Profile={scanTimes:[],toolName:"DAP",metricsURLV2:"https://aat.w3ibm.mybluemix.net",profile:function(e,a){IBMa.DAP.Log.Profile.scanTimes[a]=IBMa.DAP.Log.Profile.scanTimes[a]||[],IBMa.DAP.Log.Profile.scanTimes[a].push(e)},sendLogs:function(e){try{var a="";if(e&&0===e.indexOf("https://aat")){var o=e.match(/(https?:\/\/[^\/]*)\/token\/([a-f0-9-]{36})/);o&&(IBMa.DAP.Log.Profile.metricsURLV2=o[1],a=o[2])}for(var i in IBMa.DAP.Log.Profile.scanTimes)for(;IBMa.DAP.Log.Profile.scanTimes[i].length>0;){var t=IBMa.DAP.Log.Profile.scanTimes[i].splice(0,150),s="?t="+IBMa.DAP.Log.Profile.toolName+"&tag="+i+"&a="+a+"&pol=&st=";t.forEach(function(e){s+=e,s+=","}),s=s.substr(0,s.length-1);var r=new XMLHttpRequest;r.open("GET",IBMa.DAP.Log.Profile.metricsURLV2+"/api/pub/meter/v2"+s,!1),r.send(null)}}catch(n){}}};