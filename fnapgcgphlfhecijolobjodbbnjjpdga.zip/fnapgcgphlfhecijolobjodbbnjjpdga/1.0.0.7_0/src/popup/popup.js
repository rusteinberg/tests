/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
$("#dapPluginLanding").click(function(){window.open("https://ibm.biz/a11yDashboard")}),$("#dapPluginHelp").click(function(){window.open(chrome.runtime.getURL("documentation/usingDAP.htm"))}),$("#dapPluginFormSupport").click(function(){window.open("https://ibm.biz/a11ySupport")}),$("#dapPluginOptions").click(function(){window.open(chrome.runtime.getURL("src/options/options.html"))});