/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
IBMa.DAP.Report=IBMa.DAP.Report||{},IBMa.DAP.Report.csv={policiesMeta:[],reportLevelsDesc:{violation:"Violation",potentialviolation:"Potential Violation",recommendation:"Recommendation",potentialrecommendation:"Potential Recommendation",manual:"Manual"},toCSV:function(e){return null==e?'"null"':0==e.length?'""':(e.replace('"','""'),'"'+e+'"')},csvReportHeader:function(e){var t=e.summary.policies;return str="Policies: ",t.forEach(function(e,t){IBMa.DAP.Report.csv.policiesMeta.hasOwnProperty(e)&&(t>0&&(str+=";"),str+=IBMa.DAP.Report.csv.policiesMeta[e])}),str+="\n",str+="Date: "+Date().toString()+"\n\n",str+="URL,Level,Message,XPath,Rule Id,Help\n",str},csvReport:function(e){var t="";return t=IBMa.DAP.Report.csv.csvReportHeader(e),e.reports.forEach(function(e){var o=e.frameURL;e.issues.forEach(function(e){var r=e.xpath;r=r.replace(/"/g,"&#34;").replace(/'/g,"&#39;");var a=e.tokenMessage;a=a.replace(/"/g,'""'),a='"'+a+'"',t+=IBMa.DAP.Report.csv.toCSV(o)+","+IBMa.DAP.Report.csv.toCSV(IBMa.DAP.Report.csv.reportLevelsDesc[e.level])+","+a+","+IBMa.DAP.Report.csv.toCSV(r)+","+IBMa.DAP.Report.csv.toCSV(e.ruleId)+","+IBMa.DAP.Report.csv.toCSV(e.helpUrl)+"\n"})}),t+="\n",t+="\n"}};