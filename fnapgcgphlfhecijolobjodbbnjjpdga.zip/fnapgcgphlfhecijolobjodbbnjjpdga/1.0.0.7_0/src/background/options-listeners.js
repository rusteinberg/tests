/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
chrome.runtime.onMessage.addListener(function(e,n,o){try{if("getRuleSets"==e.name&&loadRules(function(e){if(e.success){var n={};for(var t in IBMa.Config.rs)rs=IBMa.Config.rs[t],n[rs.id]=IBMa.Config.getNLS(rs.nameCode);e.ruleSets=n,o(e)}else o(e)},e.forcereload),"getOptions"==e.name&&readOptions(function(e){o(null!=e?e:{exception:"empty options"})}),"openOptions"==e.name){var t=chrome.extension.getURL("src/options/options.html");chrome.tabs.query({url:t},function(e){if(e.length){var n=(e[0].id,e[0].windowId);chrome.windows.update(n,{focused:!0},function(){chrome.tabs.update(e[0].id,{active:!0})})}else chrome.tabs.create({url:t})})}if("setOptions"==e.name){var s=e.options;void 0==s&&o({exception:"Options can not be empty"});var i=defaultOptions;Object.keys(s).forEach(function(e){i[e]=s[e]}),IBMa.Config.options=i,i.debug&&(IBMa.Config.DEBUG=i.debug),o({success:!0,message:"Options are set."})}if("setDefaultOptions"==e.name&&(IBMa.Config.options=defaultOptions,o({success:!0,message:"Options are saved."})),"openDAPHelp"==e.name){var a=chrome.extension.getURL("documentation/UsingDAP.htm");chrome.tabs.create({url:a})}return!0}catch(r){o({exception:""+r})}});