/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
function readOptions(n){n(IBMa.Config.options)}function isServerChanged(n){readOptions(function(e){if(null!=e){var r=e.rulePack;r!==IBMa.GSALoader.ROOTURL[0].url?(IBMa.Config.DEBUG&&console.log("Rule server changed to "+IBMa.GSALoader.ROOTURL[0].url+" from "+r),n(!0)):n(!1)}})}function reloadRulesIfRuleServerChanged(n){isServerChanged(function(e){e?loadRules(function(r){n(e,r)}):n(e,!1)})}function getCurrentActiveTab(n){return chrome.tabs.query({currentWindow:!0,windowType:"normal",active:!0},function(e){n(e[0])}),!0}function getBrowserTabId(n,e){return void 0==n.tabId||null==n.tabId||""==n.tabId?getCurrentActiveTab(function(n){e(n.id)}):e(n.tabId),!0}