/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
var IBMa={};IBMa.Config=IBMa.Config||{DEBUG:!1,nls:{},rulesets:{},metadata:{},"rules.js":{},rs:{},rsMap:{},policies:[],locale:"en-us",loaded:!1,options:{},setLocale:function(e){e=e.toLowerCase()},addNLS:function(e,n){e=e.toLowerCase(),IBMa.Config.nls[e]=IBMa.Config.nls[e]||{};for(var a in n)IBMa.Config.nls[e][a]=n[a]},getNLS:function(e,n){if(!e)return null;if(IBMa.Config.locale in IBMa.Config.nls&&e in IBMa.Config.nls[IBMa.Config.locale]){if(void 0==n||"undefined"==typeof n)return IBMa.Config.nls[IBMa.Config.locale][e];var a=IBMa.Config.nls[IBMa.Config.locale][e],i=a;if(i=i.replace(/</g,"&lt;"),i=i.replace(/>/g,"&gt;"),n.length>0){var o=/{([0-9]+)}/g;i=i.replace(o,function(e,a){return n[a]})}return i}return e},addRuleset:function(e){IBMa.Config.rs[e.id]=e;for(var n=e,a=0;a<n.requirements.length;++a){var i=n.requirements[a];for(var o in i.rules)IBMa.Config.rsMap[o]=IBMa.Config.rsMap[o]||[],IBMa.Config.rsMap[o].push({rs:{id:e.id,label:IBMa.Config.getNLS(n.nameCode)},requirement:{id:i.criterionNumber,label:IBMa.Config.getNLS(i.criterionDesc),level:IBMa.Config.getNLS(i.criterionLevel)},levelCode:i.rules[o].severityCode})}}};