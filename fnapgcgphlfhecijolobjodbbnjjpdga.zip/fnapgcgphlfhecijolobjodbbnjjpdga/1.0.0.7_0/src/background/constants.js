/******************************************************************************
 * Licensed Materials - Property of IBM
 * "Restricted Materials of IBM"
 * © Copyright IBM Corp. 2016,2017 All Rights Reserved.
 *
 * Copying, redistribution and/or modification is prohibited.
 * U.S. Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *****************************************************************************/
var constants={rulePack:"https://cc-rules.w3ibm.mybluemix.net/js/latest/",filterMap:["violation","potentialviolation","recommendation","potentialrecommendation","manual"],severityLevels:["high","medium","low","information"],eventScanning:!1,includeHidden:!1,refreshInterval:5,labels:["Chrome","master","V12","Windows"],debug:!1},defaultOptions={policies:constants.policies,filterMap:constants.filterMap,severityLevels:constants.severityLevels,eventScanning:constants.eventScanning,rulePack:constants.rulePack,includeHidden:constants.includeHidden,refreshInterval:constants.refreshInterval,label:constants.labels,debug:constants.debug};